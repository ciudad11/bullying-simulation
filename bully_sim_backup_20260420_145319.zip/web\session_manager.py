"""
SessionManager - 适配层
将新的 MultiAgentRunner 适配到现有的 Session 接口
保留所有现有功能（日志、报告、配置加载）
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / ".." / "src"))

import uuid
import time
import random
import json
import asyncio
from datetime import datetime
from typing import Dict, List, Optional


# ============================================================
# 尝试导入新的 LangGraph 多Agent系统
# ============================================================

try:
    from multi_agent import create_runner, MultiAgentRunner
    NEW_MULTI_AGENT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: New multi_agent module not available: {e}")
    NEW_MULTI_AGENT_AVAILABLE = False


# ============================================================
# 配置加载（复用 orchestrator.yaml）
# ============================================================

def load_config() -> dict:
    """加载 orchestrator.yaml 配置"""
    # 尝试多个可能的路径
    possible_paths = [
        Path(__file__).parent.parent / "config" / "orchestrator.yaml",
        Path(__file__).parent.parent.parent / "config" / "orchestrator.yaml",
        Path("config/orchestrator.yaml"),
        Path("../config/orchestrator.yaml"),
        Path(__file__).parent.parent / "src" / "orchestrator.yaml",
        Path("src/orchestrator.yaml"),
    ]

    for config_path in possible_paths:
        if config_path.exists():
            try:
                import yaml
                with open(config_path, "r", encoding="utf-8") as f:
                    config = yaml.safe_load(f) or {}
                    print(f"[Config] Loaded from {config_path}")
                    return config
            except ImportError:
                print("Warning: yaml module not available, using default config")
                return {}
            except Exception as e:
                print(f"Warning: Failed to load config from {config_path}: {e}")
                continue

    print("Warning: orchestrator.yaml not found, using default config")
    return {}


# ============================================================
# SessionManager - 兼容层
# ============================================================

class SessionManager:
    """
    会话管理器
    封装新的 MultiAgentRunner，提供与旧接口兼容的方法
    """

    def __init__(
        self,
        session_id: str,
        level: int = 2,
        scenario: dict = None,
        use_llm: bool = True,
        config: dict = None,
    ):
        self.session_id = session_id
        self.level = level
        self.scenario = scenario
        self.use_llm = use_llm
        self.config = config or load_config()

        self.round = 0
        self.messages: List[Dict] = []
        self.interventions: List[Dict] = []
        self.started_at = datetime.now()

        # 终止条件跟踪
        self.auto_ended = False
        self.auto_end_reason = ""
        self.result_type = ""
        self.AUTO_END_CONFIG = {
            "bullying_stopped_rounds": self.config.get("bullying_stopped_rounds", 3),
            "intervention_effective_rounds": self.config.get("intervention_effective_rounds", 4),
            "victim_crisis_threshold": self.config.get("victim_crisis_threshold", 0.95),
            "victim_crisis_rounds": self.config.get("victim_crisis_rounds", 3),
            "max_rounds": self.config.get("max_rounds", 40),
            "min_rounds": self.config.get("min_rounds", 3),
        }

        # 创建新的 MultiAgentRunner
        if NEW_MULTI_AGENT_AVAILABLE:
            self.runner: Optional[MultiAgentRunner] = create_runner(
                level=level,
                max_rounds=self.AUTO_END_CONFIG["max_rounds"],
                use_llm=use_llm,
                config=self.config,
                session_id=session_id,
                scenario=self.scenario,
            )
            print(f"[SessionManager] Using new LangGraph MultiAgentRunner (level={level})")
        else:
            self.runner = None
            print(f"[SessionManager] MultiAgentRunner not available, running in limited mode")

        # 初始化日志
        self._init_logging()

    def _init_logging(self):
        """初始化日志目录"""
        self.log_dir = Path(__file__).parent.parent / "logs" / f"sim_{int(self.started_at.timestamp())}"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.session_log_file = self.log_dir / "session_log.json"
        self.session_md_file = self.log_dir / "session_log.md"

        self.session_data = {
            "session_id": self.session_id,
            "started_at": self.started_at.isoformat(),
            "level": self.level,
            "scenario": self.scenario,
            "use_llm": self.use_llm,
            "messages": [],
            "interventions": [],
            "metrics_history": [],
        }

    def _save_log(self):
        """保存日志"""
        try:
            with open(self.session_log_file, "w", encoding="utf-8") as f:
                json.dump(self.session_data, f, ensure_ascii=False, indent=2)
            self._save_markdown()
        except Exception as e:
            print(f"[SessionManager] Log save failed: {e}")

    def _save_markdown(self):
        """保存 Markdown 日志"""
        lines = [
            f"# 话语霸凌模拟会话记录",
            f"",
            f"**会话ID**: {self.session_id}",
            f"**开始时间**: {self.session_data['started_at']}",
            f"**霸凌级别**: {self.level}",
            f"**智能模式**: {'是' if self.use_llm else '否'}",
            f"",
        ]
        if self.scenario:
            lines.extend([
                f"## 会话情境",
                f"",
                f"**{self.scenario.get('title', '未命名情境')}**",
                f"",
                f"{self.scenario.get('description', '')}",
                f"",
            ])
        lines.extend([
            f"## 会话过程",
            f"",
        ])
        for msg in self.session_data.get("messages", []):
            icon = {"bully": "😈", "victim": "😢", "bystander_a": "✨", "bystander_b": "👀", "teacher": "👨‍🏫"}.get(msg.get("role", ""), "💬")
            lines.append(f"- **{msg.get('timestamp', '')}** [{msg.get('round', 0)}轮] {icon} **{msg.get('sender', '未知')}**: {msg.get('content', '')}")
        if self.session_data.get("interventions"):
            lines.extend(["", "## 教师干预", ""])
            for interv in self.session_data["interventions"]:
                lines.append(f"- **[第{interv.get('round', 0)}轮]**: {interv.get('content', '')}")
        if self.session_data.get("metrics_history"):
            lines.extend(["", "## 指标趋势", "", "| 轮次 | 霸凌强度 | 受害者压力 |", "|------|---------|-----------|"])
            for m in self.session_data["metrics_history"]:
                lines.append(f"| {m.get('round', 0)} | {m.get('bullying_intensity', 0):.0%} | {m.get('victim_distress', 0):.0%} |")
        try:
            with open(self.session_md_file, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except Exception as e:
            print(f"[SessionManager] Markdown save failed: {e}")

    def run_round(self) -> Dict:
        """运行一轮对话"""
        if self.runner is None:
            return self._limited_run_round()

        # 添加情境消息（第一轮）- 同时添加到runner的state和显示消息列表
        if self.runner.state.round == 0 and self.scenario:
            scenario_content = f"[场景] {self.scenario.get('title', '')}：{self.scenario.get('description', '')}"
            
            # 添加到runner的state（让智能体能看到场景信息）
            from multi_agent.state import Message as StateMessage
            scenario_state_msg = StateMessage(
                sender_id="system",
                sender_name="系统",
                role="system",
                content=scenario_content,
                timestamp=datetime.now().strftime("%H:%M:%S"),
                round=0,
            )
            self.runner.state.messages.append(scenario_state_msg)
            
            # 添加到显示消息列表
            scenario_msg = {
                "id": "scenario_0",
                "sender": "System",
                "role": "system",
                "content": f"[Scenario] {self.scenario.get('title', '')}: {self.scenario.get('description', '')}",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "hostile_score": 0,
                "emotions": [],
            }
            self.messages.append(scenario_msg)
            self.session_data["messages"].append(scenario_msg)

        # 调用 MultiAgentRunner（LangGraph 内部管理轮次）
        result = self.runner.run_round()

        # 同步轮次
        self.round = self.runner.state.round

        # 检查终止条件
        if result.get("finished"):
            self.auto_ended = True
            self.auto_end_reason = result.get("termination_reason", "未知原因")
            self.result_type = result.get("result_type", "")
            self._save_log()
            return {
                "round": self.round,
                "done": True,
                "auto_ended": True,
                "auto_end_reason": self.auto_end_reason,
                "result_type": self.result_type,
                "status": self.runner.get_status(),
                "messages": [],  # 结束时无新消息，前端无需追加
            }

        # 转换消息格式并记录日志
        # 只取本轮新增的消息（result["messages"] 已经是新增的消息）
        new_messages = result.get("messages", [])
        for msg in new_messages:
            self.messages.append(msg)
            self.session_data["messages"].append(msg)

        # 记录指标历史
        metrics = result.get("metrics", {})
        self.session_data["metrics_history"].append({
            "round": self.round,
            "bullying_intensity": metrics.get("bullying_intensity", 0),
            "victim_distress": metrics.get("victim_distress", 0),
        })

        self._save_log()

        return {
            "round": self.round,
            "done": False,
            "auto_ended": False,
            "status": self.runner.get_status(),
            "messages": new_messages,
            "metrics": metrics,
        }

    def _limited_run_round(self) -> Dict:
        """有限模式运行（当 MultiAgentRunner 不可用时）"""
        self.round += 1
        return {
            "round": self.round,
            "done": False,
            "status": {"round": self.round, "finished": False},
            "messages": [],
        }

    def intervene(self, content: str) -> Dict:
        """教师干预"""
        if self.runner is None:
            return {"feedback": ["MultiAgentRunner not available"], "messages": []}

        # 调用新版 MultiAgentRunner.intervene() (graph_builder)
        try:
            result = self.runner.intervene(content)
        except Exception as e:
            return {"feedback": [f"干预处理失败: {str(e)}"], "messages": []}

        # 新版intervene()返回 dict: {"quality_score", "feedback", "victim_care_score", ...}
        if not result:
            return {"feedback": ["干预未产生有效响应"], "messages": []}

        if not isinstance(result, dict):
            return {"feedback": [f"意外返回值类型: {type(result)}"], "messages": []}

        feedback_list = result.get("feedback", [])
        quality = result.get("quality_score", 0)
        recommendation = result.get("recommendation", "")
        if feedback_list and recommendation and recommendation not in str(feedback_list):
            feedback_list = feedback_list + [recommendation]

        interv_record = {
            "content": content,
            "quality_score": quality,
            "victim_care_score": result.get("victim_care_score", 0),
            "feedback": feedback_list,
            "round": self.round,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "bullying_reduction": result.get("intervention_record", {}).get("bullying_reduction", 0),
            "distress_reduction": result.get("intervention_record", {}).get("distress_reduction", 0),
        }
        self.interventions.append(interv_record)
        self.session_data["interventions"].append(interv_record)
        
        # 更新状态中的干预计数和最后干预信息
        self.runner.state.intervention_count += 1
        self.runner.state.last_intervention = content
        self.runner.state.last_intervention_round = self.round
        
        # 【修复】同步 MultiAgentRunner 的消息计数指针：
        # intervene() 在 run_round() 之间被调用，会向 state.messages 添加教师消息，
        # 若不同步 _prev_msg_count，下一次 run_round() 会把教师消息也算成"新消息"
        # 导致前端重复显示同一教师的干预内容
        # 注意：run_round() 读取的是 runner._prev_msg_count（不是 _step_runner 的），
        # 之前的修复错把指针同步到了 _step_runner._prev_msg_count，没有效果
        self.runner._prev_msg_count = len(self.runner.state.messages)
        
        self._save_log()

        return {
            "content": content,
            "feedback": feedback_list,
            "quality_score": quality,
            "victim_care_score": result.get("victim_care_score", 0),
            "bullying_intensity": result.get("bullying_intensity", 0),
            "victim_distress": result.get("victim_distress", 0),
            "recommendation": recommendation,
        }

    def get_status(self) -> Dict:
        """获取状态"""
        if self.runner:
            return self.runner.get_status()
        return {
            "round": self.round,
            "level": self.level,
            "bullying_intensity": 0,
            "victim_distress": 0,
            "bystander_intervention": 0,
            "finished": False,
            "termination_reason": "",
        }

    def add_message(self, message: Dict) -> None:
        """添加消息到会话"""
        self.messages.append(message)
        self.session_data["messages"].append(message)
        self._save_log()

    def get_messages(self, after_id: str = None) -> List[Dict]:
        """获取消息"""
        if after_id is None:
            return self.messages
        idx = next((i for i, m in enumerate(self.messages) if m.get("id") == after_id), -1)
        return self.messages[idx + 1:]

    def check_auto_end_conditions(self) -> Dict:
        """检查自动终止条件（兼容旧接口）"""
        if self.runner is None:
            return {"should_end": False}

        status = self.runner.get_status()
        result = {
            "should_end": status.get("finished", False),
            "reason": status.get("termination_reason", ""),
            "details": {},
        }

        if result["should_end"]:
            self.auto_ended = True
            self.auto_end_reason = result["reason"]
            self.result_type = status.get("result_type", "")

        return result

    def generate_report(self) -> Dict:
        """生成评估报告"""
        if self.runner is None:
            return {"summary": {"total_messages": 0}}

        metrics = self.runner.get_metrics()
        return {
            "summary": {
                "total_messages": len(self.messages),
                "intervention_count": len(self.interventions),
                "bullying_intensity": metrics.get("bullying_intensity", 0),
                "victim_distress": metrics.get("victim_distress", 0),
            },
            "metrics": metrics,
            "messages": self.messages,
            "interventions": self.interventions,
            "ability_assessment": {
                "discovery": {"level": "good" if metrics.get("bullying_intensity", 0) > 0 else "needs_improvement"},
                "intervention": {"count": len(self.interventions)},
            },
        }
