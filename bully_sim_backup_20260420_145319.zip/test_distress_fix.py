"""验证受害者压力修复效果"""
import requests, json

base = 'http://localhost:5000'

# 创建session
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': True})
data = r.json()
sid = data['session_id']
s = data['status']
print(f'Session: {sid}')
print(f'  Initial: B={s["bullying_intensity"]:.2%} V={s["victim_distress"]:.2%}')

# 运行3轮观察
for i in range(3):
    r = requests.post(f'{base}/api/session/{sid}/run')
    data = r.json()
    s = data.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)
    msgs = data.get('messages', [])
    last_msg = msgs[-1]['content'][:30] if msgs else ''
    print(f'  Round {i+1}: B={b:.2%} V={v:.2%}  last_msg="{last_msg}..."')
    if data.get('done'):
        print(f'  TERMINATED: {data.get("auto_end_reason","")}')
        break

if not data.get('done'):
    # 做一次干预
    r = requests.post(f'{base}/api/session/{sid}/intervene', json={
        'content': '思远，你还好吗？老师看到了你的委屈，这不是你的错，老师会保护你。陈浩，你的行为已经构成了言语霸凌，需要立刻停止。'
    })
    iv = r.json()
    print(f'  Intervene: quality={iv.get("quality_score",0):.2f} B={iv.get("bullying_intensity",0):.2%} V={iv.get("victim_distress",0):.2%}')

    # 再运行3轮观察恢复
    for i in range(3):
        r = requests.post(f'{base}/api/session/{sid}/run')
        data = r.json()
        s = data.get('status', {})
        b = s.get('bullying_intensity', 0)
        v = s.get('victim_distress', 0)
        print(f'  Round {i+4}: B={b:.2%} V={v:.2%}')
        if data.get('done'):
            print(f'  TERMINATED: {data.get("auto_end_reason","")}')
            break
