"""
LangGraph Graph Builder - Step-by-Step Mode
Each round runs independently, replacing LangGraph invoke()
"""

from typing import Optional
from langgraph.graph import StateGraph, END

from .state import SharedState, create_initial_state, message_to_display, Message as StateMessage
from .llm_client import LLMClient, get_api_key


# ============================================================
# Global LLM client
# ============================================================

_llm_client: Optional[LLMClient] = None


def set_llm_client(client: Optional[LLMClient]):
    global _llm_client
    _llm_client = client


def get_llm_client() -> Optional[LLMClient]:
    return _llm_client


# ============================================================
# Node functions (lazy import to avoid circular deps)
# ============================================================

def _supervisor_node(state) -> dict:
    from .supervisor import _supervisor_logic
    return _supervisor_logic(state)


def _bully_node(state) -> dict:
    from .supervisor import _agent_logic
    return _agent_logic(state, "bully")


def _victim_node(state) -> dict:
    from .supervisor import _agent_logic
    return _agent_logic(state, "victim")


def _bystander_a_node(state) -> dict:
    from .supervisor import _agent_logic
    return _agent_logic(state, "bystander_a")


def _bystander_b_node(state) -> dict:
    from .supervisor import _agent_logic
    return _agent_logic(state, "bystander_b")


def _evaluate_node(state) -> dict:
    from .evaluator_node import _evaluator_logic
    return _evaluator_logic(state)


def _route_to_agents(state) -> str:
    from .supervisor import _route_to_agents as route
    return route(state)


# ============================================================
# Step-by-step runner (replaces LangGraph invoke)
# ============================================================

class StepRunner:
    """
    Step-by-step runner.
    Replaces LangGraph invoke(), each round runs independently.
    """

    def __init__(self, state: SharedState, llm_client: Optional[LLMClient] = None):
        self.state = state
        self.llm_client = llm_client
        set_llm_client(llm_client)

    def step(self) -> dict:
        """
        Execute one complete round.
        Returns: {"done": bool, "messages": [...], "status": {...}}
        """
        # 1. Supervisor: decide who speaks
        self._prev_msg_count = len(self.state.messages)
        result = _supervisor_node(self.state)

        if result.get("finished"):
            self.state.finished = True
            self.state.termination_reason = result.get("termination_reason", "")
            self.state.result_type = result.get("result_type", "")
            return self._build_response(done=True)

        # 2. Process speaking queue
        self._process_speaking_queue()

        # 3. Evaluator: evaluate all messages
        _evaluate_node(self.state)

        return self._build_response(done=False)

    def _process_speaking_queue(self):
        """Process all agents in the speaking queue"""
        while self.state.speaking_queue:
            agent_id = self.state.speaking_queue[0]

            if agent_id == "bully":
                result = _bully_node(self.state)
            elif agent_id == "victim":
                result = _victim_node(self.state)
            elif agent_id == "bystander_a":
                result = _bystander_a_node(self.state)
            elif agent_id == "bystander_b":
                result = _bystander_b_node(self.state)
            else:
                break

            self._merge_result(result)

    def _merge_result(self, result: dict):
        """Merge node return values into state"""
        if not result:
            return

        for key, value in result.items():
            if key == "messages":
                existing = getattr(self.state, key, [])
                if isinstance(existing, list) and isinstance(value, list):
                    # Deduplicate by sender_id+round
                    existing_ids = set()
                    for m in existing:
                        if hasattr(m, "sender_id"):
                            existing_ids.add(f"{m.sender_id}_{getattr(m, 'round', 0)}")
                        elif isinstance(m, dict):
                            existing_ids.add(f"{m.get('sender_id', '')}_{m.get('round', 0)}")
                    for msg in value:
                        if hasattr(msg, "sender_id"):
                            msg_id = f"{msg.sender_id}_{getattr(msg, 'round', 0)}"
                        elif isinstance(msg, dict):
                            msg_id = f"{msg.get('sender_id', '')}_{msg.get('round', 0)}"
                        else:
                            msg_id = str(id(msg))
                        if msg_id not in existing_ids:
                            existing.append(msg)
            elif key == "pending_messages":
                existing = getattr(self.state, key, [])
                if isinstance(existing, list) and isinstance(value, list):
                    existing.extend(value)
            else:
                setattr(self.state, key, value)

    def _build_response(self, done: bool) -> dict:
        return {
            "done": done,
            "finished": self.state.finished,
            "termination_reason": self.state.termination_reason,
            "result_type": self.state.result_type,
            "round": self.state.round,
            "metrics": {
                "bullying_intensity": self.state.bullying_intensity,
                "victim_distress": self.state.victim_distress,
                "bystander_intervention": self.state.bystander_intervention,
            },
            "messages": [message_to_display(m) for m in self.state.messages],
        }


# ============================================================
# MultiAgentRunner
# ============================================================

class MultiAgentRunner:
    """
    Multi-agent runner using step-by-step execution.
    """

    def __init__(
        self,
        level: int = 2,
        max_rounds: int = 40,
        use_llm: bool = True,
        config: dict = None,
        session_id: str = None,
        scenario: dict = None,
    ):
        self.level = level
        self.max_rounds = max_rounds
        self.use_llm = use_llm
        self.config = config or {}
        self.session_id = session_id or f"sim_{int(__import__('time').time())}"
        self.scenario = scenario

        self.llm_client: Optional[LLMClient] = None
        if use_llm:
            api_key = get_api_key()
            if api_key:
                self.llm_client = LLMClient(api_key)
                print(f"[Runner] LLM client initialized")
            else:
                print(f"[Runner] No API key, using presets")

        self.state = create_initial_state(
            level=level,
            max_rounds=max_rounds,
            config=config,
            scenario=scenario,
        )

        self._step_runner = StepRunner(self.state, self.llm_client)
        self._prev_msg_count = 0

        print(f"[Runner] Ready (level={level}, max_rounds={max_rounds})")

    def run_round(self) -> dict:
        """Run one round of dialogue, returns only new messages since last call"""
        if self.state.finished:
            return {
                "done": True,
                "finished": True,
                "termination_reason": self.state.termination_reason,
                "result_type": self.state.result_type,
                "round": self.state.round,
                "metrics": self._get_metrics(),
                "messages": [],
            }

        prev_count = self._prev_msg_count
        resp = self._step_runner.step()
        resp["messages"] = [message_to_display(m) for m in self.state.messages[prev_count:]]
        self._prev_msg_count = len(self.state.messages)
        return resp

    def intervene(self, intervention_content: str) -> dict:
        """Teacher intervention"""
        from .evaluator_node import evaluate_intervention
        return evaluate_intervention(self.state, intervention_content)

    def get_status(self) -> dict:
        return self.state.to_summary_dict()

    def get_metrics(self) -> dict:
        return self._get_metrics()

    def _get_metrics(self) -> dict:
        return {
            "bullying_intensity": self.state.bullying_intensity,
            "victim_distress": self.state.victim_distress,
            "bystander_intervention": self.state.bystander_intervention,
            "round": self.state.round,
            "finished": self.state.finished,
            "termination_reason": self.state.termination_reason,
        }


def create_runner(
    level: int = 2,
    max_rounds: int = 40,
    use_llm: bool = True,
    config: dict = None,
    session_id: str = None,
    scenario: dict = None,
) -> MultiAgentRunner:
    return MultiAgentRunner(
        level=level,
        max_rounds=max_rounds,
        use_llm=use_llm,
        config=config,
        session_id=session_id,
        scenario=scenario,
    )
