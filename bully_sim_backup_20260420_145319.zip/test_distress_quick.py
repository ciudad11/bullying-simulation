# -*- coding: utf-8 -*-
import requests
import json

base = 'http://localhost:5000'

# 创建session
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': False})
print(f'创建session: {r.status_code}')
data = r.json()
sid = data.get('session_id')
s = data.get('status', {})
print(f'初始状态: B={s.get("bullying_intensity",0):.1%} V={s.get("victim_distress",0):.1%}')

# 运行几轮
for i in range(10):
    r2 = requests.post(f'{base}/api/session/{sid}/run')
    d = r2.json()
    s2 = d.get('status', {})
    b = s2.get('bullying_intensity', 0)
    v = s2.get('victim_distress', 0)
    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        content = last.get('content','')[:40]
        sender = last.get('sender','')
        print(f'轮{i+1}: B={b:.1%} V={v:.1%} | [{sender}] {content}...')
    if d.get('done'):
        print(f'结束: {d.get("auto_end_reason","")}')
        break

# 干预测试
print('\n测试干预...')
r3 = requests.post(f'{base}/api/session/{sid}/intervene', json={
    'content': '思远，这不是你的错，老师会保护你的。陈浩，请立刻停止这种行为。'
})
iv = r3.json()
print(f'干预结果: quality={iv.get("quality_score",0):.2f} B={iv.get("bullying_intensity",0):.1%} V={iv.get("victim_distress",0):.1%}')

# 再运行几轮看恢复
for i in range(5):
    r4 = requests.post(f'{base}/api/session/{sid}/run')
    d = r4.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)
    print(f'干预后轮{i+1}: B={b:.1%} V={v:.1%}')
    if d.get('done'):
        break
