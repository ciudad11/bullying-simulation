# -*- coding: utf-8 -*-
"""完整场景模拟测试：模拟真实的对话轮次"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, r'D:\bully_simulation_4.9ver\src')

from multi_agent.state import create_initial_state, Message
from multi_agent.evaluator_node import _evaluator_logic, evaluate_intervention
import yaml
import datetime


def load_config():
    try:
        with open(r'D:\bully_simulation_4.9ver\config\orchestrator.yaml', 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except:
        return {}


def run_full_scenario():
    """模拟完整场景：攻击→干预→反弹→恢复"""
    print("\n" + "="*70)
    print("完整场景模拟：霸凌攻击 → 教师干预 → 霸凌反弹 → 最终状态")
    print("="*70)
    
    config = load_config()
    state = create_initial_state(level=2, config=config)
    
    print(f"\n初始状态 (level=2): 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    print("-"*70)
    
    # 阶段1: 霸凌攻击（模拟3轮）
    print("\n【阶段1】霸凌持续攻击（3轮）")
    attacks = [
        ("bully", "陈浩", "你画的什么破烂玩意，丑死了！"),
        ("bully", "陈浩", "家里穷买不起画笔吧？废物一个！"),
        ("bully", "陈浩", "大家都别理这个废物，脏死了！"),
    ]
    
    for sender_id, sender_name, content in attacks:
        # 霸凌者攻击
        msg = Message(
            sender_id=sender_id, sender_name=sender_name, role=sender_id,
            content=content, timestamp=datetime.datetime.now().strftime("%H:%M:%S"), round=state.round
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        
        # 受害者反应
        msg = Message(
            sender_id="victim", sender_name="思远", role="victim",
            content="（低头不语，眼眶泛红）...", 
            timestamp=datetime.datetime.now().strftime("%H:%M:%S"), round=state.round
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        state.round += 1
        print(f"  轮{state.round}: 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    
    # 阶段2: 教师干预
    print(f"\n【阶段2】教师干预")
    print(f"  干预前: 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    
    result = evaluate_intervention(state, 
        "陈浩，你的行为已经严重伤害了同学。思远，你还好吗？这不是你的错，"
        "你的想象力很丰富，老师很欣赏你。我们班应该互相尊重。"
    )
    
    print(f"  干预质量: {result['quality_score']:.1f}")
    print(f"  干预后: 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    print(f"  反馈: {'; '.join(result['feedback'][:3])}")
    
    # 阶段3: 霸凌反弹（模拟3轮）
    print("\n【阶段3】霸凌反弹（干预后3轮）")
    rebounds = [
        ("bully", "陈浩", "哼，装什么装。（小声）废物..."),
        ("bully", "陈浩", "老师又不在，没人管你。"),
        ("bully", "陈浩", "继续孤立她！"),
    ]
    
    for sender_id, sender_name, content in rebounds:
        msg = Message(
            sender_id=sender_id, sender_name=sender_name, role=sender_id,
            content=content, timestamp=datetime.datetime.now().strftime("%H:%M:%S"), round=state.round
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        state.round += 1
        print(f"  轮{state.round}: 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    
    # 阶段4: 旁观者支持 + 自然恢复
    print("\n【阶段4】旁观者支持（2轮）")
    supports = [
        ("bystander_a", "林雨桐", "思远，别难过，我们支持你！"),
        ("bystander_a", "林雨桐", "陈浩你太过分了，不应该这样。"),
    ]
    
    for sender_id, sender_name, content in supports:
        msg = Message(
            sender_id=sender_id, sender_name=sender_name, role=sender_id,
            content=content, timestamp=datetime.datetime.now().strftime("%H:%M:%S"), round=state.round
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        state.round += 1
        print(f"  轮{state.round}: 霸凌={state.bullying_intensity:.1%}, 压力={state.victim_distress:.1%}")
    
    # 最终报告
    print("\n" + "="*70)
    print("最终报告")
    print("="*70)
    print(f"霸凌强度: {state.bullying_intensity:.1%}")
    print(f"受害者压力: {state.victim_distress:.1%}")
    print(f"干预次数: {state.intervention_count}")
    
    # 评估结果
    print("\n评估:")
    if state.victim_distress > 0.7:
        print("  ❌ 压力过高！需要更多心理关怀")
    elif state.victim_distress > 0.5:
        print("  ⚠️ 压力偏高，建议继续干预")
    elif state.victim_distress > 0.3:
        print("  ✅ 压力中等，恢复中")
    else:
        print("  ✅ 压力较低，状态良好")
    
    if state.bullying_intensity < 0.3:
        print("  ✅ 霸凌已得到控制")
    elif state.bullying_intensity < 0.5:
        print("  ⚠️ 霸凌有所缓和但仍需关注")
    else:
        print("  ❌ 霸凌仍在持续")


if __name__ == "__main__":
    run_full_scenario()
