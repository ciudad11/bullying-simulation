"""
LLM 客户端 - 封装 MiniMax API 调用
使用 LangChain 的 ChatOpenAI 兼容接口
"""

import os
import time
import json
from typing import Optional, List, Dict, Any
from pathlib import Path

# LangChain imports
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage


# ============================================================
# API Key 获取（复用 app.py 的逻辑）
# ============================================================

def get_api_key() -> str:
    """获取 MiniMax API Key，优先从环境变量读取"""
    # 1. 尝试环境变量
    api_key = os.environ.get("MINIMAX_API_KEY", "") or os.environ.get("OPENCLAW_API_KEY", "")
    if api_key:
        return api_key

    # 2. 从 .env 文件读取
    env_path = Path(__file__).parent.parent.parent / ".env"
    if env_path.exists():
        try:
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, val = line.split("=", 1)
                        if key.strip() in ("MINIMAX_API_KEY", "OPENCLAW_API_KEY"):
                            if val.strip():
                                return val.strip()
        except Exception:
            pass

    # 3. 从 OpenClaw 配置读取
    try:
        openclaw_config = Path.home() / ".openclaw" / "openclaw.json"
        if openclaw_config.exists():
            with open(openclaw_config, "r", encoding="utf-8") as f:
                config = json.load(f)
            providers = config.get("models", {}).get("providers", {})
            for provider_name in ["minimax-cn", "minimax"]:
                if provider_name in providers:
                    key = providers[provider_name].get("apiKey", "")
                    if key:
                        return key
    except Exception:
        pass

    return ""


# ============================================================
# MiniMax API 端点配置
# ============================================================

MINIMAX_BASE_URL = "https://api.minimaxi.com/v1"
MINIMAX_MODEL = "MiniMax-M2.7"


class MiniMaxChat(ChatOpenAI):
    """
    MiniMax Chat 模型
    继承自 ChatOpenAI，复用其接口，但配置 MiniMax 特定参数
    """

    def __init__(
        self,
        api_key: str,
        model: str = "MiniMax-M2.7",
        temperature: float = 0.8,
        max_tokens: int = 300,
        timeout: int = 30,
        **kwargs
    ):
        super().__init__(
            model=model,
            openai_api_key=api_key,
            openai_api_base=MINIMAX_BASE_URL,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout,
            **kwargs
        )


# ============================================================
# LLM Client 封装
# ============================================================

class LLMClient:
    """
    统一的 LLM 客户端
    支持 MiniMax，提供对话、补全等接口
    """

    def __init__(
        self,
        api_key: str = None,
        model: str = "MiniMax-M2.7",
        temperature: float = 0.8,
        max_tokens: int = 800,
    ):
        self.api_key = api_key or get_api_key()
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._llm: Optional[MiniMaxChat] = None

    @property
    def llm(self) -> MiniMaxChat:
        if self._llm is None:
            if not self.api_key:
                raise ValueError("API Key 未设置")
            self._llm = MiniMaxChat(
                api_key=self.api_key,
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
        return self._llm

    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = None,
        max_tokens: int = None,
    ) -> str:
        """
        对话接口

        Args:
            messages: [{"role": "user/assistant/system", "content": "..."}]
            temperature: 温度参数
            max_tokens: 最大token数

        Returns:
            模型回复文本
        """
        if not self.api_key:
            return self._fallback_response()

        try:
            # 转换为 LangChain 消息格式
            langchain_messages = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")

                if role == "system":
                    langchain_messages.append(SystemMessage(content=content))
                elif role == "assistant":
                    langchain_messages.append(AIMessage(content=content))
                else:
                    langchain_messages.append(HumanMessage(content=content))

            # 调用模型
            llm_params = {}
            if temperature is not None:
                llm_params["temperature"] = temperature
            if max_tokens is not None:
                llm_params["max_tokens"] = max_tokens

            response = self.llm.invoke(langchain_messages, **llm_params)
            return response.content if hasattr(response, "content") else str(response)

        except Exception as e:
            print(f"[LLMClient] API调用失败: {e}")
            return self._fallback_response()

    def chat_with_langchain(
        self,
        messages: List[BaseMessage],
        temperature: float = None,
    ) -> str:
        """使用 LangChain 消息格式对话"""
        if not self.api_key:
            return self._fallback_response()

        try:
            llm_params = {}
            if temperature is not None:
                llm_params["temperature"] = temperature
            response = self.llm.invoke(messages, **llm_params)
            return response.content if hasattr(response, "content") else str(response)
        except Exception as e:
            print(f"[LLMClient] API调用失败: {e}")
            return self._fallback_response()

    def _fallback_response(self) -> str:
        """API 不可用时的默认回复"""
        return "[LLM暂时不可用，请检查API配置]"


# ============================================================
# 预设回复库（作为兜底）
# ============================================================

PRESET_RESPONSES = {
    "bully": {
        1: ["这画得也太丑了吧,哈哈哈!", "切,有什么了不起的。"],
        2: ["哈哈哈,思远你这画的是什么东西啊?", "穷鬼还画画,真是可笑!"],
        3: ["哈哈哈哈,思远你看看你那穷酸样!", "就你还想画画?你家买得起颜料吗?"],
        4: ["思远你就是班级里的垃圾!", "穷逼还想跟我们一个班?滚远点!"],
        5: ["思远你怎么不去死啊?活着浪费空气!", "你这种废物就不该存在!"],
    },
    "victim": {
        1: ["(小声)我...我没有...", "(低着头不说话)"],
        2: ["(眼眶泛红)我真的画了很久...", "(沉默,低下头)"],
        3: ["(忍不住眼泪)我没有...我没有做错什么...", "(小声哭泣)求你们别说了..."],
        4: ["(眼泪止不住)为什么...为什么总是我...", "(无声哭泣,整个人发抖)"],
        5: ["(无声落泪,不敢看任何人)", "(蜷缩在座位上)"],
    },
    "bystander_a": {
        1: ["陈浩,你这样说有点过分了吧。", "思远的画挺好的啊,我觉得很有想象力。"],
        2: ["陈浩,你过了!", "思远别理他们,你的画真的很棒。"],
        3: ["够了!陈浩你太过分了!", "思远,他们说的不对,别往心里去。"],
        4: ["陈浩!你太过分了!", "老师说过不能欺负同学,你这样是霸凌!"],
        5: ["陈浩你这个行为是犯罪你知道吗!", "必须告诉老师!"],
    },
    "bystander_b": {
        1: ["(跟着笑)哈哈哈...", "好像是有点好笑..."],
        2: ["是啊是啊,有点土...", "(跟着起哄)"],
        3: ["(有点犹豫)不过这么说确实...", "(附和)是啊是啊..."],
        4: ["(小声)好像有点过分了...", "(不安地挪动)"],
        5: ["(小声)我觉得...是不是太过分了...", "(看向老师方向)"],
    },
}


def get_preset_response(agent_id: str, level: int) -> str:
    """获取预设回复"""
    responses = PRESET_RESPONSES.get(agent_id, {}).get(level, ["..."])
    import random
    return random.choice(responses)


def check_api_available() -> tuple[bool, str]:
    """检查 API 是否可用"""
    api_key = get_api_key()
    if not api_key:
        return False, "未找到 API Key"
    try:
        client = LLMClient(api_key)
        # 简单测试调用
        response = client.chat([
            {"role": "user", "content": "你好"}
        ], max_tokens=10)
        return True, "API 可用"
    except Exception as e:
        return False, f"API 测试失败: {e}"
