import requests
import json

# Test 1: Create a new session
print('=== Test 1: Create Session ===')
resp = requests.post('http://127.0.0.1:5000/api/session', json={'level': 2, 'use_llm': False})
print(f'Status: {resp.status_code}')
data = resp.json()
print(f"Session ID: {data.get('session_id')}")
print(f"Level: {data.get('level')}")
session_id = data.get('session_id')

# Test 2: Run first round
print('\n=== Test 2: Run Round 1 ===')
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
data = resp.json()
print(f"Done: {data.get('done')}")
print(f"Auto ended: {data.get('auto_ended')}")
print(f"Messages count: {len(data.get('messages', []))}")
for msg in data.get('messages', []):
    print(f"  - {msg.get('sender')}: {msg.get('content')[:50]}...")

# Test 3: Run second round
print('\n=== Test 3: Run Round 2 ===')
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
data = resp.json()
print(f"Done: {data.get('done')}")
print(f"Messages count: {len(data.get('messages', []))}")
for msg in data.get('messages', []):
    print(f"  - {msg.get('sender')}: {msg.get('content')[:50]}...")

# Test 4: Run third round
print('\n=== Test 4: Run Round 3 ===')
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
data = resp.json()
print(f"Done: {data.get('done')}")
print(f"Messages count: {len(data.get('messages', []))}")
for msg in data.get('messages', []):
    print(f"  - {msg.get('sender')}: {msg.get('content')[:50]}...")

# Test 5: Send intervention
print('\n=== Test 5: Send Intervention ===')
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/intervene', 
                     json={'content': '同学们，我们应该友好相处'})
data = resp.json()
print(f"Intervention sent")
print(f"Message sender: {data.get('message', {}).get('sender')}")
print(f"Message content: {data.get('message', {}).get('content')}")

# Test 6: Run round after intervention
print('\n=== Test 6: Run Round After Intervention ===')
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
data = resp.json()
print(f"Done: {data.get('done')}")
print(f"Messages count: {len(data.get('messages', []))}")
for msg in data.get('messages', []):
    print(f"  - {msg.get('sender')}: {msg.get('content')[:50]}...")

print('\n=== All tests completed ===')
