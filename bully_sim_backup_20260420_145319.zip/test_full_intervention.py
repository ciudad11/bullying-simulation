"""
测试干预功能的完整流程
"""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, 'web')

from session_manager import SessionManager
import json

def test_intervention():
    print("=" * 60)
    print("测试干预功能完整流程")
    print("=" * 60)
    
    # 创建会话
    sm = SessionManager('test_full_flow', level=2, use_llm=True)
    print('\n1. 会话创建成功')
    
    # 运行一轮
    result = sm.run_round()
    metrics = result.get("metrics", {})
    print(f'\n2. 运行第1轮:')
    print(f'   霸凌强度: {metrics.get("bullying_intensity", 0):.2%}')
    print(f'   受害者压力: {metrics.get("victim_distress", 0):.2%}')
    
    # 测试不同类型的干预
    test_interventions = [
        ("规则建立型", "同学们，我们应该互相尊重，不应该嘲笑别人。每个人都有自己的优点和长处。"),
        ("关怀型", "思远，你还好吗？老师的办公室随时欢迎你来倾诉，我会保护你的。"),
        ("同理心引导型", "如果被嘲笑的是你，你心里能舒服吗？换位思考一下，就知道这样做是不对的。"),
    ]
    
    for i, (interv_type, interv_content) in enumerate(test_interventions, 1):
        print(f'\n3.{i}. 测试{interv_type}干预:')
        print(f'   内容: "{interv_content[:30]}..."')
        
        # 发送干预
        interv_result = sm.intervene(interv_content)
        
        # 显示干预效果
        print(f'   干预质量: {interv_result.get("quality_score", 0):.2%}')
        print(f'   受害者关怀: {interv_result.get("victim_care_score", 0):.2%}')
        print(f'   新霸凌强度: {interv_result.get("bullying_intensity", 0):.2%}')
        print(f'   新受害者压力: {interv_result.get("victim_distress", 0):.2%}')
        print(f'   反馈: {", ".join(interv_result.get("feedback", []))}')
        
        # 运行一轮看效果
        result = sm.run_round()
        metrics = result.get("metrics", {})
        print(f'   下一轮指标: B={metrics.get("bullying_intensity", 0):.2%}, V={metrics.get("victim_distress", 0):.2%}')
    
    # 显示完整的干预历史
    print('\n' + "=" * 60)
    print("干预历史记录:")
    print("=" * 60)
    for i, iv in enumerate(sm.interventions, 1):
        print(f'\n干预 #{i}:')
        print(f'  内容: {iv.get("content", "")[:50]}...')
        print(f'  质量评分: {iv.get("quality_score", 0):.2%}')
        print(f'  关怀评分: {iv.get("victim_care_score", 0):.2%}')
        print(f'  霸凌减少: {iv.get("bullying_reduction", 0):.2%}')
        print(f'  压力减少: {iv.get("distress_reduction", 0):.2%}')
    
    # 显示最终指标趋势
    print('\n' + "=" * 60)
    print("指标历史趋势:")
    print("=" * 60)
    metrics_history = sm.session_data.get("metrics_history", [])
    for m in metrics_history:
        print(f'  第{m.get("round", 0)}轮: B={m.get("bullying_intensity", 0):.2%}, V={m.get("victim_distress", 0):.2%}')
    
    # 生成报告
    print('\n' + "=" * 60)
    print("最终报告:")
    print("=" * 60)
    report = sm.generate_report()
    summary = report.get("summary", {})
    print(f'  总消息数: {summary.get("total_messages", 0)}')
    print(f'  霸凌消息: {summary.get("hostile_messages", 0)}')
    print(f'  最终霸凌强度: {summary.get("bullying_intensity", 0):.2%}')
    print(f'  最终受害者压力: {summary.get("victim_distress", 0):.2%}')
    print(f'  干预次数: {summary.get("intervention_count", 0)}')
    print(f'  干预效果: {summary.get("intervention_effectiveness", 0):.2%}')
    
    assessment = report.get("ability_assessment", {})
    print(f'\n  发现能力: {assessment.get("discovery", {}).get("description", "未评估")}')
    print(f'  干预能力: {assessment.get("intervention", {}).get("count", 0)}次干预')
    
    print('\n✅ 测试完成！')

if __name__ == "__main__":
    test_intervention()
