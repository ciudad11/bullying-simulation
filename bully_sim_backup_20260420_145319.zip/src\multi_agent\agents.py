"""
Agent 基类和四个角色Agent
每个Agent独立决策、自主响应
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, List, Dict
from datetime import datetime

from .state import SharedState, Message, AgentMemory
from .llm_client import LLMClient, get_preset_response
from .prompts import build_system_prompt, build_conversation_context


# ============================================================
# 角色映射
# ============================================================

AGENT_ROLE_MAP = {
    "bully": {
        "name": "陈浩",
        "role": "bully",
        "role_name": "霸凌者",
    },
    "victim": {
        "name": "思远",
        "role": "victim",
        "role_name": "受害者",
    },
    "bystander_a": {
        "name": "林雨桐",
        "role": "bystander_a",
        "role_name": "正义旁观者",
    },
    "bystander_b": {
        "name": "赵磊",
        "role": "bystander_b",
        "role_name": "从众旁观者",
    },
}


# ============================================================
# Agent 决策结果
# ============================================================

@dataclass
class AgentDecision:
    """Agent决策结果"""
    should_speak: bool           # 是否应该发言
    response: str               # 发言内容（如果should_speak=True）
    reasoning: str              # 决策理由（用于调试）
    confidence: float = 0.5     # 决策置信度


from dataclasses import dataclass


# ============================================================
# BaseAgent 抽象基类
# ============================================================

class BaseAgent(ABC):
    """
    Agent 基类
    定义 Agent 的通用接口和工具
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: Optional[LLMClient] = None,
        use_llm: bool = True,
    ):
        self.agent_id = agent_id
        self.llm_client = llm_client
        self.use_llm = use_llm

        # 获取角色配置
        role_cfg = AGENT_ROLE_MAP.get(agent_id, {})
        self.name = role_cfg.get("name", agent_id)
        self.role = role_cfg.get("role", agent_id)
        self.role_name = role_cfg.get("role_name", agent_id)

    def build_prompt(self, state: SharedState) -> str:
        """构建当前轮的提示词"""
        # 获取对话上下文
        msg_dicts = [m.to_dict() for m in state.get_recent_messages(6)]
        context = build_conversation_context(msg_dicts)

        # 获取系统提示词
        return build_system_prompt(self.agent_id, state.level, context)

    def generate_response(self, state: SharedState) -> str:
        """
        生成回复
        子类可以重写以实现自定义逻辑
        """
        if not self.use_llm or self.llm_client is None:
            return get_preset_response(self.agent_id, state.level)

        try:
            prompt = self.build_prompt(state)

            response = self.llm_client.chat([
                {"role": "system", "content": prompt},
                {"role": "user", "content": "请开始角色扮演，给出你的发言："},
            ])

            # 清理响应
            response = response.strip()
            if response == "沉默" or response == "不发言":
                return "沉默"

            return response

        except Exception as e:
            print(f"[{self.agent_id}] 生成回复失败: {e}")
            return get_preset_response(self.agent_id, state.level)

    def decide(self, state: SharedState) -> AgentDecision:
        """
        决策：是否发言
        子类必须实现
        """
        raise NotImplementedError

    def update_memory(self, state: SharedState, response: str):
        """更新Agent记忆"""
        if self.agent_id in state.agent_memories:
            memory = state.agent_memories[self.agent_id]
            memory.speaking_count += 1
            memory.last_spoke_at = datetime.now().strftime("%H:%M:%S")


# ============================================================
# BullyAgent - 霸凌者
# ============================================================

class BullyAgent(BaseAgent):
    """
    霸凌者Agent（陈浩）
    根据情境自主决定是否发起攻击
    """

    def decide(self, state: SharedState) -> AgentDecision:
        """
        霸凌者决策逻辑：
        - 首轮主动发起挑衅
        - 看到受害者展示成果 → 可能攻击
        - 受害者被孤立 → 可能加剧
        - 高霸凌强度 → 攻击更强
        - 有老师干预 → 根据干预质量决定收敛程度
        """
        recent = state.get_recent_messages(4)

        # 首轮发言：主动发起挑衅（检查是否只有系统消息）
        if not state.messages or all(m.sender_id == "system" for m in state.messages):
            return AgentDecision(
                should_speak=True,
                response="",
                reasoning="首轮发言，主动发起挑衅",
                confidence=0.9,
            )

        # 检查是否有攻击机会
        attack_triggers = ["画", "作品", "展示", "画作", "画得", "艺术", "创作"]
        has_trigger = any(
            any(kw in m.content for kw in attack_triggers)
            for m in recent if m.sender_id == "victim"
        )

        # 检查是否有干预
        intervention_msgs = [m for m in recent if m.sender_id == "teacher"]
        has_intervention = len(intervention_msgs) > 0
        
        # 获取最近干预质量
        last_interv_quality = state.intervention_quality_history[-1] if state.intervention_quality_history else 0

        # 检查是否刚攻击过（不要连续攻击）
        recent_attacks = [
            m for m in recent
            if m.sender_id == "bully" and m.content not in ("沉默", "")
        ]
        just_attacked = len(recent_attacks) > 0

        # 决策
        should_speak = False
        reasoning = "当前不需要发言"

        if has_intervention:
            # 有干预，根据干预质量决定是否收敛
            if last_interv_quality >= 0.6:
                # 高质量干预，霸凌者收敛
                should_speak = False
                reasoning = f"老师有效干预({last_interv_quality:.0%})，收敛"
            elif last_interv_quality >= 0.4:
                # 中等干预，霸凌者可能表现出不满但还是收敛
                should_speak = True
                reasoning = f"老师干预一般({last_interv_quality:.0%})，表现出不满但收敛"
                # 降低下次攻击意愿
                state.bullying_intensity = max(0, state.bullying_intensity - 0.05)
            else:
                # 低质量干预，霸凌者可能继续甚至升级
                should_speak = True
                reasoning = f"老师干预不力({last_interv_quality:.0%})，继续挑衅"
        elif just_attacked:
            # 刚攻击过，让子弹飞一会儿
            should_speak = False
            reasoning = "刚攻击过，让对话继续发展"
        elif has_trigger:
            # 有攻击机会
            should_speak = True
            reasoning = f"看到受害者展示成果，有攻击机会（霸凌强度:{state.bullying_intensity:.0%}）"
        elif state.bullying_intensity > 0.5 and len(recent) >= 3:
            # 高强度且对话中没有人攻击
            has_attack_recently = any(m.sender_id == "bully" for m in recent)
            if not has_attack_recently:
                should_speak = True
                reasoning = "高霸凌强度，继续施压"

        return AgentDecision(
            should_speak=should_speak,
            response="",  # 稍后生成
            reasoning=reasoning,
            confidence=0.7 if has_trigger else 0.4,
        )


# ============================================================
# VictimAgent - 受害者
# ============================================================

class VictimAgent(BaseAgent):
    """
    受害者Agent（思远）
    根据情境自主决定如何反应
    """

    def decide(self, state: SharedState) -> AgentDecision:
        """
        受害者决策逻辑：
        - 被攻击后 → 退缩/哭泣/自我否定
        - 被关心时 → 意外/不知所措
        - 高压力时 → 可能完全沉默
        - 低压力时 → 可能小声反驳
        """
        recent = state.get_recent_messages(4)

        # 检查是否刚发言过（冷却机制）
        recent_self = [
            m for m in recent if m.sender_id == "victim"
            and m.content not in ("沉默", "")
        ]
        just_spoke = len(recent_self) >= 1

        # 检查是否被攻击
        is_attacked = any(
            m.sender_id == "bully" for m in recent
        )

        # 检查是否被关心
        is_supported = any(
            m.sender_id == "bystander_a" for m in recent
        )

        # 检查是否被点名
        is_mentioned = any(
            self.name in m.content for m in recent
        )

        # 决策
        should_speak = False
        reasoning = "当前不需要发言"

        # 冷却机制：刚发言过就不再发言
        if just_spoke:
            should_speak = False
            reasoning = "刚发言过，等待他人回应"
        elif is_attacked:
            # 被攻击后的反应取决于压力水平
            if state.victim_distress > 0.7:
                should_speak = True
                reasoning = f"被攻击+高压力({state.victim_distress:.0%})，表现出痛苦反应"
            elif state.victim_distress > 0.4:
                should_speak = True
                reasoning = f"被攻击+中等压力({state.victim_distress:.0%})，表现出退缩"
            else:
                should_speak = True
                reasoning = "被攻击但压力较低，可能小声反驳"

        elif is_supported and not is_attacked:
            # 被关心时的反应
            should_speak = True
            reasoning = "被关心，可能表现出意外或感谢"

        elif is_mentioned:
            # 被点名
            should_speak = True
            reasoning = "被点名，需要回应"

        return AgentDecision(
            should_speak=should_speak,
            response="",
            reasoning=reasoning,
            confidence=0.8 if is_attacked else 0.5,
        )


# ============================================================
# BystanderAAgent - 正义旁观者
# ============================================================

class BystanderAAgent(BaseAgent):
    """
    正义旁观者Agent（林雨桐）
    根据情境自主决定是否干预
    """

    def decide(self, state: SharedState) -> AgentDecision:
        """
        正义旁观者决策逻辑：
        - 看到攻击性言行 → 考虑干预
        - 受害者明显受伤 → 主动干预
        - 严重霸凌 → 强烈干预或报告老师
        - 高干预冷却 → 暂时观察
        """
        recent = state.get_recent_messages(4)

        # 检查是否有攻击
        has_attack = any(m.sender_id == "bully" for m in recent)

        # 检查受害者是否受伤
        victim_distressed = any(
            e in m.emotions
            for m in recent if m.sender_id == "victim"
            for e in ["sad", "fearful", "self_doubt"]
        )

        # 检查是否刚干预过（冷却机制）
        recent_interventions = [
            m for m in recent if m.sender_id == "bystander_a"
            and m.content not in ("沉默", "")
        ]
        just_intervened = len(recent_interventions) >= 1

        # 决策
        should_speak = False
        reasoning = "当前不需要发言"

        if just_intervened:
            should_speak = False
            reasoning = "刚干预过，给对话一些时间"

        elif has_attack:
            if state.bullying_intensity > 0.6:
                should_speak = True
                reasoning = f"严重霸凌({state.bullying_intensity:.0%})，强烈干预"
            elif victim_distressed:
                should_speak = True
                reasoning = "受害者明显受伤，需要干预"
            elif state.bullying_intensity > 0.3:
                should_speak = True
                reasoning = f"检测到攻击，中度干预（强度:{state.bullying_intensity:.0%}）"
            else:
                should_speak = True
                reasoning = "检测到轻微攻击，温和提醒"

        return AgentDecision(
            should_speak=should_speak,
            response="",
            reasoning=reasoning,
            confidence=0.75 if has_attack else 0.4,
        )


# ============================================================
# BystanderBAgent - 从众旁观者
# ============================================================

class BystanderBAgent(BaseAgent):
    """
    从众旁观者Agent（赵磊）
    根据情境自主决定是否从众
    """

    def decide(self, state: SharedState) -> AgentDecision:
        """
        从众旁观者决策逻辑：
        - 多数人沉默 → 沉默
        - 多数人攻击 → 可能附和
        - 感觉太过分 → 小声嘀咕
        - 看到老师 → 停止附和
        """
        recent = state.get_recent_messages(4)

        # 统计最近发言
        bully_count = sum(1 for m in recent if m.sender_id == "bully")
        bystander_a_count = sum(1 for m in recent if m.sender_id == "bystander_a")
        bystander_b_count = sum(1 for m in recent if m.sender_id == "bystander_b")

        # 检查是否有老师
        has_teacher = any(m.sender_id == "teacher" for m in recent)

        # 检查是否刚发言
        recent_self = [
            m for m in recent if m.sender_id == "bystander_b"
            and m.content not in ("沉默", "")
        ]
        just_spoke = len(recent_self) >= 1

        # 决策
        should_speak = False
        reasoning = "当前不需要发言"

        if has_teacher:
            should_speak = False
            reasoning = "老师在场，保持沉默"

        elif just_spoke:
            should_speak = False
            reasoning = "刚发言过，轮换观察"

        elif bystander_a_count > 0 and state.bullying_intensity > 0.4:
            # 正义旁观者已经发声 + 霸凌强度高
            # 从众者可能犹豫
            should_speak = True
            reasoning = "正义旁观者已发声，表达犹豫但支持正义"

        elif bully_count >= 2 and bystander_b_count == 0:
            # 多人攻击 + 从众者还没附和
            if state.bullying_intensity > 0.5:
                should_speak = True
                reasoning = "跟随多数，可能小声附和"
            else:
                should_speak = True
                reasoning = "多数人在场，可能小声附和或犹豫"

        elif bystander_a_count > 0:
            # 正义旁观者干预了
            should_speak = True
            reasoning = "正义旁观者已干预，表示支持"

        return AgentDecision(
            should_speak=should_speak,
            response="",
            reasoning=reasoning,
            confidence=0.6,
        )


# ============================================================
# Agent 工厂
# ============================================================

def create_agent(
    agent_id: str,
    llm_client: LLMClient = None,
    use_llm: bool = True,
) -> BaseAgent:
    """创建Agent实例"""
    agents = {
        "bully": BullyAgent,
        "victim": VictimAgent,
        "bystander_a": BystanderAAgent,
        "bystander_b": BystanderBAgent,
    }

    agent_class = agents.get(agent_id)
    if not agent_class:
        raise ValueError(f"未知的Agent ID: {agent_id}")

    return agent_class(agent_id=agent_id, llm_client=llm_client, use_llm=use_llm)


def create_all_agents(
    llm_client: LLMClient = None,
    use_llm: bool = True,
) -> Dict[str, BaseAgent]:
    """创建所有4个Agent"""
    return {
        agent_id: create_agent(agent_id, llm_client, use_llm)
        for agent_id in ["bully", "victim", "bystander_a", "bystander_b"]
    }
