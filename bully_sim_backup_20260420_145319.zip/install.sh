#!/bin/bash

# 校园话语霸凌与教师干预实训系统 - macOS 安装脚本

echo "=========================================="
echo "  校园话语霸凌与教师干预实训系统"
echo "  macOS 依赖安装"
echo "=========================================="
echo ""

# 检查 Python 版本
if ! command -v python3 &> /dev/null; then
    echo "❌ 未检测到 Python 3"
    echo ""
    echo "请先安装 Python："
    echo "  方式一：访问 https://www.python.org/downloads/ 下载安装"
    echo "  方式二（推荐）：在终端运行：brew install python3"
    echo ""
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1)
if [ "$PYTHON_VERSION" -lt 3 ]; then
    echo "❌ Python 版本过低，需要 Python 3.9 或更高版本"
    exit 1
fi

echo "✅ Python 版本检查通过"

# 创建虚拟环境（可选）
echo ""
echo "正在安装依赖..."
python3 -m pip install --upgrade pip
pip3 install fastapi uvicorn pyyaml jinja2 --quiet

if [ $? -eq 0 ]; then
    echo "✅ 依赖安装成功！"
    echo ""
    echo "下一步：运行 bash start.sh 启动系统"
else
    echo "❌ 依赖安装失败，请检查网络连接"
    exit 1
fi
