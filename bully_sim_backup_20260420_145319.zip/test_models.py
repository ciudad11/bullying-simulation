import requests, json, os

api_key = os.environ.get("MINIMAX_API_KEY", "")
models = [
    "MiniMax-Text-01",
    "abab6.5s-chat",
    "abab6.5-chat",
    "MiniMax-M1",
    "MiniMax-Text-01-preview",
    "abab7-chat-preview",
    "MiniMax-Pro-128k",
]

for model in models:
    try:
        r = requests.post(
            "https://api.minimax.chat/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": "hi"}],
                "max_tokens": 5,
            },
            timeout=15,
        )
        data = r.json()
        if r.status_code == 200:
            content = data["choices"][0]["message"]["content"]
            print(f"OK: {model} -> {content}")
        else:
            err = data.get("error", {}).get("message", str(data))
            print(f"FAIL: {model} -> {err[:100]}")
    except Exception as e:
        print(f"ERR: {model} -> {e}")
