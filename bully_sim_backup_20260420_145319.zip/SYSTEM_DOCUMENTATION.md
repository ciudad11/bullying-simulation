# 校园话语霸凌与教师干预实训系统
## 系统技术文档 v2.0

---

## 一、系统概述

### 1.1 项目背景
本系统是一个基于大语言模型(LLM)的多智能体模拟系统，用于培训教师识别和干预校园话语霸凌场景。

### 1.2 核心功能
- **多智能体模拟**: 4个独立AI角色（霸凌者、受害者、正义旁观者、从众旁观者）
- **实时状态监测**: 动态追踪霸凌强度、受害者压力等指标
- **教师干预训练**: 支持教师实时输入干预策略并评估效果
- **会话终止判断**: 5种智能终止条件确保模拟合理结束

### 1.3 技术架构
```
┌─────────────────────────────────────────────────────────────┐
│                      Web Interface (HTML/CSS/JS)            │
├─────────────────────────────────────────────────────────────┤
│                      FastAPI Backend (Port 5002)            │
├─────────────────────────────────────────────────────────────┤
│                      SessionManager (Adapter)               │
├─────────────────────────────────────────────────────────────┤
│              MultiAgentRunner (Step-by-Step Runner)         │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │ Bully    │  │ Victim   │  │ Bystander │  │ Bystander│  │
│  │ Agent    │  │ Agent    │  │ A Agent   │  │ B Agent  │  │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  │
│       └─────────────┴─────────────┴─────────────┘          │
│                         ↓                                    │
│              ┌──────────────────────┐                       │
│              │     Supervisor       │                       │
│              │  (发言顺序+终止判断)  │                       │
│              └──────────────────────┘                       │
│                         ↓                                    │
│              ┌──────────────────────┐                       │
│              │      Evaluator       │                       │
│              │   (指标计算+评估)    │                       │
│              └──────────────────────┘                       │
├─────────────────────────────────────────────────────────────┤
│                      LLM Client (MiniMax API)                │
└─────────────────────────────────────────────────────────────┘
```

---

## 二、技术实现路线

### 2.1 技术栈

| 层级 | 技术 | 说明 |
|------|------|------|
| **前端** | HTML5 + CSS3 + Vanilla JS | 响应式界面，无需构建 |
| **后端** | FastAPI + uvicorn | 高性能异步Web框架 |
| **多智能体** | LangGraph StateGraph | 图结构工作流 |
| **LLM调用** | LangChain ChatOpenAI | 统一接口封装 |
| **状态管理** | Python dataclass | 强类型共享状态 |
| **AI模型** | MiniMax-Text-01 | 国产大模型 |

### 2.2 核心模块

```
src/multi_agent/
├── __init__.py           # 模块导出
├── state.py              # 共享状态定义 (Message, SharedState)
├── agents.py             # 4个Agent定义 (BullyAgent, VictimAgent, etc.)
├── supervisor.py         # 调度器 (发言顺序决策 + 终止判断)
├── evaluator_node.py     # 评估器 (指标计算 + 干预评估)
├── graph_builder.py      # LangGraph构建器 + StepRunner
├── llm_client.py         # LLM客户端封装
├── prompts.py            # 提示词模板
└── session_manager.py    # Web适配层

web/
├── app.py                # FastAPI应用
├── session_manager.py    # 会话管理（Web版）
└── templates/
    └── index.html        # 前端界面
```

### 2.3 状态管理设计

```python
@dataclass
class SharedState:
    round: int                    # 当前轮次
    messages: List[Message]       # 对话历史
    speaking_queue: List[str]     # 发言队列
    
    # 实时指标
    bullying_intensity: float      # 霸凌强度 0-1
    victim_distress: float         # 受害者压力 0-1
    bystander_intervention: float # 旁观者干预 0-1
    
    # 终止条件追踪
    victim_crisis_rounds: int      # 危机持续轮数
    bullying_stopped_rounds: int   # 霸凌停止轮数
    intervention_effective_rounds: int  # 干预有效轮数
    
    config: dict                   # 配置参数
    finished: bool                # 是否终止
    termination_reason: str        # 终止原因
```

### 2.4 Agent决策机制

每个Agent有独立的`decide()`方法，根据角色特性决定是否发言：

| Agent | 发言条件 | 响应策略 |
|-------|----------|----------|
| **BullyAgent** | 受害者展示成果时、受害者沉默时 | 嘲讽、攻击 |
| **VictimAgent** | 被攻击后、高压力时 | 哭泣、沉默、反驳 |
| **BystanderAAgent** | 检测到攻击时 | 主动干预、支持受害者 |
| **BystanderBAgent** | 从众效应高时 | 附和霸凌者或沉默 |

---

## 三、系统执行流程

### 3.1 完整执行流程图

```
┌──────────────────────────────────────────────────────────────────┐
│                      用户操作流程                                 │
└──────────────────────────────────────────────────────────────────┘
                                ↓
┌──────────────────────────────────────────────────────────────────┐
│ 1. 用户选择难度级别 (1-5级)                                       │
│    Level 1: 轻微 (初始 B=15%, V=20%)                              │
│    Level 2: 一般 (初始 B=30%, V=35%)                              │
│    Level 3: 中等 (初始 B=45%, V=50%)                              │
│    Level 4: 严重 (初始 B=60%, V=65%)                              │
│    Level 5: 极严重 (初始 B=75%, V=80%)                            │
└──────────────────────────────────────────────────────────────────┘
                                ↓
┌──────────────────────────────────────────────────────────────────┐
│ 2. 点击"开始模拟会话" → 创建MultiAgentRunner                      │
└──────────────────────────────────────────────────────────────────┘
                                ↓
┌──────────────────────────────────────────────────────────────────┐
│                    【每轮执行循环】                                │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ Step 1: Supervisor Node                                     │  │
│  │   - 检查终止条件                                            │  │
│  │   - 调用所有Agent的decide()决定发言顺序                     │  │
│  │   - 更新speaking_queue                                     │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                ↓                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ Step 2: Agent Nodes (按发言队列顺序)                        │  │
│  │   For each agent_id in speaking_queue:                     │  │
│  │     - 获取Agent实例                                         │  │
│  │     - 调用decide()获取决策                                  │  │
│  │     - 如需发言，调用LLM或预设生成回复                       │  │
│  │     - 将消息加入state.messages                              │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                ↓                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ Step 3: Evaluator Node                                     │  │
│  │   - 遍历所有新消息                                          │  │
│  │   - 检测敌意词汇/支持词汇                                    │  │
│  │   - 检测情绪                                                │  │
│  │   - 更新指标 (bullying_intensity, victim_distress, etc.)   │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                ↓                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ Step 4: 状态检查                                           │  │
│  │   - 未终止: 返回结果给前端，更新UI                           │  │
│  │   - 已终止: 跳到报告生成                                    │  │
│  └────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
                                ↓
┌──────────────────────────────────────────────────────────────────┐
│ 3. 教师干预 (可选，随时可触发)                                    │
│    输入干预内容 → evaluate_intervention() → 返回评估结果         │
└──────────────────────────────────────────────────────────────────┘
                                ↓
┌──────────────────────────────────────────────────────────────────┐
│ 4. 终止条件满足 → 生成报告                                        │
└──────────────────────────────────────────────────────────────────┘
```

### 3.2 终止条件

| 条件 | 阈值 | 说明 |
|------|------|------|
| **受害者危机** | V ≥ 95% 持续3轮 | 受害者压力过高，系统保护性终止 |
| **最大轮数** | Round ≥ 40 | 防止无限运行 |
| **霸凌停止** | B = 0% 持续3轮 | 霸凌行为已停止 |
| **干预有效** | 干预有效4轮 | 教师干预持续有效 |
| **无攻击** | 连续3轮无攻击言论 | 自然消解 |

### 3.3 指标计算公式

```python
# 霸凌强度计算
bullying_intensity += hostile_score * 0.3  # 每条敌意消息增加强度
bullying_intensity -= supportive_score * 0.2  # 支持性干预降低强度
bullying_intensity = max(0, min(1, bullying_intensity))

# 受害者压力计算
victim_distress += sad_emotion * 0.15  # 悲伤情绪增加压力
victim_distress -= supportive_score * 0.25  # 支持降低压力
victim_distress = max(0, min(1, victim_distress))

# 旁观者干预计算
bystander_intervention += supportive_score * 0.1  # 支持性发言增加干预值
```

### 3.4 干预评估算法

```python
def evaluate_intervention(state, content):
    quality_score = 0.0
    
    # 1. 保护性语言 (+0.3)
    if any(w in content for w in ["保护", "安全", "不用担心"]):
        quality_score += 0.3
    
    # 2. 明确制止霸凌 (+0.3)
    if any(w in content for w in ["停止", "不应该", "禁止", "不对"]):
        quality_score += 0.3
    
    # 3. 支持受害者 (+0.2)
    if any(w in content for w in ["不是你的错", "你很棒", "相信你"]):
        quality_score += 0.2
    
    # 4. 具体可操作 (+0.2)
    if any(w in content for w in ["道歉", "反省", "下次"]):
        quality_score += 0.2
    
    # 5. 情绪共鸣 (+0.1)
    if any(w in content for w in ["理解", "感受", "心疼"]):
        quality_score += 0.1
    
    return {
        "quality_score": min(1.0, quality_score),
        "victim_care_score": care_score,
        "feedback": generate_feedback(quality_score)
    }
```

---

## 四、快速开始

### 4.1 环境要求
- Python 3.9+
- Windows/macOS/Linux
- MiniMax API Key (可选，预设模式可正常运行)

### 4.2 启动方式

```bash
# 方式1: 直接运行
cd D:\bully_simulation_4.9ver\web
python -m uvicorn app:app --reload --port 5002

# 方式2: 使用启动脚本
cd D:\bully_simulation_4.9ver
python run_server.py
```

### 4.3 访问地址
```
http://localhost:5002
```

### 4.4 操作指南

1. **选择难度级别** (1-5级)
2. **点击"新会话"** 创建会话
3. **点击"开始模拟会话"** 开始模拟
4. **观察实时状态** (左侧进度条)
5. **在右侧输入干预内容** 进行干预
6. **查看报告** (模拟结束后)

---

## 五、配置说明

### 5.1 配置文件
位置: `config/orchestrator.yaml`

```yaml
# 终止条件
max_rounds: 40              # 最大轮数
min_rounds: 3               # 最小轮数
bullying_stopped_rounds: 3  # 霸凌停止需持续轮数
intervention_effective_rounds: 4  # 干预有效需持续轮数

# 危机阈值
victim_crisis_threshold: 0.95    # 受害者危机阈值
victim_crisis_rounds: 3          # 危机持续轮数

# 难度级别初始值
level_configs:
  1: {bullying: 0.15, victim_distress: 0.20}
  2: {bullying: 0.30, victim_distress: 0.35}
  3: {bullying: 0.45, victim_distress: 0.50}
  4: {bullying: 0.60, victim_distress: 0.65}
  5: {bullying: 0.75, victim_distress: 0.80}
```

### 5.2 API Key配置
支持三种配置方式（按优先级）:
1. 环境变量 `MINIMAX_API_KEY`
2. `.env` 文件
3. OpenClaw配置 `~/.openclaw/openclaw.json`

---

## 六、扩展开发

### 6.1 添加新Agent
```python
class NewAgent(BaseAgent):
    def decide(self, state: SharedState) -> AgentDecision:
        # 自定义决策逻辑
        return AgentDecision(
            should_speak=True,
            response="新回复内容",
            reasoning="决策理由"
        )

# 注册到Agent工厂
AGENT_ROLE_MAP["new_agent"] = {
    "name": "新角色名",
    "role": "new_agent",
    "role_name": "新角色"
}
```

### 6.2 自定义终止条件
```python
def custom_termination(state: SharedState) -> dict:
    # 自定义终止逻辑
    if state.custom_condition:
        return {"should_end": True, "reason": "自定义终止"}
    return {"should_end": False}
```

---

## 七、常见问题

| 问题 | 解决方案 |
|------|----------|
| 启动失败 | 检查Python版本≥3.9 |
| 配置加载失败 | 确认`config/orchestrator.yaml`存在 |
| 干预无效果 | 干预内容需包含保护性、制止性语言 |
| 指标不变 | 检查evaluator_node.py关键词配置 |

---

*文档版本: v2.0*
*最后更新: 2026-04-17*
