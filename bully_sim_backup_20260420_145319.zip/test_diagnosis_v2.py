# -*- coding: utf-8 -*-
"""详细诊断压力计算和干预问题 - 修复版"""
import requests
import json

base = 'http://localhost:5000'

print("=" * 70)
print("诊断测试 - 受害者压力异常上升问题 (v2)")
print("=" * 70)

# 创建session
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': False})
data = r.json()
sid = data['session_id']
s = data['status']
print(f'Session ID: {sid}')
print(f'初始状态: B={s.get("bullying_intensity",0):.1%} V={s.get("victim_distress",0):.1%}')

print("\n" + "=" * 70)
print("阶段1: 观察5轮压力变化")
print("=" * 70)

prev_b, prev_v = 0, 0
for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)

    b_delta = b - prev_b
    v_delta = v - prev_v

    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        role = last.get('role', '')
        content = last.get('content', '')[:50]
        print(f'轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')

    prev_b, prev_v = b, v

    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("阶段2: 执行干预并检查响应")
print("=" * 70)

# 使用明确的关怀语言
intervention_text = '思远，这不是你的错，老师看到了你的委屈。陈浩，你的行为已经构成了言语霸凌，需要立刻停止并向思远道歉。'
print(f'干预内容: {intervention_text}')

r = requests.post(f'{base}/api/session/{sid}/intervene', json={'content': intervention_text})
iv = r.json()
print(f'\n完整干预响应:')
print(json.dumps(iv, indent=2, ensure_ascii=False))

# 正确解析嵌套结构
intervention_data = iv.get('intervention', {})
print(f'\n干预评估详情:')
print(f'  quality_score: {intervention_data.get("quality_score", "N/A")}')
print(f'  victim_care_score: {intervention_data.get("victim_care_score", "N/A")}')
print(f'  bullying_intensity: {intervention_data.get("bullying_intensity", "N/A")}')
print(f'  victim_distress: {intervention_data.get("victim_distress", "N/A")}')
print(f'  feedback: {intervention_data.get("feedback", [])}')

# 检查session状态
status_data = iv.get('status', {})
print(f'\n当前session状态:')
print(f'  B={status_data.get("bullying_intensity", 0):.1%} V={status_data.get("victim_distress", 0):.1%}')

print("\n" + "=" * 70)
print("阶段3: 干预后观察压力恢复")
print("=" * 70)

for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)

    b_delta = b - prev_b
    v_delta = v - prev_v

    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        content = last.get('content', '')[:50]
        print(f'干预后轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')

    prev_b, prev_v = b, v

    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("诊断总结")
print("=" * 70)
print("关键问题检查:")
print(f"  1. 干预quality_score是否合理: {intervention_data.get('quality_score', 'N/A')}")
print(f"  2. 干预后B是否下降: {status_data.get('bullying_intensity', 'N/A')}")
print(f"  3. 干预后V是否下降: {status_data.get('victim_distress', 'N/A')}")
