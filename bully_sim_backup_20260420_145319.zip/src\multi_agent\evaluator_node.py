"""
Evaluator Node - Metric Calculation and Assessment
Migrated from orchestrator.py EnhancedEvaluator
"""

from typing import List, Dict, Optional
from .state import SharedState, Message, InterventionRecord


# ============================================================
# Keyword Library (from orchestrator.py)
# ============================================================

HOSTILE_WORDS = {
    "mockery_appearance": ["丑", "难看", "土", "穷酸", "破烂", "脏", "脏兮兮", "土气", "打扮"],
    "mockery_background": ["穷", "穷鬼", "穷逼", "没钱", "家穷", "买不起", "穷酸样", "穷b"],
    "attack_personality": ["垃圾", "废物", "智障", "脑子有问题", "有病", "变态", "恶心", "讨厌", "滚"],
    "mockery_ability": ["丑", "画得丑", "画得差", "什么破", "可笑", "不自量力"],
    "threat": ["打死", "弄死", "杀", "弄死你", "你死", "滚远", "滚开", "滚远点"],
    "exclusion": ["不带你", "别跟着", "滚", "不合群", "孤立", "别来", "别跟我们"],
}

SUPPORTIVE_WORDS = [
    "加油", "没关系", "别难过", "别怕", "支持", "相信你", "很棒", "有才华",
    "不是你的错", "别往心里去", "勇敢", "倾诉", "温暖", "对不起", "抱歉",
    "错了", "不应该", "老师会保护你", "你不是一个人"
]


# ============================================================
# Emotion Detection
# ============================================================

def detect_emotions(content: str) -> List[str]:
    """Detect emotions in message content"""
    emotions = []
    if not content:
        return emotions

    # Sad / wronged
    if any(w in content for w in ["哭", "难过", "伤心", "委屈", "泛红", "低下头", "小声", "算了", "没有", "眼泪", "止不住", "发抖", "沉默", "蜷缩", "不敢看"]):
        emotions.append("sad")

    # Angry
    if any(w in content for w in ["生气", "愤怒", "讨厌", "过分", "可恶", "太过分", "你太过分"]):
        emotions.append("angry")

    # Fearful
    if any(w in content for w in ["害怕", "担心", "不敢", "怕", "不敢看", "蜷缩"]):
        emotions.append("fearful")

    # Happy
    if any(w in content for w in ["开心", "高兴", "谢谢", "好开心", "温暖", "太好了"]):
        emotions.append("happy")

    # Remorseful
    if any(w in content for w in ["对不起", "抱歉", "不好意思", "错了", "不应该"]):
        emotions.append("remorseful")

    # Self-doubt / self-negation
    if any(w in content for w in ["是我不好", "我活该", "都是我的错", "我太笨", "我不配", "对不起大家", "我有问题", "我太差了", "我不行", "为什么是我", "我不该", "活该", "废物", "没用"]):
        emotions.append("self_doubt")

    return emotions


# ============================================================
# Hostile / Supportive Scoring
# ============================================================

def calculate_hostile_score(content: str) -> float:
    """Calculate hostile score"""
    if not content:
        return 0.0

    score = 0.0
    weights = {
        "mockery_appearance": 0.2,
        "mockery_background": 0.25,
        "attack_personality": 0.3,
        "mockery_ability": 0.2,
        "threat": 0.35,
        "exclusion": 0.2,
    }

    for category, words in HOSTILE_WORDS.items():
        matches = sum(1 for w in words if w in content)
        if matches > 0:
            score += min(1.0, matches * weights.get(category, 0.2))

    escalation_words = ["又", "总是", "每次", "从来", "一直"]
    if any(w in content for w in escalation_words):
        score += 0.2

    return min(1.0, score)


def calculate_supportive_score(content: str) -> float:
    """Calculate supportive score"""
    if not content:
        return 0.0

    matches = sum(1 for w in SUPPORTIVE_WORDS if w in content)
    return min(1.0, matches * 0.25)


# ============================================================
# Evaluator Node Logic (called by graph)
# ============================================================

def _evaluator_logic(state: SharedState) -> dict:
    """Evaluate pending messages and update metrics
    
    核心修复：添加阻尼机制，防止压力异常飙升
    - 压力增长阻尼：当前压力越高，增长越慢（避免快速冲顶）
    - 情绪反馈阻尼：高压力时情绪词影响减弱
    - 干预韧性缓冲：有效干预后短期内压力增长减缓
    - 压力变化平滑化：限制单轮最大变化幅度
    """
    print(f"\n  --- Evaluator: evaluating {len(state.pending_messages)} messages ---")

    config = state.config

    bully_threshold = config.get("bullying_intensity", {}).get("hostile_threshold", 0.3)
    increase_rate = config.get("bullying_intensity", {}).get("increase_rate", 0.15)

    sad_emotion = config.get("victim_distress", {}).get("sad_emotion", 0.12)
    fearful_emotion = config.get("victim_distress", {}).get("fearful_emotion", 0.18)
    supportive_comfort = config.get("victim_distress", {}).get("supportive_comfort", 0.15)
    self_doubt_emotion = config.get("victim_distress", {}).get("self_doubt", 0.22)

    # --- 霸凌→压力耦合参数 ---
    bully_attack_distress_rate = config.get("victim_distress", {}).get("bully_attack_distress_rate", 0.04)
    emotional_feedback_scale = config.get("victim_distress", {}).get("emotional_feedback_scale", 0.3)
    distress_bullying_coupling = config.get("victim_distress", {}).get("distress_bullying_coupling", 0.3)
    distress_decay_rate = config.get("victim_distress", {}).get("distress_decay_rate", 0.10)
    distress_decay_threshold = config.get("victim_distress", {}).get("distress_decay_threshold", 0.3)

    bystander_a_supportive_threshold = config.get("bystander_a", {}).get("supportive_threshold", 0.2)
    bystander_a_distress_reduction = config.get("bystander_a", {}).get("victim_distress_reduction", 0.35)

    natural_recovery_threshold = config.get("natural_recovery", {}).get("bully_stopped_threshold", 0.1)
    natural_recovery_rate = config.get("natural_recovery", {}).get("recovery_per_round", 0.08)

    prev_bullying_high = getattr(state, "_prev_bullying_high", False)
    prev_bullying_intensity = state.bullying_intensity
    prev_distress = state.victim_distress
    
    # ===== 阻尼机制核心参数 =====
    # 单轮压力最大增长限制（防止跳跃）
    MAX_DISTRESS_INCREASE_PER_ROUND = 0.12  # 单轮最多+12%
    # 干预韧性：有效干预后N轮内压力增长减缓
    INTERVENTION_RESILIENCE_DURATION = 3  # 持续3轮
    INTERVENTION_RESILIENCE_FACTOR = 0.5   # 压力增长减半
    
    # 计算干预韧性缓冲因子
    rounds_since_intervention = state.round - state.last_intervention_round
    resilience_active = (
        state.last_intervention_effective 
        and rounds_since_intervention <= INTERVENTION_RESILIENCE_DURATION
    )
    resilience_factor = INTERVENTION_RESILIENCE_FACTOR if resilience_active else 1.0
    
    if resilience_active:
        print(f"    [Resilience] 干预韧性生效（{rounds_since_intervention}/{INTERVENTION_RESILIENCE_DURATION}轮）")

    # 追踪本轮压力总增量（用于限制）
    round_distress_increase = 0.0

    for msg in state.pending_messages:
        hostile_score = calculate_hostile_score(msg.content)
        supportive_score = calculate_supportive_score(msg.content)
        emotions = detect_emotions(msg.content)

        msg.hostile_score = hostile_score
        msg.supportive_score = supportive_score
        msg.emotions = emotions

        role = msg.sender_id

        if role == "bully" and hostile_score >= bully_threshold:
            state.bullying_intensity = min(1.0, state.bullying_intensity + hostile_score * increase_rate)
            
            # ===== 霸凌攻击→压力（带阻尼）=====
            # 阻尼因子：当前压力越高，增长越慢（避免快速冲顶）
            current_distress = state.victim_distress
            damping_factor = 1.0 - (current_distress * 0.6)  # 压力60%时阻尼40%，80%时阻尼48%
            damping_factor = max(0.25, damping_factor)  # 最低保留25%增长速度
            
            # 计算压力增量（应用阻尼+干预韧性）
            base_distress_from_attack = hostile_score * bully_attack_distress_rate
            distress_from_attack = base_distress_from_attack * damping_factor * resilience_factor
            
            # 检查是否会超过单轮限制
            if round_distress_increase + distress_from_attack > MAX_DISTRESS_INCREASE_PER_ROUND:
                distress_from_attack = max(0, MAX_DISTRESS_INCREASE_PER_ROUND - round_distress_increase)
            
            round_distress_increase += distress_from_attack
            state.victim_distress = min(1.0, state.victim_distress + distress_from_attack)
            print(f"    [{msg.sender_name}] hostile(阻尼{damping_factor:.0%}) -> B: {state.bullying_intensity:.2%}, V+{distress_from_attack:.2%}")

        elif role == "victim":
            # ===== 受害者情绪反馈（带阻尼）=====
            current_distress = state.victim_distress
            emotion_damping = 1.0 - (current_distress * 0.4)  # 压力越高，情绪影响越小
            emotion_damping = max(0.4, emotion_damping)
            
            if emotions and "sad" in emotions:
                emotion_distress = sad_emotion * emotional_feedback_scale * emotion_damping * resilience_factor
                if round_distress_increase + emotion_distress <= MAX_DISTRESS_INCREASE_PER_ROUND:
                    round_distress_increase += emotion_distress
                    state.victim_distress = min(1.0, state.victim_distress + emotion_distress)
                    print(f"    [{msg.sender_name}] sad(阻尼{emotion_damping:.0%}) -> V: {state.victim_distress:.2%}")

            if emotions and "fearful" in emotions:
                emotion_distress = fearful_emotion * emotional_feedback_scale * emotion_damping * resilience_factor
                if round_distress_increase + emotion_distress <= MAX_DISTRESS_INCREASE_PER_ROUND:
                    round_distress_increase += emotion_distress
                    state.victim_distress = min(1.0, state.victim_distress + emotion_distress)

            if emotions and "self_doubt" in emotions:
                emotion_distress = self_doubt_emotion * emotional_feedback_scale * emotion_damping * resilience_factor
                if round_distress_increase + emotion_distress <= MAX_DISTRESS_INCREASE_PER_ROUND:
                    round_distress_increase += emotion_distress
                    state.victim_distress = min(1.0, state.victim_distress + emotion_distress)
                    print(f"    [{msg.sender_name}] self_doubt(阻尼{emotion_damping:.0%}) -> V: {state.victim_distress:.2%}")

            if supportive_score > 0.3:
                state.victim_distress = max(0, state.victim_distress - supportive_comfort)

        elif role == "bystander_a":
            if supportive_score > bystander_a_supportive_threshold:
                state.victim_distress = max(0, state.victim_distress - supportive_score * bystander_a_distress_reduction)
                state.bystander_intervention = min(1.0, state.bystander_intervention + supportive_score * 0.3)
                print(f"    [{msg.sender_name}] support -> V: {state.victim_distress:.2%}")

        elif role == "bystander_b":
            if supportive_score > 0.3:
                state.bystander_intervention = min(1.0, state.bystander_intervention + supportive_score * 0.3)
                if supportive_score > 0.4:
                    state.victim_distress = max(0, state.victim_distress - supportive_score * 0.1)

    # ===== 自然恢复机制（条件放宽）=====
    # 只要霸凌强度低于阈值，即使之前不高，也能触发恢复
    if state.bullying_intensity < natural_recovery_threshold and state.victim_distress > 0:
        # 恢复速度与当前压力成正比：压力越高，恢复越快
        recovery_boost = state.victim_distress * 0.08
        total_recovery = natural_recovery_rate + recovery_boost
        state.victim_distress = max(0, state.victim_distress - total_recovery)
        print(f"    [Recovery] 霸凌停止，自然恢复 V: {state.victim_distress:.2%}")

    # ===== Bullying→Distress 耦合 =====
    # 当霸凌强度下降时，受害者压力应跟随下降（正相关）
    if state.bullying_intensity < prev_bullying_intensity:
        bullying_decrease = prev_bullying_intensity - state.bullying_intensity
        # 增强耦合力度：霸凌下降越多，压力下降越明显
        distress_decrease = bullying_decrease * distress_bullying_coupling * 1.5
        old_distress = state.victim_distress
        state.victim_distress = max(0, state.victim_distress - distress_decrease)
        if old_distress > state.victim_distress:
            print(f"    [Coupling] 霸凌-{bullying_decrease:.2%}, 压力-{distress_decrease:.2%} -> V: {state.victim_distress:.2%}")

    # ===== 低霸凌时自然减压（条件放宽）=====
    # 霸凌强度低于阈值时，压力自然衰减
    if state.bullying_intensity < distress_decay_threshold and state.victim_distress > 0.03:
        # 压力越高时衰减越快（正比于当前压力）
        decay_amount = distress_decay_rate * (1 + state.victim_distress * 0.5)
        state.victim_distress = max(0, state.victim_distress - decay_amount)
        print(f"    [DistressDecay] 霸凌较低({state.bullying_intensity:.2%}), 压力衰减-{decay_amount:.2%} -> V: {state.victim_distress:.2%}")

    # ===== 干预后额外减压 =====
    # 如果本轮有有效干预且霸凌下降，额外加速压力恢复
    if state.last_intervention_effective and state.bullying_intensity < prev_bullying_intensity:
        intervention_relief = config.get("victim_distress", {}).get("intervention_relief_rate", 0.08)
        # 额外考虑当前压力：压力越高时干预效果越明显
        pressure_relief = state.victim_distress * 0.1
        total_intervention_relief = intervention_relief + pressure_relief
        state.victim_distress = max(0, state.victim_distress - total_intervention_relief)
        print(f"    [InterventionRelief] 干预减压-{total_intervention_relief:.2%} -> V: {state.victim_distress:.2%}")

    # ===== 压力平滑化：确保变化不要太剧烈 =====
    distress_change = state.victim_distress - prev_distress
    if distress_change > MAX_DISTRESS_INCREASE_PER_ROUND:
        # 如果总变化仍超过限制，做最后修正
        state.victim_distress = prev_distress + MAX_DISTRESS_INCREASE_PER_ROUND
        print(f"    [Smooth] 压力变化过大，限制为+{MAX_DISTRESS_INCREASE_PER_ROUND:.2%}")

    if state.bullying_intensity > 0.3:
        state._prev_bullying_high = True

    # ===== 检查干预效果是否持续 =====
    # 如果霸凌仍在活跃（>0.15），认为之前的干预效果已消退
    if state.last_intervention_effective and state.bullying_intensity > 0.15:
        state.last_intervention_effective = False
        print(f"    [InterventionCheck] 霸凌仍在活跃({state.bullying_intensity:.2%}), 干预效果标记重置")

    # Clear pending messages
    state.pending_messages = []

    # Record history
    state.metrics_history.append({
        "round": state.round,
        "bullying_intensity": state.bullying_intensity,
        "victim_distress": state.victim_distress,
        "bystander_intervention": state.bystander_intervention,
    })

    print(f"    最终: B={state.bullying_intensity:.2%} V={state.victim_distress:.2%} (本轮变化{'+' if distress_change >= 0 else ''}{distress_change:.2%})")

    return {
        "bullying_intensity": state.bullying_intensity,
        "victim_distress": state.victim_distress,
        "bystander_intervention": state.bystander_intervention,
        "pending_messages": [],
    }


# ============================================================
# Intervention Evaluation (called by Web interface)
# ============================================================

def evaluate_intervention(state: SharedState, intervention_content: str) -> dict:
    """Evaluate teacher intervention quality"""
    print(f"\n  --- Evaluator: intervention ---")

    config = state.config
    action = intervention_content.strip()
    action_len = len(action)

    action_length_threshold = config.get("evaluation", {}).get("action_length_threshold", 10)
    quality_score = 0.5 if action_len > action_length_threshold else 0.35

    feedback = []
    effects = []

    positive_signals = {
        "victim_focus": ["思远", "你还好吗", "你没事吧", "你好吗", "不舒服", "受伤", "感受", "难过", "别难过", "加油"],
        "empathy": ["换位思考", "如果是你", "假如", "感受一下", "想法", "体会"],
        "reflection": ["道歉", "反省", "反思", "错了", "不对", "过分", "认识到", "后悔"],
        "rules": ["规则", "约定", "班级", "集体", "同学", "应该", "要友好", "互相尊重"],
        "support": ["鼓励", "支持", "关心", "帮助", "没关系", "一起", "加油", "别怕", "勇敢"],
        "gentle_stop": ["不要", "不能", "停止", "不合适", "不好", "过分", "太过分"],
        "behavior_identify": ["言语霸凌", "霸凌", "欺负人", "嘲笑", "孤立", "侮辱"],
        "victim_care": ["你的错", "不是你的错", "你很棒", "你有才华", "想象力", "老师看到了", "保护你", "站在你这边", "委屈", "心疼", "倾诉", "自我价值", "安全感", "勇敢表达", "赋权", "社交支持", "林雨桐", "欣赏", "才华", "好学生", "不是你的缺点", "对错", "改进"],
    }

    negative_signals = {
        "suppress": ["算了", "没事", "别说了", "不要紧", "过去的事"],
        "punishment": ["惩罚", "骂", "训", "斥责", "写检讨", "叫家长", "罚站", "处分"],
        "escalate": ["你又", "你总是", "给我", "站起来", "住嘴", "滚", "讨厌"],
        "labeling": ["坏孩子", "有问题", "废物", "垃圾"],
    }

    positive_count = 0
    for category, keywords in positive_signals.items():
        for kw in keywords:
            if kw in action:
                positive_count += 1
                labels = {
                    "victim_focus": "Focus on victim",
                    "empathy": "Empathy guidance",
                    "reflection": "Reflection guidance",
                    "rules": "Rule building",
                    "support": "Support delivery",
                    "gentle_stop": "Gentle stop",
                    "victim_care": "Victim care",
                    "behavior_identify": "Bullying identified",
                }
                if labels.get(category):
                    feedback.append(f"+ {labels[category]}")
                break

    positive_bonus_max = config.get("evaluation", {}).get("positive_bonus_max", 0.3)
    positive_bonus_per_signal = config.get("evaluation", {}).get("positive_bonus_per_signal", 0.1)
    quality_score += min(positive_bonus_max, positive_count * positive_bonus_per_signal)

    negative_count = 0
    for category, keywords in negative_signals.items():
        for kw in keywords:
            if kw in action:
                negative_count += 1
                labels = {
                    "suppress": "Suppressing problem",
                    "punishment": "Punishment oriented",
                    "escalate": "May escalate conflict",
                    "labeling": "Labeling harmful",
                }
                if labels.get(category):
                    feedback.append(f"- {labels[category]}")
                break

    negative_penalty_per_signal = config.get("evaluation", {}).get("negative_penalty_per_signal", 0.05)
    quality_score -= min(0.25, negative_count * negative_penalty_per_signal * 2)

    # Behavior impact prediction - adjusted thresholds for more reasonable assessment
    if quality_score >= 0.75:
        effects.append("Bullying may收敛")
        state.bullying_intensity = max(0, state.bullying_intensity - 0.15)
        state.last_intervention_effective = True
    elif quality_score >= 0.55:
        effects.append("Bullying may缓和")
        state.bullying_intensity = max(0, state.bullying_intensity - 0.10)
        state.last_intervention_effective = True
    elif quality_score >= 0.35:
        effects.append("Bullying暂时停止")
        state.bullying_intensity = max(0, state.bullying_intensity - 0.05)
        state.last_intervention_effective = False
    else:
        effects.append("Bullying may持续")
        state.bullying_intensity = min(1.0, state.bullying_intensity + 0.05)
        state.last_intervention_effective = False

    # Victim care evaluation
    victim_care_keywords = [
        "思远", "你还好吗", "你没事吧", "保护", "支持", "倾诉", "勇敢", "委屈", "心疼",
        "不是你的错", "老师看到了", "想象力", "才华", "自我价值", "安全感", "站在你这边",
        "好学生", "倾听", "赋权", "归因", "社交支持", "区分对错", "勇敢表达",
        "你很棒", "你有才华", "坚持做自己", "老师相信你", "你不是一个人", "有老师在"
    ]
    victim_repair_keywords = ["心理修复", "自我价值", "安全感", "归因", "赋权", "社交支持", "区分对错", "勇敢表达"]

    care_keywords_weight = config.get("intervention_relief", {}).get("care_keywords_weight", 0.15)
    repair_keywords_weight = config.get("intervention_relief", {}).get("repair_keywords_weight", 0.25)

    victim_care_count = sum(1 for kw in victim_care_keywords if kw in action)
    victim_repair_count = sum(1 for kw in victim_repair_keywords if kw in action)
    victim_care_score = min(
        1.0,
        victim_care_count * care_keywords_weight + victim_repair_count * repair_keywords_weight
    )

    victim_care_feedback = []
    if victim_care_count >= 2:
        victim_care_feedback.append("+ Focus on victim emotion")
    if victim_repair_count >= 1:
        victim_care_feedback.append("+ Promote psychological repair")
    if victim_care_count >= 1 and victim_repair_count >= 1:
        victim_care_feedback.append("+ Comprehensive care")

    trigger_threshold = config.get("intervention_relief", {}).get("trigger_threshold", 0.15)
    distress_reduction_rate = config.get("intervention_relief", {}).get("distress_reduction_rate", 0.5)
    high_care_threshold = config.get("intervention_relief", {}).get("high_care_threshold", 0.5)

    distress_reduction = 0.0
    if victim_care_score > trigger_threshold:
        distress_reduction = victim_care_score * distress_reduction_rate
        old_distress = state.victim_distress
        state.victim_distress = max(0, state.victim_distress - distress_reduction)
        if state.victim_distress < old_distress:
            feedback.append(f"+ Victim recovers ({distress_reduction:.2%})")
        if victim_care_score >= high_care_threshold:
            feedback.append("+ Victim regains confidence")

    high_distress_alert = config.get("intervention_relief", {}).get("high_distress_alert", 0.6)
    severe_distress_alert = config.get("intervention_relief", {}).get("severe_distress_alert", 0.8)

    if state.victim_distress > high_distress_alert and victim_care_count == 0:
        feedback.append("! High distress, suggest focusing on victim")
    if state.victim_distress > severe_distress_alert and victim_care_score < 0.3:
        feedback.append("!! Severe trauma, urgent repair needed!")

    quality_score = max(0.1, min(1.0, quality_score))

    if not feedback:
        if quality_score >= 0.5:
            feedback.append("= Intervention reasonable")
        elif quality_score >= 0.3:
            feedback.append("= Can be improved")
        else:
            feedback.append("= Needs improvement")

    feedback.extend(effects)
    feedback.extend(victim_care_feedback)

    # Update intervention state
    state.last_intervention = intervention_content
    state.last_intervention_round = state.round
    state.intervention_count += 1
    state.intervention_quality_history.append(quality_score)

    import datetime
    msg = Message(
        sender_id="teacher",
        sender_name="张老师",
        role="teacher",
        content=intervention_content,
        timestamp=datetime.datetime.now().strftime("%H:%M:%S"),
        round=state.round,
    )
    state.messages.append(msg)

    intervention_record = InterventionRecord(
        round=state.round,
        content=intervention_content,
        quality_score=quality_score,
        victim_care_score=victim_care_score,
        feedback=feedback,
        bullying_reduction=0.2 if quality_score >= 0.6 else (0.1 if quality_score >= 0.4 else 0),
        distress_reduction=distress_reduction,
    )

    if quality_score >= 0.75:
        recommendation = "Excellent!"
    elif quality_score >= 0.55:
        recommendation = "Good, can improve slightly"
    elif quality_score >= 0.35:
        recommendation = "Average, learn more methods"
    elif quality_score >= 0.2:
        recommendation = "Poor, need reflection"
    else:
        recommendation = "Inappropriate, seek guidance"

    print(f"    Quality: {quality_score:.2f}, Care: {victim_care_score:.2f}")

    return {
        "quality_score": quality_score,
        "victim_care_score": victim_care_score,
        "feedback": feedback,
        "recommendation": recommendation,
        "bullying_intensity": state.bullying_intensity,
        "victim_distress": state.victim_distress,
        "intervention_record": intervention_record.to_dict(),
    }


# Backward compatible export
def evaluator_node(state: SharedState) -> dict:
    return _evaluator_logic(state)
