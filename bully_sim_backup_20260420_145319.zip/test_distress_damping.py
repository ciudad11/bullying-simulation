# -*- coding: utf-8 -*-
"""测试压力阻尼机制修复效果"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 添加项目路径
sys.path.insert(0, r'D:\bully_simulation_4.9ver\src')

from multi_agent.state import create_initial_state, Message
from multi_agent.evaluator_node import _evaluator_logic
import datetime


def test_distress_damping():
    """测试阻尼机制：压力增长应该有上限"""
    print("\n" + "="*60)
    print("测试1: 压力阻尼机制")
    print("="*60)
    
    # 加载配置
    import yaml
    config = {}
    try:
        with open(r'D:\bully_simulation_4.9ver\config\orchestrator.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
    except Exception as e:
        print(f"配置加载失败: {e}")
    
    # 创建初始状态（中等难度）
    state = create_initial_state(level=2, config=config)
    print(f"初始状态: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    # 模拟霸凌者攻击（高敌意）
    print("\n--- 模拟高强度霸凌攻击 ---")
    for i in range(5):
        msg = Message(
            sender_id="bully",
            sender_name="陈浩",
            role="bully",
            content="你真是废物垃圾，滚远点！",
            timestamp=datetime.datetime.now().strftime("%H:%M:%S"),
            round=state.round,
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        state.round += 1
        
        # 检查压力增长是否平滑
        if i > 0:
            change = state.victim_distress - prev_v
            print(f"  轮次{i}: 压力变化 = {'+' if change >= 0 else ''}{change:.2%}")
            if change > 0.15:  # 超过15%警告
                print(f"  ⚠️ 警告: 单轮压力变化过大!")
        prev_v = state.victim_distress
    
    print(f"\n最终: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    if state.victim_distress < 0.9:
        print("✅ 阻尼机制生效，压力未异常飙升")
    else:
        print("❌ 阻尼机制可能未生效，压力过高")


def test_intervention_resilience():
    """测试干预韧性：干预后短期内压力增长减缓"""
    print("\n" + "="*60)
    print("测试2: 干预韧性缓冲")
    print("="*60)
    
    import yaml
    config = {}
    try:
        with open(r'D:\bully_simulation_4.9ver\config\orchestrator.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
    except:
        pass
    
    state = create_initial_state(level=3, config=config)
    print(f"初始: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    # 模拟几轮攻击让压力上升
    print("\n--- 先进行3轮攻击 ---")
    for i in range(3):
        msg = Message(
            sender_id="bully",
            sender_name="陈浩",
            role="bully",
            content="你真没用废物",
            timestamp=datetime.datetime.now().strftime("%H:%M:%S"),
            round=state.round,
        )
        state.pending_messages.append(msg)
        _evaluator_logic(state)
        state.round += 1
    print(f"攻击后: V={state.victim_distress:.2%}")
    
    # 模拟教师干预
    print("\n--- 教师干预 ---")
    from multi_agent.evaluator_node import evaluate_intervention
    result = evaluate_intervention(state, "思远，你还好吗？老师很关心你。这不是你的错，你很有才华。陈浩，你的行为已经构成了言语霸凌，需要立刻停止。")
    print(f"干预质量: {result['quality_score']:.2f}")
    print(f"干预后: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    # 模拟霸凌反弹
    print("\n--- 模拟霸凌反弹（干预后3轮内应有韧性） ---")
    for i in range(5):
        msg = Message(
            sender_id="bully",
            sender_name="陈浩",
            role="bully",
            content="哼，真是装模作样，废物一个",
            timestamp=datetime.datetime.now().strftime("%H:%M:%S"),
            round=state.round,
        )
        state.pending_messages.append(msg)
        prev_v = state.victim_distress
        _evaluator_logic(state)
        state.round += 1
        change = state.victim_distress - prev_v
        print(f"  轮次{state.round-1}: V={state.victim_distress:.2%}, 变化={'+' if change >= 0 else ''}{change:.2%}")
    
    print(f"\n最终: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")


def test_recovery_coupling():
    """测试恢复耦合：霸凌下降时压力应跟随下降"""
    print("\n" + "="*60)
    print("测试3: 霸凌下降→压力下降耦合")
    print("="*60)
    
    import yaml
    config = {}
    try:
        with open(r'D:\bully_simulation_4.9ver\config\orchestrator.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
    except:
        pass
    
    state = create_initial_state(level=3, config=config)
    
    # 设置高压力
    state.bullying_intensity = 0.7
    state.victim_distress = 0.8
    print(f"初始: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    # 模拟有效的旁观者支持（降低霸凌）
    print("\n--- 模拟旁观者支持 ---")
    for i in range(4):
        msg = Message(
            sender_id="bystander_a",
            sender_name="林雨桐",
            role="bystander_a",
            content="思远，别难过，我们支持你！陈浩你太过分了，不应该这样对待同学。",
            timestamp=datetime.datetime.now().strftime("%H:%M:%S"),
            round=state.round,
        )
        state.pending_messages.append(msg)
        prev_b = state.bullying_intensity
        prev_v = state.victim_distress
        _evaluator_logic(state)
        state.round += 1
        print(f"  轮次{i+1}: B={state.bullying_intensity:.2%} ({prev_b-state.bullying_intensity:.2%}), V={state.victim_distress:.2%} ({prev_v-state.victim_distress:.2%})")
    
    print(f"\n最终: B={state.bullying_intensity:.2%}, V={state.victim_distress:.2%}")
    
    if state.victim_distress < 0.5:
        print("✅ 耦合机制生效，压力随霸凌下降")
    else:
        print("⚠️ 压力下降可能不够明显")


if __name__ == "__main__":
    print("\n" + "="*60)
    print("受害者压力阻尼机制测试")
    print("="*60)
    
    test_distress_damping()
    test_intervention_resilience()
    test_recovery_coupling()
    
    print("\n" + "="*60)
    print("测试完成")
    print("="*60)
