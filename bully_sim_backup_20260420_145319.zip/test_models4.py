import requests, json, os

api_key = os.environ.get("MINIMAX_API_KEY", "")
print(f"Key prefix: {api_key[:10]}...")

# Key finding: sk-cp- = Token Plan Key, needs minimaxi.com endpoint
# MiniMax-M2.7 is the latest model for Token Plan

endpoints_models = [
    # (endpoint, model_name, label)
    ("https://api.minimaxi.com/v1", "MiniMax-M2.7", "国内版 + M2.7"),
    ("https://api.minimaxi.com/v1", "MiniMax-M2.5", "国内版 + M2.5"),
    ("https://api.minimaxi.com/v1", "MiniMax-M1", "国内版 + M1"),
    ("https://api.minimaxi.com/v1", "MiniMax-Text-01", "国内版 + Text-01"),
    ("https://api.minimaxi.com/v1", "abab6.5s-chat", "国内版 + abab6.5s"),
    ("https://api.minimax.chat/v1", "MiniMax-M2.7", "国际版 + M2.7"),
    ("https://api.minimax.chat/v1", "MiniMax-M2.5", "国际版 + M2.5"),
    ("https://api.minimaxi.com/v1", "MiniMax-M1-80k", "国内版 + M1-80k"),
]

for url, model, label in endpoints_models:
    try:
        r = requests.post(
            f"{url}/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": "你好，用一句话介绍自己"}],
                "max_tokens": 50,
            },
            timeout=30,
        )
        data = r.json()
        if r.status_code == 200:
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            print(f"OK: [{label}] -> {content}")
        else:
            err = data.get("error", {}).get("message", str(data)[:200])
            print(f"FAIL: [{label}] ({r.status_code}) -> {err[:120]}")
    except Exception as e:
        print(f"ERR: [{label}] -> {e}")
