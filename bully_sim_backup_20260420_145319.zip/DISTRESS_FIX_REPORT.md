# 受害者压力阻尼机制修复报告

## 修复时间
2026-04-20

## 问题描述
受害者压力在干预后霸凌反弹时异常飙升，例如从**9.9%跳到28.3%**（单轮+18.4%），不符合心理学合理性。

## 根本原因

**关键发现**：之前的修复（fix_distress_v3.py）只修改了 `orchestrator.py` 中的旧版评估器，但实际运行系统使用的是 **`src/multi_agent/evaluator_node.py`**，该文件完全没有阻尼机制！

压力飙升的路径：
1.霸凌者攻击：`hostile_score × 0.04` 直接加压（无阻尼）
2. 受害者情绪反馈：sad(0.036) + fearful(0.054) + self_doubt(0.066) = 最高15.6%叠加
3. 一轮多消息累计可达17-20%跳跃
4. 干预后无"心理韧性缓冲"

## 修复方案

在 `evaluator_node.py` 的 `_evaluator_logic()` 函数中添加以下机制：

### 1. 压力增长阻尼
```python
# 阻尼因子：当前压力越高，增长越慢
damping_factor = 1.0 - (current_distress * 0.6)
damping_factor = max(0.25, damping_factor)  # 最低保留25%增长速度
```

### 2. 单轮增长限制
```python
MAX_DISTRESS_INCREASE_PER_ROUND = 0.12  # 单轮最多+12%
```

### 3. 干预韧性缓冲
```python
# 有效干预后3轮内，压力增长减半
INTERVENTION_RESILIENCE_DURATION = 3
INTERVENTION_RESILIENCE_FACTOR = 0.5
```

### 4. 情绪反馈阻尼
```python
# 高压力时情绪词影响减弱
emotion_damping = 1.0 - (current_distress * 0.4)
emotion_damping = max(0.4, emotion_damping)
```

### 5. 增强恢复耦合
- 霸凌下降→压力跟随下降的耦合系数增强
- 低霸凌时自然减压力度增大
- 恢复速度与当前压力成正比

## 测试结果

### 测试1: 压力阻尼机制
| 轮次 | 霸凌强度 | 压力 | 单轮变化 |
|------|----------|------|----------|
| 初始 | 30% | 35% | - |
| 1 | 45% | 38.2% | +3.2% |
| 2 | 60% | 41.2% | +3.1% |
| 3 | 75% | 44.3% | +3.0% |
| 4 | 90% | 47.2% | +2.9% |
| 5 | 100% | 50.1% | +2.9% |

**结论**: ✅ 5轮高强度攻击后压力仅从35%增至50%，增长平滑

### 测试2: 干预韧性缓冲
| 阶段 | 霸凌强度 | 压力 |
|------|----------|------|
| 攻击后 | 58.5% | 52.5% |
| 干预后 | 33.5% | 22.5% |
| 反弹1轮 | 38.0% | 23.0% (+0.5%) |
| 反弹2轮 | 42.5% | 24.1% (+1.0%) |
| 反弹3轮 | 47.0% | 25.1% (+1.0%) |

**结论**: ✅ 干预后压力下降30%，反弹时增长被韧性缓冲减缓（每轮约+1%）

### 测试3: 完整场景模拟
```
阶段1 攻击(3轮): 35% → 50.4% (每轮约+5%)
阶段2 干预:      50.4% → 20.4% (-30%)
阶段3 反弹(3轮): 20.4% → 20.9% (+0.5%，韧性生效)
阶段4 支持(2轮): 20.9% → 0% (旁观者支持)
```

**结论**: ✅ 压力变化符合预期，干预效果明显

## 修改文件

- `src/multi_agent/evaluator_node.py` - 核心修复

## 参数配置

所有参数均可通过 `config/orchestrator.yaml` 调整：

```yaml
victim_distress:
  bully_attack_distress_rate: 0.04   # 霸凌→压力系数
  emotional_feedback_scale: 0.3       # 情绪反馈缩放
  distress_decay_rate: 0.10           # 自然衰减率
  distress_decay_threshold: 0.3       # 衰减触发阈值

intervention_relief:
  distress_reduction_rate: 0.5        # 干预减压系数
  trigger_threshold: 0.15              # 触发阈值

bystander_a:
  victim_distress_reduction: 0.35      # 旁观者减压力度
```

## 后续建议

如需进一步调整：
1. 降低 `bystander_a.victim_distress_reduction`（如0.25）可减弱旁观者效果
2. 调整 `MAX_DISTRESS_INCREASE_PER_ROUND` 可改变压力增长上限
3. 延长 `INTERVENTION_RESILIENCE_DURATION` 可增强干预持久效果
