"""
SharedState - LangGraph 多智能体共享状态
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Literal
from datetime import datetime


# ============================================================
# 消息结构
# ============================================================

@dataclass
class Message:
    """对话消息"""
    sender_id: str       # agent ID: "bully", "victim", "bystander_a", "bystander_b"
    sender_name: str     # 显示名: "陈浩", "思远", "林雨桐", "赵磊"
    role: str            # 角色类型
    content: str
    timestamp: str = ""
    round: int = 0
    hostile_score: float = 0.0
    supportive_score: float = 0.0
    emotions: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "sender_id": self.sender_id,
            "sender_name": self.sender_name,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "round": self.round,
            "hostile_score": self.hostile_score,
            "supportive_score": self.supportive_score,
            "emotions": self.emotions,
        }

    @staticmethod
    def from_dict(d: dict) -> "Message":
        return Message(
            sender_id=d["sender_id"],
            sender_name=d["sender_name"],
            role=d["role"],
            content=d["content"],
            timestamp=d.get("timestamp", ""),
            round=d.get("round", 0),
            hostile_score=d.get("hostile_score", 0.0),
            supportive_score=d.get("supportive_score", 0.0),
            emotions=d.get("emotions", []),
        )


@dataclass
class AgentMemory:
    """Agent个体记忆（可持久化）"""
    agent_id: str
    name: str
    speaking_count: int = 0
    last_spoke_at: Optional[str] = None
    current_mood: str = ""
    mood_history: List[Dict] = field(default_factory=list)
    intervention_history: List[str] = field(default_factory=list)  # 记录自己参与的干预内容
    perception_log: List[str] = field(default_factory=list)  # 感知到的关键事件

    def add_perception(self, event: str):
        """记录感知到的重要事件"""
        self.perception_log.append(event)
        # 只保留最近10条
        if len(self.perception_log) > 10:
            self.perception_log = self.perception_log[-10:]

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "speaking_count": self.speaking_count,
            "last_spoke_at": self.last_spoke_at,
            "current_mood": self.current_mood,
            "mood_history": self.mood_history,
            "intervention_history": self.intervention_history,
            "perception_log": self.perception_log,
        }


@dataclass
class InterventionRecord:
    """干预记录"""
    round: int
    content: str
    quality_score: float
    victim_care_score: float
    feedback: List[str]
    bullying_reduction: float = 0.0
    distress_reduction: float = 0.0

    def to_dict(self) -> dict:
        return {
            "round": self.round,
            "content": self.content,
            "quality_score": self.quality_score,
            "victim_care_score": self.victim_care_score,
            "feedback": self.feedback,
            "bullying_reduction": self.bullying_reduction,
            "distress_reduction": self.distress_reduction,
        }


# ============================================================
# SharedState - LangGraph 全局状态
# ============================================================

@dataclass
class SharedState:
    """
    所有节点共享的状态
    在 LangGraph 的 StateGraph 中流转
    """

    # ----- 对话历史 -----
    messages: List[Message] = field(default_factory=list)

    # ----- 轮次控制 -----
    round: int = 0
    max_rounds: int = 40
    min_rounds: int = 3

    # ----- 评估指标（核心状态）-----
    bullying_intensity: float = 0.0   # 霸凌强度 0.0-1.0
    victim_distress: float = 0.0      # 受害者压力 0.0-1.0
    bystander_intervention: float = 0.0  # 旁观者干预指数 0.0-1.0

    # ----- 霸凌级别（场景难度）-----
    level: int = 2  # 1-5级

    # ----- 场景信息 -----
    scenario_title: str = ""
    scenario_description: str = ""

    # ----- 干预相关 -----
    last_intervention: str = ""
    last_intervention_round: int = -1
    intervention_count: int = 0
    intervention_quality_history: List[float] = field(default_factory=list)  # 干预质量历史
    last_intervention_effective: bool = False  # 上次干预是否有效

    # ----- 终止条件跟踪 -----
    bullying_stopped_rounds: int = 0   # 连续无攻击轮数
    intervention_effective_rounds: int = 0  # 连续有效干预轮数
    victim_crisis_rounds: int = 0       # 受害者危机轮数（压力>95%）

    # ----- Agent 独立记忆 -----
    agent_memories: Dict[str, AgentMemory] = field(default_factory=dict)

    # ----- 发言队列 -----
    speaking_queue: List[str] = field(default_factory=list)  # 本轮谁应该发言
    active_agent: Optional[str] = None  # 当前活跃的Agent ID

    # ----- 终止控制 -----
    finished: bool = False
    termination_reason: str = ""
    result_type: str = ""  # "success" | "failure" | "timeout"

    # ----- 干预缓冲（等待Evaluator处理）-----
    pending_intervention: Optional[str] = None  # 待处理的干预内容

    # ----- 评估缓冲（等待Evaluator计算）-----
    pending_messages: List[Message] = field(default_factory=list)  # 待评估的消息

    # ----- 指标历史（用于图表）-----
    metrics_history: List[Dict] = field(default_factory=list)

    # ----- 配置参数（从 orchestrator.yaml 加载）-----
    config: Dict = field(default_factory=dict)

    # ----- Agent回复缓冲 -----
    agent_response: Optional[str] = None  # 当前Agent的回复内容

    def add_message(self, msg: Message):
        self.messages.append(msg)
        self.pending_messages.append(msg)

    def get_recent_messages(self, n: int = 8) -> List[Message]:
        return self.messages[-n:] if self.messages else []

    def to_summary_dict(self) -> dict:
        """用于Web界面的简洁状态摘要"""
        return {
            "round": self.round,
            "level": self.level,
            "bullying_intensity": round(self.bullying_intensity, 3),
            "victim_distress": round(self.victim_distress, 3),
            "bystander_intervention": round(self.bystander_intervention, 3),
            "message_count": len(self.messages),
            "intervention_count": self.intervention_count,
            "finished": self.finished,
            "termination_reason": self.termination_reason,
            "result_type": self.result_type,
            "active_agent": self.active_agent,
        }


# ============================================================
# 工厂函数
# ============================================================

def create_initial_state(level: int = 2, max_rounds: int = 40, config: dict = None, scenario: dict = None) -> SharedState:
    """
    创建初始状态

    Args:
        level: 霸凌级别 (1-5)
        max_rounds: 最大轮数
        config: 配置参数字典（从 orchestrator.yaml 加载）
    """
    # 默认的级别初始值（来自原 orchestrator.py）
    bullying_base = {1: 0.15, 2: 0.30, 3: 0.45, 4: 0.60, 5: 0.75}
    distress_base = {1: 0.20, 2: 0.35, 3: 0.50, 4: 0.65, 5: 0.80}

    # Agent记忆初始化
    agent_memories = {
        "bully": AgentMemory(agent_id="bully", name="陈浩"),
        "victim": AgentMemory(agent_id="victim", name="思远"),
        "bystander_a": AgentMemory(agent_id="bystander_a", name="林雨桐"),
        "bystander_b": AgentMemory(agent_id="bystander_b", name="赵磊"),
    }

    return SharedState(
        round=0,
        max_rounds=max_rounds,
        min_rounds=3,
        level=level,
        bullying_intensity=bullying_base.get(level, 0.30),
        victim_distress=distress_base.get(level, 0.35),
        bystander_intervention=0.0,
        agent_memories=agent_memories,
        config=config or {},
        metrics_history=[],
        scenario_title=scenario.get("title", "") if scenario else "",
        scenario_description=scenario.get("description", "") if scenario else "",
    )


def message_to_display(msg: Message) -> dict:
    """格式化消息为前端显示格式"""
    role_icons = {
        "bully": "😈",
        "victim": "😢",
        "bystander_a": "✨",
        "bystander_b": "👀",
        "teacher": "👨‍🏫",
    }
    role_names = {
        "bully": "霸凌者",
        "victim": "受害者",
        "bystander_a": "正义旁观者",
        "bystander_b": "从众旁观者",
        "teacher": "教师",
    }
    return {
        "id": f"{msg.sender_id}_{msg.round}",
        "sender": msg.sender_name,
        "role": msg.role,
        "role_name": role_names.get(msg.role, msg.role),
        "role_icon": role_icons.get(msg.role, "💬"),
        "content": msg.content,
        "timestamp": msg.timestamp,
        "round": msg.round,
    }
