# -*- coding: utf-8 -*-
"""详细诊断压力计算和干预问题 - 修复版v3"""
import requests
import json
import sys

# 强制UTF-8输出
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

base = 'http://localhost:5000'

print("=" * 70)
print("诊断测试 - 受害者压力异常上升问题 (v3)")
print("=" * 70)

# 创建session
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': False})
data = r.json()
sid = data['session_id']
s = data['status']
print(f'Session ID: {sid}')
print(f'初始状态: B={s.get("bullying_intensity",0):.1%} V={s.get("victim_distress",0):.1%}')

print("\n" + "=" * 70)
print("阶段1: 观察5轮压力变化")
print("=" * 70)

prev_b, prev_v = 0, 0
for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)

    b_delta = b - prev_b
    v_delta = v - prev_v

    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        content = last.get('content', '')[:40]
        print(f'轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')

    prev_b, prev_v = b, v

    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("阶段2: 执行干预并检查响应")
print("=" * 70)

# 使用明确的关怀语言
intervention_text = '思远，这不是你的错，老师看到了你的委屈。陈浩，你的行为已经构成了言语霸凌，需要立刻停止并向思远道歉。'
print(f'干预内容: {intervention_text}')

r = requests.post(f'{base}/api/session/{sid}/intervene', json={'content': intervention_text})
iv = r.json()

# 正确解析嵌套结构
intervention_data = iv.get('intervention', {})
status_data = iv.get('status', {})

print(f'\n干预评估详情:')
print(f'  quality_score: {intervention_data.get("quality_score", "N/A")}')
print(f'  victim_care_score: {intervention_data.get("victim_care_score", "N/A")}')
print(f'  bullying_intensity (from intervention): {intervention_data.get("bullying_intensity", "N/A")}')
print(f'  victim_distress (from intervention): {intervention_data.get("victim_distress", "N/A")}')
print(f'  feedback items: {len(intervention_data.get("feedback", []))}')
if intervention_data.get('feedback'):
    for fb in intervention_data.get('feedback', [])[:3]:
        print(f'    - {fb}')

print(f'\n当前session状态 (from status):')
print(f'  B={status_data.get("bullying_intensity", 0):.1%} V={status_data.get("victim_distress", 0):.1%}')

print("\n" + "=" * 70)
print("阶段3: 干预后观察压力恢复")
print("=" * 70)

for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)

    b_delta = b - prev_b
    v_delta = v - prev_v

    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        content = last.get('content', '')[:40]
        print(f'干预后轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')

    prev_b, prev_v = b, v

    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("诊断总结")
print("=" * 70)
print("关键问题检查:")
q_score = intervention_data.get('quality_score', 0)
b_after = status_data.get('bullying_intensity', 1)
v_after = status_data.get('victim_distress', 1)

print(f"  1. 干预quality_score: {q_score:.2f} ({'合理' if q_score >= 0.5 else '偏低'})")
print(f"  2. 干预后B: {b_after:.1%} ({'已下降' if b_after < 0.5 else '仍偏高'})")
print(f"  3. 干预后V: {v_after:.1%} ({'已下降' if v_after < 0.5 else '仍偏高'})")

# 分析问题
issues = []
if q_score < 0.5:
    issues.append("干预质量评估偏低")
if b_after > 0.5:
    issues.append("霸凌强度未有效降低")
if v_after > 0.5:
    issues.append("受害者压力未有效降低")

if issues:
    print(f"\n⚠️  发现问题:")
    for issue in issues:
        print(f"  - {issue}")
else:
    print(f"\n✅ 干预效果正常")
