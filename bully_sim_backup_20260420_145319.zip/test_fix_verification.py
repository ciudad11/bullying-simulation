"""
最终测试 - 验证干预功能修复
"""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, 'web')

from session_manager import SessionManager

def test():
    print("=" * 60)
    print("Test: Intervention functionality fix verification")
    print("=" * 60)
    
    # Create session
    sm = SessionManager('test_fix', level=2, use_llm=True)
    print('\n[OK] Session created')
    
    # Run one round
    result = sm.run_round()
    metrics = result.get("metrics", {})
    b1 = metrics.get("bullying_intensity", 0)
    v1 = metrics.get("victim_distress", 0)
    print(f'\n[OK] Round 1: B={b1:.2%}, V={v1:.2%}')
    
    # Test intervention
    print('\nSending intervention...')
    interv_result = sm.intervene('同学们，我们应该互相尊重，不应该嘲笑别人。')
    
    # Check result
    quality = interv_result.get('quality_score', 0)
    new_b = interv_result.get('bullying_intensity', -1)
    new_v = interv_result.get('victim_distress', -1)
    
    print(f'\n[OK] Intervention result:')
    print(f'  quality_score: {quality:.2%}')
    print(f'  bullying_intensity: {new_b:.2%}' if new_b >= 0 else '  bullying_intensity: MISSING!')
    print(f'  victim_distress: {new_v:.2%}' if new_v >= 0 else '  victim_distress: MISSING!')
    
    # Verify
    assert quality > 0, "quality_score should be > 0"
    assert new_b >= 0, "bullying_intensity should be returned"
    assert new_v >= 0, "victim_distress should be returned"
    assert new_b <= b1, "bullying_intensity should decrease after intervention"
    
    print('\n[OK] All assertions passed!')
    
    # Run another round to see effect
    result = sm.run_round()
    metrics = result.get("metrics", {})
    print(f'\n[OK] Round 2 after intervention: B={metrics.get("bullying_intensity", 0):.2%}, V={metrics.get("victim_distress", 0):.2%}')
    
    print('\n' + "=" * 60)
    print("Test PASSED - Intervention functionality is working correctly!")
    print("=" * 60)

if __name__ == "__main__":
    test()
