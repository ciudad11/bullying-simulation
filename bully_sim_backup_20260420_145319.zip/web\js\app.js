/**
 * 话语霸凌模拟系统 - 网页版 JavaScript v2
 * 
 * 新特性：
 * 1. 自动开始，自动运行
 * 2. 5秒等待干预
 * 3. 干预驱动继续
 * 4. 教师主动结束
 */

// 全局状态
const state = {
    sessionId: null,
    level: 2,
    isRunning: false,
    isPaused: false,
    isStopping: false,
    maxRounds: 6,
    currentRound: 0,
    waitTimer: null,
    messages: [],
    interventions: [],
    scenarios: [],  // 情境列表
    currentScenario: null,  // 当前情境
    scenarioModified: false,  // 情境是否被修改
    lastReport: null,  // 上次的报告数据
    sessionHistory: [],  // 会话历史记录
    participants: [],  // 参与者列表
    currentEditingParticipant: null,  // 当前编辑的参与者
    interventionLibrary: [],  // 干预库
    recommendedInterventions: [],  // 推荐干预
    allInterventions: [],  // 所有干预
    currentEditingIntervention: null,  // 当前编辑的干预
    showAllInterventions: false,  // 是否显示所有干预
};

// API 基础 URL
const API_BASE = '';

// ============================================================
// 初始化
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
    updateLevelInfo(2);
    loadScenarios();
    loadParticipants();
    loadInterventions();
});

// ============================================================
// 事件监听
// ============================================================

// 统一的按钮状态管理
// 状态类型: 'initial', 'ready', 'running', 'stopped', 'report'
function updateButtonStates(state) {
    const simControl = document.getElementById('sim-control-group');
    const simRunning = document.getElementById('sim-running-group');
    const btnNewSess = document.getElementById('btn-new-session-alt');
    const btnStart = document.getElementById('btn-start');
    const btnViewReport = document.getElementById('btn-view-report');
    const btnStop = document.getElementById('btn-stop');
    const btnPause = document.getElementById('btn-pause');
    
    // 隐藏所有按钮组
    simControl.classList.add('hidden');
    simRunning.classList.add('hidden');
    btnNewSess.classList.add('hidden');
    btnStart.classList.add('hidden');
    btnViewReport.classList.add('hidden');
    
    switch(state) {
        case 'initial':
            // 初始状态：只有新会话按钮
            simControl.classList.remove('hidden');
            btnNewSess.classList.remove('hidden');
            break;
            
        case 'ready':
            // 准备状态：显示开始按钮（新会话已点击，情景已选择）
            simControl.classList.remove('hidden');
            btnStart.classList.remove('hidden');
            btnStart.disabled = false;
            break;
            
        case 'running':
            // 运行状态：显示停止和暂停按钮
            simRunning.classList.remove('hidden');
            btnPause.innerHTML = '⏸️ 暂停';
            btnPause.classList.remove('btn-warning');
            btnPause.classList.add('btn-secondary');
            state.isPaused = false;
            break;
            
        case 'stopped':
            // 停止状态：显示查看报告和新会话按钮，隐藏开始按钮
            simControl.classList.remove('hidden');
            btnStart.classList.add('hidden');
            btnViewReport.classList.remove('hidden');
            btnViewReport.disabled = false;
            btnNewSess.classList.remove('hidden');
            break;
            
        case 'report':
            // 报告状态：显示查看报告（已打开报告）和新会话
            simControl.classList.remove('hidden');
            btnViewReport.classList.remove('hidden');
            btnNewSess.classList.remove('hidden');
            break;
    }
}

function initEventListeners() {
    // 级别选择
    document.querySelectorAll('.level-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.level-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            state.level = parseInt(btn.dataset.level);
            updateLevelInfo(state.level);
        });
    });

    // 情境选择
    document.getElementById('scenario-select').addEventListener('change', onScenarioSelect);
    
    // 新建情境
    document.getElementById('btn-new-scenario').addEventListener('click', newScenario);
    
    // 保存情境
    document.getElementById('btn-save-scenario').addEventListener('click', saveScenario);
    
    // 情境标题/描述修改检测
    document.getElementById('scenario-title').addEventListener('input', onScenarioModified);
    document.getElementById('scenario-desc').addEventListener('input', onScenarioModified);
    
    // 情境面板折叠/展开
    const header = document.getElementById('scenario-header');
    header.addEventListener('click', function(e) {
        // 如果点击的是按钮或select，不触发展开/折叠
        if (e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT') {
            return;
        }
        toggleScenarioPanel();
    });

    // 开始按钮
    document.getElementById('btn-start').addEventListener('click', startSimulation);

    // 停止模拟按钮
    document.getElementById('btn-stop').addEventListener('click', () => {
        stopSimulation();
    });

    // 暂停/继续模拟按钮
    document.getElementById('btn-pause').addEventListener('click', togglePause);

    // 结束会话按钮

    // 发送干预
    document.getElementById('btn-intervene').addEventListener('click', sendIntervention);
    
    // 干预输入框 - 检测到内容立即停止倒计时
    document.getElementById('intervention-input').addEventListener('input', () => {
        const input = document.getElementById('intervention-input');
        if (input.value.trim() && state.waitTimer) {
            cancelWaitTimer();
            // 显示等待发送状态
            document.querySelector('.waiting-text').classList.remove('hidden');
            document.querySelector('.waiting-text').textContent = '⏳ 请点击发送按钮';
        }
    });

    // 回车发送（Ctrl+Enter）
    document.getElementById('intervention-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            sendIntervention();
        }
    });

    // 快捷干预 - 点击填充内容到输入框
    document.querySelectorAll('.quick-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.dataset.action;
            const messages = {
                kind: '同学们，我们应该友好相处，不要取笑别人。',
                firm: '陈浩，你的言论已经越界了。请立即停止这种行为。',
                support: '思远，你还好吗？老师注意到你可能不太舒服。',
                reflect: '如果被取笑的是你，你会有什么感受？换位思考一下。'
            };
            if (messages[action]) {
                document.getElementById('intervention-input').value = messages[action];
                // 取消倒计时，等待用户点击发送
                cancelWaitTimer();
            }
        });
    });

    // 帮助
    document.getElementById('btn-help').addEventListener('click', () => {
        document.getElementById('help-modal').classList.add('active');
    });

    document.getElementById('close-help').addEventListener('click', () => {
        document.getElementById('help-modal').classList.remove('active');
    });

    // 报告模态框
    document.getElementById('close-report').addEventListener('click', () => {
        document.getElementById('report-modal').classList.remove('active');
    });

    // 关闭报告模态框
    document.getElementById('btn-new-session').addEventListener('click', () => {
        document.getElementById('report-modal').classList.remove('active');
        resetToStart();
    });

    // 查看报告按钮
    document.getElementById('btn-view-report').addEventListener('click', viewReport);

    // 详细记录按钮
    document.getElementById('btn-open-detailed-history')?.addEventListener('click', openDetailedHistory);
    
    // 关闭详细记录模态框
    document.getElementById('close-detail-history')?.addEventListener('click', closeDetailedHistory);
    document.getElementById('btn-close-detail-history')?.addEventListener('click', closeDetailedHistory);
    
    // 点击模态框外部关闭
    document.getElementById('detail-history-modal')?.addEventListener('click', (e) => {
        if (e.target.id === 'detail-history-modal') closeDetailedHistory();
    });

    // 初始化历史显示
    updateHistoryDisplay();

    // 开始新会话按钮（顶部）
    document.getElementById('btn-new-session-alt')?.addEventListener('click', () => {
        document.getElementById('report-modal').classList.remove('active');
        resetToStart();
        // 启用情境选择并显示开始按钮
        enableScenarioSelection();
    });

    // 下载文本报告
    document.getElementById('btn-download-report').addEventListener('click', downloadTextReport);

    // 导出 PDF
    document.getElementById('btn-export-pdf').addEventListener('click', exportPDF);

    // 导出 Word
    document.getElementById('btn-export-word').addEventListener('click', exportWord);

    // 自动终止弹窗
    document.getElementById('close-autoend').addEventListener('click', () => {
        document.getElementById('autoend-modal').classList.remove('active');
    });
    document.getElementById('btn-autoend-confirm').addEventListener('click', () => {
        document.getElementById('autoend-modal').classList.remove('active');
        showReport();
    });

    // 点击模态框外部关闭
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
    
    // 参与者编辑相关
    document.getElementById('btn-edit-participants')?.addEventListener('click', openParticipantModal);
    document.getElementById('close-participant')?.addEventListener('click', closeParticipantModal);
    document.getElementById('btn-cancel-participant')?.addEventListener('click', closeParticipantModal);
    document.getElementById('btn-save-participant')?.addEventListener('click', saveParticipant);
    document.getElementById('btn-reset-participant')?.addEventListener('click', resetCurrentParticipant);
    
    // 干预库编辑相关
    document.getElementById('btn-edit-interventions')?.addEventListener('click', openInterventionModal);
    document.getElementById('close-intervention')?.addEventListener('click', closeInterventionModal);
    document.getElementById('btn-cancel-intervention')?.addEventListener('click', closeInterventionModal);
    document.getElementById('btn-save-intervention')?.addEventListener('click', saveIntervention);
    document.getElementById('btn-delete-intervention')?.addEventListener('click', deleteIntervention);
    document.getElementById('btn-add-intervention')?.addEventListener('click', addNewIntervention);
    document.getElementById('btn-more-interventions')?.addEventListener('click', toggleMoreInterventions);
}

// ============================================================
// API 调用
// ============================================================

async function apiCall(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' },
    };

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, options);
        
        // 获取响应文本
        const responseText = await response.text();
        
        if (!response.ok) {
            // 尝试解析错误信息
            try {
                const errorData = JSON.parse(responseText);
                throw new Error(errorData.detail || '请求失败');
            } catch (e) {
                throw new Error(responseText || '请求失败');
            }
        }
        
        // 解析成功响应
        return JSON.parse(responseText);
    } catch (error) {
        console.error('API 调用失败:', error);
        throw error;
    }
}

// ============================================================
// 模拟控制
// ============================================================

async function startSimulation() {
    try {
        // 获取选中的情境ID
        const scenarioSelect = document.getElementById('scenario-select');
        const scenarioId = scenarioSelect.value;
        
        // 创建新会话，传递情境ID和LLM开关
        const useLlmCheckbox = document.getElementById('use-llm');
        const useLlm = useLlmCheckbox ? useLlmCheckbox.checked : false;
        
        const result = await apiCall('/api/session', 'POST', { 
            level: state.level,
            scenario_id: scenarioId || null,
            use_llm: useLlm
        });
        
        state.sessionId = result.session_id;
        state.isRunning = true;
        state.isPaused = false;
        state.maxRounds = getMaxRounds(state.level);
        state.messages = [];
        state.interventions = [];
        
        // 如果有情境，保存到当前会话
        if (result.scenario) {
            state.currentScenario = result.scenario;
        }
        
        // 更新按钮状态 - 运行中
        updateButtonStates('running');
        
        document.getElementById('session-badge').textContent = '运行中';
        document.getElementById('session-badge').className = 'badge running';
        document.getElementById('empty-state').classList.add('hidden');
        document.getElementById('messages-list').innerHTML = '';
        document.getElementById('intervention-history').querySelector('.history-list').innerHTML = '';
        
        // 禁用情境编辑（模拟进行中）
        scenarioSelect.disabled = true;
        document.getElementById('scenario-title').disabled = true;
        document.getElementById('scenario-desc').disabled = true;
        
        // 启用输入
        document.getElementById('intervention-input').disabled = false;
        document.getElementById('btn-intervene').disabled = false;
        
        // 更新状态
        updateStatus(result.status);
        
        // 添加系统消息
        if (state.currentScenario) {
            addSystemMessage(`📋 情境：${state.currentScenario.title}`);
        } else {
            addSystemMessage(`模拟开始 - ${state.level}级霸凌场景`);
        }
        
        // 自动开始第一轮
        setTimeout(() => runNextRound(), 1000);
        
    } catch (error) {
        console.error('启动失败:', error);
        alert('启动失败: ' + error.message);
    }
}

async function stopSimulation() {
    // 手动停止模拟
    if (!state.sessionId) return;
    
    // 首先设置标志，防止新的 runNextRound 开始
    state.isRunning = false;
    state.isStopping = true;
    state.isPaused = false;
    
    // 停止计时器
    cancelWaitTimer();
    
    addSystemMessage('⏹️ 正在停止...');
    
    // 更新 badge
    document.getElementById('session-badge').textContent = '正在停止...';
    document.getElementById('session-badge').className = 'badge warning';
    
    // 主动调用最终化停止（不等待 API）
    finalizeStop();
}

// 最终化停止过程
async function finalizeStop(autoEnded = false, autoEndReason = '', resultType = '') {
    console.log('finalizeStop called', { autoEnded, autoEndReason, resultType });
    
    // 确保不会运行
    state.isRunning = false;
    state.isStopping = false;
    
    addSystemMessage('🛑 实训结束');
    
    // 禁用输入
    document.getElementById('intervention-input').disabled = true;
    document.getElementById('btn-intervene').disabled = true;
    
    // 更新 badge
    document.getElementById('session-badge').textContent = '已结束';
    document.getElementById('session-badge').className = 'badge';
    
    // 获取并保存报告数据
    try {
        console.log('Getting report...');
        state.lastReport = await apiCall(`/api/session/${state.sessionId}/report`);
        console.log('Report received, updating buttons');
        
        // 保存到历史记录
        saveToHistory(state.lastReport);
        
        // 更新按钮状态 - 停止状态
        updateButtonStates('stopped');
        
    } catch (error) {
        console.error('获取报告失败:', error);
        // 即使获取报告失败，仍然更新按钮状态
        updateButtonStates('stopped');
    }
    
    // 如果是系统自动终止，弹出终止原因弹窗（在报告数据获取完成后显示）
    if (autoEnded && autoEndReason) {
        // 根据结果类型显示不同样式
        const iconEl = document.getElementById('autoend-icon');
        const titleEl = document.getElementById('autoend-title');
        const subtitleEl = document.getElementById('autoend-subtitle');
        const reasonEl = document.getElementById('autoend-reason');
        
        if (resultType === 'success') {
            iconEl.textContent = '✅';
            titleEl.textContent = '🎉 调解成功';
            subtitleEl.textContent = '干预起到了积极效果';
            reasonEl.style.borderLeftColor = '#4caf50';
        } else if (resultType === 'failure') {
            iconEl.textContent = '❌';
            titleEl.textContent = '😔 调解失败';
            subtitleEl.textContent = '需要重新思考干预策略';
            reasonEl.style.borderLeftColor = '#f44336';
        } else if (resultType === 'timeout') {
            iconEl.textContent = '⏰';
            titleEl.textContent = '📋 模拟超时';
            subtitleEl.textContent = '对话轮次已达上限';
            reasonEl.style.borderLeftColor = '#ff9800';
        } else {
            iconEl.textContent = '🏁';
            titleEl.textContent = '📋 模拟结束';
            subtitleEl.textContent = '模拟已达成终止条件';
            reasonEl.style.borderLeftColor = 'var(--primary)';
        }
        
        reasonEl.textContent = autoEndReason;
        document.getElementById('autoend-modal').classList.add('active');
    }
}

// 保存到历史记录
function saveToHistory(report) {
    const summary = report.summary || {};
    const assessment = report.ability_assessment || {};
    
    // 获取干预详情 - API返回的是 interventions 不是 intervention_records
    const interventions = report.interventions || [];
    
    const historyEntry = {
        id: Date.now().toString(),
        date: new Date().toLocaleDateString('zh-CN'),
        datetime: new Date().toISOString(),
        level: state.level,
        scenario: state.currentScenario?.title || '未选择情境',
        
        // 霸凌情况
        bullying_intensity: summary.bullying_intensity || 0,
        victim_distress: summary.victim_distress || 0,
        hostile_messages: summary.hostile_messages || 0,
        total_messages: summary.total_messages || 0,
        
        // 干预情况
        intervention_count: summary.intervention_count || 0,
        intervention_effectiveness: summary.intervention_effectiveness || 0,
        
        // 干预详情（用于详细记录展示）
        interventions: interventions.map(iv => ({
            content: iv.content || '',
            quality_score: iv.quality_score || 0,
            victim_care_score: iv.victim_care_score || 0,
            feedback: iv.feedback || []
        })),
        
        // 能力评估
        discovery_level: assessment.discovery?.level || 'unknown',
        intervention_count_assessed: assessment.intervention?.count || 0,
        
        // 简短评价
        rating: summary.intervention_effectiveness >= 0.6 ? 'good' : 
                summary.intervention_effectiveness >= 0.3 ? 'medium' : 'poor'
    };
    
    // 获取现有历史
    const history = getHistory();
    
    // 添加新记录（最新在前）
    history.unshift(historyEntry);
    
    // 只保留最近 50 条
    if (history.length > 50) {
        history.pop();
    }
    
    // 保存
    localStorage.setItem('bullying_sim_history', JSON.stringify(history));
    state.sessionHistory = history;
    
    // 更新历史显示（如果存在）
    updateHistoryDisplay();
}

// 获取历史记录
function getHistory() {
    try {
        const stored = localStorage.getItem('bullying_sim_history');
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        return [];
    }
}

// 更新历史显示
function updateHistoryDisplay() {
    const historyList = document.getElementById('history-list');
    if (!historyList) return;
    
    const history = getHistory();
    
    if (history.length === 0) {
        historyList.innerHTML = '<p class="empty-hint">暂无历史记录</p>';
        return;
    }
    
    historyList.innerHTML = history.slice(0, 10).map((entry, i) => `
        <div class="history-item ${entry.rating}" data-id="${entry.id}">
            <div class="history-date">${entry.date}</div>
            <div class="history-summary">
                ${entry.scenario} | 干预${entry.intervention_count}次 | 
                效果${Math.round(entry.intervention_effectiveness * 100)}%
            </div>
            <div class="history-rating">
                ${entry.rating === 'good' ? '✅' : entry.rating === 'medium' ? '⚠️' : '❌'}
            </div>
        </div>
    `).join('');
}

// ==================== 详细记录功能 ====================

// 打开详细记录模态框
function openDetailedHistory() {
    const content = document.getElementById('detail-history-content');
    const records = getHistory();
    
    if (records.length === 0) {
        content.innerHTML = '<p class="empty-hint" style="text-align: center; padding: 40px;">暂无实训记录</p>';
    } else {
        content.innerHTML = records.map((record, index) => `
            <div class="detail-record-item" id="record-${record.id}">
                <div class="detail-record-header" onclick="toggleRecordDetail('${record.id}')">
                    <div class="detail-record-info">
                        <span class="record-date">${record.date}</span>
                        <span class="record-scenario">${record.scenario}</span>
                        <span class="record-level">${getLevelName(record.level)}</span>
                    </div>
                    <div class="detail-record-stats">
                        <span class="stat-badge">干预 ${record.intervention_count} 次</span>
                        <span class="stat-badge ${record.rating === 'good' ? 'good' : record.rating === 'medium' ? 'medium' : 'poor'}">
                            效果 ${Math.round(record.intervention_effectiveness * 100)}%
                        </span>
                        <span class="rating-badge">${record.rating === 'good' ? '✅' : record.rating === 'medium' ? '⚠️' : '❌'}</span>
                        <button class="btn-icon report-btn" onclick="event.stopPropagation(); viewReportFromHistory('${record.id}')" title="查看报告">📊</button>
                        <button class="btn-icon delete-btn" onclick="event.stopPropagation(); deleteRecord('${record.id}')" title="删除此记录">🗑️</button>
                        <span class="toggle-icon" id="toggle-${record.id}">▼</span>
                    </div>
                </div>
                <div class="detail-record-body" id="body-${record.id}" style="display: none;">
                    ${renderRecordDetailBody(record)}
                </div>
            </div>
        `).join('');
    }
    
    document.getElementById('detail-history-modal').classList.add('active');
}

// 关闭详细记录模态框
function closeDetailedHistory() {
    document.getElementById('detail-history-modal').classList.remove('active');
}

// 切换记录详情展开/收起
function toggleRecordDetail(recordId) {
    const body = document.getElementById(`body-${recordId}`);
    const icon = document.getElementById(`toggle-${recordId}`);
    
    if (body.style.display === 'none') {
        body.style.display = 'block';
        icon.textContent = '▲';
    } else {
        body.style.display = 'none';
        icon.textContent = '▼';
    }
}

// 渲染记录详情内容
function renderRecordDetailBody(record) {
    let html = '<div class="detail-record-content">';
    
    // 基本信息
    html += '<div class="detail-section">';
    html += '<h4>📊 基本信息</h4>';
    html += '<table class="detail-table">';
    html += `<tr><td>总消息数</td><td>${record.total_messages || 0} 条</td></tr>`;
    html += `<tr><td>攻击性消息</td><td>${record.hostile_messages || 0} 条</td></tr>`;
    html += `<tr><td>霸凌强度</td><td>${Math.round((record.bullying_intensity || 0) * 100)}%</td></tr>`;
    html += `<tr><td>受害者压力</td><td>${Math.round((record.victim_distress || 0) * 100)}%</td></tr>`;
    html += `<tr><td>干预次数</td><td>${record.intervention_count || 0} 次</td></tr>`;
    html += `<tr><td>干预效果</td><td>${Math.round((record.intervention_effectiveness || 0) * 100)}%</td></tr>`;
    html += '</table></div>';
    
    // 每次干预详情
    if (record.interventions && record.interventions.length > 0) {
        html += '<div class="detail-section">';
        html += '<h4>📝 干预详情</h4>';
        record.interventions.forEach((iv, idx) => {
            html += `<div class="intervention-detail-item">`;
            html += `<div class="iv-header">#${idx + 1} <span class="iv-quality">评分: ${Math.round(iv.quality_score * 100)}%</span></div>`;
            html += `<div class="iv-content">"${iv.content}"</div>`;
            if (iv.feedback && iv.feedback.length > 0) {
                html += '<div class="iv-feedback">';
                html += iv.feedback.filter(f => f.includes('✅') || f.includes('⚠️') || f.includes('🚨')).map(f => f).join('<br>');
                html += '</div>';
            }
            if (iv.victim_care_score > 0) {
                html += `<div class="iv-care">关怀得分: ${Math.round(iv.victim_care_score * 100)}%</div>`;
            }
            html += '</div>';
        });
        html += '</div>';
    } else {
        html += '<div class="detail-section">';
        html += '<h4>📝 干预详情</h4>';
        html += '<p class="empty-hint">无干预记录</p>';
        html += '</div>';
    }
    
    html += '</div>';
    return html;
}

// 从历史记录查看报告
function viewReportFromHistory(recordId) {
    const history = getHistory();
    const record = history.find(r => r.id === recordId);
    
    if (!record) {
        alert('未找到该记录');
        return;
    }
    
    // 从历史记录重建报告数据（与generate_report格式一致）
    const report = {
        success: true,
        summary: {
            total_messages: record.total_messages || 0,
            bullying_intensity: record.bullying_intensity,
            victim_distress: record.victim_distress,
            hostile_messages: record.hostile_messages || 0,
            intervention_count: record.intervention_count,
            intervention_effectiveness: record.intervention_effectiveness,
        },
        level: record.level,
        scenario: record.scenario,
        interventions: record.interventions || [],
        ability_assessment: {
            discovery: { level: record.discovery_level || 'unknown' },
            intervention: { count: record.intervention_count_assessed || 0 }
        }
    };
    
    // 关闭详细记录模态框
    closeDetailedHistory();
    
    // 显示报告
    displayReport(report);
    document.getElementById('report-modal').classList.add('active');
}

// 删除单条记录
function deleteRecord(recordId) {
    if (!confirm('确定要删除此条实训记录吗？')) return;
    
    const history = getHistory();
    const filtered = history.filter(r => r.id !== recordId);
    
    localStorage.setItem('bullying_sim_history', JSON.stringify(filtered));
    state.sessionHistory = filtered;
    
    // 重新渲染
    openDetailedHistory();
    updateHistoryDisplay();
}

// 获取霸凌等级名称
function getLevelName(level) {
    const levels = {1: '1级-轻微', 2: '2级-一般', 3: '3级-较重', 4: '4级-严重', 5: '5级-极重'};
    return levels[level] || `${level}级`;
}

// 查看报告
async function viewReport() {
    if (state.lastReport) {
        displayReport(state.lastReport);
        document.getElementById('report-modal').classList.add('active');
    }
}

// 下载文本报告
async function downloadTextReport() {
    if (!state.sessionId) return;
    
    try {
        const report = await apiCall(`/api/session/${state.sessionId}/report`);
        const text = formatReportAsText(report);
        
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `教师实训报告_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('下载失败:', error);
        alert('下载失败: ' + error.message);
    }
}

// 导出 PDF
async function exportPDF() {
    if (!state.sessionId) return;
    
    try {
        const report = await apiCall(`/api/session/${state.sessionId}/report`);
        const html = formatReportAsHTML(report);
        
        // 创建一个隐藏的 iframe 用于打印
        const iframe = document.createElement('iframe');
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);
        
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        iframeDoc.open();
        iframeDoc.write(html);
        iframeDoc.close();
        
        iframe.contentWindow.print();
        
        setTimeout(() => iframe.remove(), 1000);
    } catch (error) {
        console.error('导出PDF失败:', error);
        alert('导出PDF失败: ' + error.message);
    }
}

// 导出 Word
async function exportWord() {
    if (!state.sessionId) return;
    
    try {
        const report = await apiCall(`/api/session/${state.sessionId}/report`);
        const html = formatReportAsHTML(report);
        
        // 添加 Word 命名空间的 HTML
        const wordHtml = `
<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
<head>
<meta charset="utf-8">
<title>教师实训报告</title>
<style>
body { font-family: '微软雅黑', Arial, sans-serif; padding: 20px; }
h1 { color: #333; border-bottom: 2px solid #2196F3; padding-bottom: 10px; }
h3 { color: #666; margin-top: 20px; }
.metric { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
.value { font-weight: bold; }
.value.good { color: #4CAF50; }
.value.warning { color: #FF9800; }
.value.danger { color: #F44336; }
</style>
</head>
<body>
${html}
</body>
</html>`;
        
        const blob = new Blob([wordHtml], { type: 'application/msword' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `教师实训报告_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.doc`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('导出Word失败:', error);
        alert('导出Word失败: ' + error.message);
    }
}

// 格式化报告为纯文本
function formatReportAsText(report) {
    const summary = report.summary || {};
    const metrics = report.metrics || {};
    const assessment = report.ability_assessment || {};
    
    return `
================================================================================
                    教师话语霸凌实训评估报告
================================================================================

生成时间: ${new Date().toLocaleString('zh-CN')}

【霸凌情况】
  总消息数: ${summary.total_messages || 0}
  攻击性事件: ${summary.hostile_messages || 0}次
  最终霸凌强度: ${Math.round((summary.bullying_intensity || 0) * 100)}%
  受害者压力: ${Math.round((summary.victim_distress || 0) * 100)}%

【教师干预】
  干预次数: ${summary.intervention_count || 0}
  平均效果: ${Math.round((summary.intervention_effectiveness || 0) * 100)}%

【能力评估】
  发现能力: ${assessment.discovery?.description || '未评估'}
  干预能力: ${assessment.intervention?.count || 0}次干预

【会话统计】
  模拟时长: ${report.session_duration || 'N/A'}
  模拟轮数: ${report.total_rounds || 'N/A'}

================================================================================
                        报告结束
================================================================================
`;
}

// 格式化报告为 HTML
function formatReportAsHTML(report) {
    const summary = report.summary || {};
    const assessment = report.ability_assessment || {};
    
    return `
<h1>📊 教师话语霸凌实训评估报告</h1>
<p><strong>生成时间:</strong> ${new Date().toLocaleString('zh-CN')}</p>

<h3>📌 霸凌情况</h3>
<div class="metric"><span>总消息数</span><span class="value">${summary.total_messages || 0}</span></div>
<div class="metric"><span>攻击性事件</span><span class="value danger">${summary.hostile_messages || 0}次</span></div>
<div class="metric"><span>最终霸凌强度</span><span class="value ${(summary.bullying_intensity || 0) > 0.5 ? 'danger' : ''}">${Math.round((summary.bullying_intensity || 0) * 100)}%</span></div>
<div class="metric"><span>受害者压力</span><span class="value ${(summary.victim_distress || 0) > 0.4 ? 'warning' : ''}">${Math.round((summary.victim_distress || 0) * 100)}%</span></div>

<h3>👨‍🏫 教师干预</h3>
<div class="metric"><span>干预次数</span><span class="value">${summary.intervention_count || 0}</span></div>
<div class="metric"><span>平均效果</span><span class="value ${(summary.intervention_effectiveness || 0) >= 0.5 ? 'good' : 'warning'}">${Math.round((summary.intervention_effectiveness || 0) * 100)}%</span></div>

<h3>🎯 能力评估</h3>
<div class="metric"><span>发现能力</span><span class="value">${assessment.discovery?.description || '未评估'}</span></div>
<div class="metric"><span>干预能力</span><span class="value">${assessment.intervention?.count || 0}次干预</span></div>
`;
}

function togglePause() {
    if (!state.sessionId || !state.isRunning) return;
    
    state.isPaused = !state.isPaused;
    
    const pauseBtn = document.getElementById('btn-pause');
    
    if (state.isPaused) {
        // 暂停
        pauseBtn.innerHTML = '▶️ 继续模拟';
        pauseBtn.classList.remove('btn-secondary');
        pauseBtn.classList.add('btn-warning');
        document.getElementById('session-badge').textContent = '已暂停';
        document.getElementById('session-badge').className = 'badge warning';
        addSystemMessage('⏸️ 模拟已暂停');
        
        // 取消等待计时器
        cancelWaitTimer();
    } else {
        // 继续
        pauseBtn.innerHTML = '⏸️ 暂停模拟';
        pauseBtn.classList.remove('btn-warning');
        pauseBtn.classList.add('btn-secondary');
        document.getElementById('session-badge').textContent = '运行中';
        document.getElementById('session-badge').className = 'badge running';
        addSystemMessage('▶️ 模拟继续');
        
        // 继续下一轮
        setTimeout(() => runNextRound(), 1000);
    }
}
    
async function runNextRound() {
    if (!state.sessionId) return;
    
    // 如果正在停止或已停止，跳过
    if (state.isStopping || !state.isRunning) {
        if (state.isStopping) {
            addSystemMessage('⏹️ 停止中...');
        }
        return;
    }
    
    if (!state.isRunning) return;
    
    // 如果暂停状态，不继续
    if (state.isPaused) {
        addSystemMessage('⏸️ 模拟已暂停');
        return;
    }
    
    state.currentRound++;
    
    // 添加轮次分隔消息
    addSystemMessage(`--- 第 ${state.currentRound} 轮对话 ---`);
    
    // 高亮参与者
    highlightParticipants('all');
    
    try {
        // 显示加载动画
        showLoading();
        
        const result = await apiCall(`/api/session/${state.sessionId}/run`, 'POST');
        
        // 隐藏加载动画
        hideLoading();
        
        // 显示新消息 - 使用正确的字段 (API返回 result.messages，而非 result.status.messages)
        const newMessages = result.messages || result.status?.messages || [];
        if (newMessages.length > 0) {
            for (const msg of newMessages) {
                await addMessage(msg);
                await delay(800); // 模拟打字延迟
            }
        }
        
        // 更新状态
        updateStatus(result.status);
        
        // 重新加载推荐干预（传入当前状态）
        setTimeout(() => loadRecommendedInterventions(), 500);
        
        // 如果模拟完成或正在停止
        console.log('API returned, checking stop condition:', { done: result.done, isStopping: state.isStopping, autoEnded: result.auto_ended });
        if (result.done || state.isStopping) {
            console.log('Calling finalizeStop');
            await finalizeStop(result.auto_ended, result.auto_end_reason || '', result.result_type || '');
            console.log('finalizeStop returned, returning');
            return;
        }
        
        // 开始等待计时器
        startWaitTimer();
        
    } catch (error) {
        console.error('运行失败:', error);
        addSystemMessage('运行出错，请检查');
    }
}

function startWaitTimer() {
    let countdown = 5;
    const timerEl = document.getElementById('countdown-timer');
    let userTyped = false;  // 标记用户是否已手动输入
    
    // 更新状态显示
    document.querySelector('.waiting-text').classList.add('hidden');
    document.querySelector('.auto-text').classList.remove('hidden');
    if (timerEl) timerEl.textContent = countdown;
    
    // 清除之前的计时器
    if (state.waitTimer) {
        clearInterval(state.waitTimer);
    }
    
    // 监听用户输入 - 检测到内容立即停止计时器
    const inputEl = document.getElementById('intervention-input');
    const handleInput = () => {
        if (inputEl.value.trim() && !userTyped) {
            userTyped = true;
            clearInterval(state.waitTimer);
            state.waitTimer = null;
            // 显示等待发送状态
            document.querySelector('.auto-text').classList.add('hidden');
            document.querySelector('.waiting-text').classList.remove('hidden');
            document.querySelector('.waiting-text').textContent = '⏳ 请点击发送按钮';
        }
    };
    inputEl.addEventListener('input', handleInput);
    
    state.waitTimer = setInterval(() => {
        countdown--;
        
        if (timerEl) timerEl.textContent = countdown > 0 ? countdown : '0';
        
        if (countdown <= 0) {
            clearInterval(state.waitTimer);
            state.waitTimer = null;
            // 移除输入监听
            inputEl.removeEventListener('input', handleInput);
            
            // 如果用户已手动输入，等待发送
            if (userTyped) {
                document.querySelector('.auto-text').classList.add('hidden');
                document.querySelector('.waiting-text').classList.remove('hidden');
                document.querySelector('.waiting-text').textContent = '⏳ 请点击发送按钮';
            } else {
                // 无输入，自动继续
                document.querySelector('.auto-text').classList.add('hidden');
                document.querySelector('.waiting-text').classList.add('hidden');
                runNextRound();
            }
        }
    }, 1000);
}

function cancelWaitTimer() {
    if (state.waitTimer) {
        clearInterval(state.waitTimer);
        state.waitTimer = null;
    }
    // 标记计时器被取消，input 监听会检测此标记
    const inputEl = document.getElementById('intervention-input');
    if (inputEl.value.trim()) {
        // 有内容，等待用户发送
        document.querySelector('.waiting-text').classList.remove('hidden');
        document.querySelector('.waiting-text').textContent = '⏳ 请点击发送按钮';
    } else {
        // 无内容，显示等待状态
        document.querySelector('.waiting-text').classList.remove('hidden');
        document.querySelector('.waiting-text').textContent = '⏳ 等待干预输入...';
    }
    document.querySelector('.auto-text').classList.add('hidden');
}

async function sendIntervention() {
    if (!state.sessionId) return;
    
    const input = document.getElementById('intervention-input');
    const content = input.value.trim();
    
    if (!content) {
        // 无内容，视为继续
        input.value = '';
        cancelWaitTimer();
        runNextRound();
        return;
    }

    try {
        showLoading();
        const result = await apiCall(`/api/session/${state.sessionId}/intervene`, 'POST', { content });
        hideLoading();
        
        console.log('干预响应:', result);
        
        // 取消等待计时器
        cancelWaitTimer();
        
        // 清空输入
        input.value = '';
        
        // 使用后端返回的消息数据（避免重复添加）
        const msgData = result.message || {
            id: Date.now().toString(),
            sender: '张老师',
            role: 'teacher',
            content: content,
            hostile_score: 0,
            emotions: [],
        };
        
        // 如果返回了评估数据，加入
        if (result.intervention?.quality_score !== undefined) {
            msgData.quality_score = result.intervention.quality_score;
        }
        
        // 添加干预消息到对话区
        await addMessage(msgData);
        
        // 干预效果可视化
        const quality = msgData.quality_score || 0.5;
        if (quality >= 0.6) {
            showInterventionEffect('good', '干预有效！角色行为可能改变');
        } else if (quality >= 0.3) {
            showInterventionEffect('medium', '干预一般，可尝试其他方法');
        } else {
            showInterventionEffect('poor', '干预效果不佳');
        }
        
        // 添加到历史
        if (result.intervention) {
            addToHistory(result.intervention);
        }
        
        // 更新状态 - 使用干预返回的指标值更新UI
        if (result.status) {
            updateStatus(result.status);
        } else if (result.intervention?.bullying_intensity !== undefined) {
            // 直接使用干预返回的指标值更新UI
            updateStatus({
                round: state.currentRound,
                bullying_intensity: result.intervention.bullying_intensity,
                victim_distress: result.intervention.victim_distress,
            });
        }
        
        // 延迟后继续
        setTimeout(() => {
            if (state.isRunning && !state.isPaused) {
                runNextRound();
            }
        }, 1500);
        
    } catch (error) {
        console.error('干预失败:', error);
        alert('干预失败: ' + error.message);
    }
}

async function endSimulation() {
    if (!state.sessionId) return;
    
    // 取消等待计时器
    cancelWaitTimer();
    state.isRunning = false;
    state.isPaused = false;
    
    // 添加系统消息
    addSystemMessage('会话已结束，正在生成报告...');
    
    // 禁用输入
    document.getElementById('intervention-input').disabled = true;
    document.getElementById('btn-intervene').disabled = true;
    
    // 隐藏运行中按钮组
    document.getElementById('sim-running-group').classList.add('hidden');
    document.getElementById('sim-control-group').classList.remove('hidden');
    
    // 显示报告
    await showReport();
}

function resetToStart() {
    state.sessionId = null;
    state.isRunning = false;
    state.isPaused = false;
    state.currentRound = 0;
    state.messages = [];
    state.interventions = [];
    
    // 重置 UI
    document.getElementById('start-panel').classList.remove('hidden');
    document.getElementById('session-badge').textContent = '等待开始';
    document.getElementById('session-badge').className = 'badge';
    document.getElementById('empty-state').classList.remove('hidden');
    document.getElementById('messages-list').innerHTML = '';
    document.getElementById('intervention-input').disabled = true;
    document.getElementById('btn-intervene').disabled = true;
    document.getElementById('intervention-input').value = '';
    
    // 重置按钮状态 - 初始状态
    updateButtonStates('initial');
    
    // 更新历史显示
    updateHistoryDisplay();
    
    // 重置情境区域
    document.getElementById('scenario-select').disabled = false;
    document.getElementById('scenario-select').value = '';
    document.getElementById('scenario-title').disabled = false;
    document.getElementById('scenario-title').value = '';
    document.getElementById('scenario-desc').disabled = false;
    document.getElementById('scenario-desc').value = '';
    document.getElementById('btn-save-scenario').classList.add('hidden');
    state.currentScenario = null;
    state.scenarioModified = false;
    updateScenarioTip();
    
    // 重置状态
    document.getElementById('status-round').textContent = '0';
    document.getElementById('progress-intensity').style.width = '0%';
    document.getElementById('value-intensity').textContent = '0%';
    document.getElementById('progress-distress').style.width = '0%';
    document.getElementById('value-distress').textContent = '0%';
    document.getElementById('alert-box').classList.add('hidden');
    document.getElementById('timer').classList.add('hidden');
    
    // 重置参与者高亮
    document.querySelectorAll('.participant').forEach(p => {
        p.classList.remove('active', 'speaking');
    });
}

// ============================================================
// UI 更新
// ============================================================

function updateLevelInfo(level) {
    const levels = {
        1: { name: '1级 - 轻微', desc: '偶尔的嘲笑、轻微言语冲突' },
        2: { name: '2级 - 一般', desc: '持续的语言嘲讽、轻微社交排斥' },
        3: { name: '3级 - 中等', desc: '明显的言语攻击、社交排斥' },
        4: { name: '4级 - 严重', desc: '持续的语言暴力、人身攻击' },
        5: { name: '5级 - 极其严重', desc: '极端的语言暴力、威胁恐吓' },
    };
    
    const info = levels[level];
    document.getElementById('level-info').innerHTML = `
        <p><strong>${info.name}</strong></p>
        <p>${info.desc}</p>
    `;
}

function updateStatus(status) {
    document.getElementById('status-round').textContent = status.round || state.currentRound;
    
    const intensity = status.bullying_intensity || 0;
    const distress = status.victim_distress || 0;
    
    document.getElementById('progress-intensity').style.width = `${Math.round(intensity * 100)}%`;
    document.getElementById('value-intensity').textContent = `${Math.round(intensity * 100)}%`;
    
    document.getElementById('progress-distress').style.width = `${Math.round(distress * 100)}%`;
    document.getElementById('value-distress').textContent = `${Math.round(distress * 100)}%`;
    
    // 干预警报
    if (status.needs_intervention) {
        document.getElementById('alert-box').classList.remove('hidden');
    } else {
        document.getElementById('alert-box').classList.add('hidden');
    }
}

function highlightParticipants(who) {
    document.querySelectorAll('.participant').forEach(p => {
        p.classList.remove('speaking');
    });
}

function highlightSpeaker(role) {
    const roleMap = {
        'bully': 'chenhao',
        'victim': 'siyuan',
        'bystander_a': 'linyutong',
        'bystander_b': 'zhaolei',
        'teacher': null,
    };
    
    const participantId = roleMap[role];
    if (participantId) {
        document.querySelectorAll('.participant').forEach(p => {
            p.classList.remove('speaking');
        });
        const el = document.getElementById(`part-${participantId}`);
        if (el) {
            el.classList.add('speaking');
            setTimeout(() => el.classList.remove('speaking'), 2000);
        }
    }
}

// 显示/隐藏加载动画
function showLoading() {
    const loading = document.getElementById('llm-loading');
    if (loading) {
        loading.classList.remove('hidden');
    }
}

function hideLoading() {
    const loading = document.getElementById('llm-loading');
    if (loading) {
        loading.classList.add('hidden');
    }
}

// 干预效果可视化
function showInterventionEffect(level, message) {
    const effectTypes = {
        'good': { icon: '✅', class: 'intervention-good', color: '#4CAF50' },
        'medium': { icon: '⚠️', class: 'intervention-medium', color: '#FF9800' },
        'poor': { icon: '❌', class: 'intervention-poor', color: '#F44336' }
    };
    
    const effect = effectTypes[level] || effectTypes['medium'];
    
    // 创建效果提示
    const effectDiv = document.createElement('div');
    effectDiv.className = `intervention-effect ${effect.class}`;
    effectDiv.innerHTML = `
        <span class="effect-icon">${effect.icon}</span>
        <span class="effect-message">${message}</span>
    `;
    effectDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        background: ${effect.color};
        color: white;
        border-radius: 8px;
        font-size: 0.875rem;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    `;
    
    document.body.appendChild(effectDiv);
    
    // 3秒后移除
    setTimeout(() => {
        effectDiv.style.animation = 'slideOut 0.3s ease-out forwards';
        setTimeout(() => effectDiv.remove(), 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

async function addMessage(msg) {
    state.messages.push(msg);
    
    const roleNames = {
        bully: '霸凌者',
        victim: '被霸凌者',
        bystander_a: '正义旁观',
        bystander_b: '从众旁观',
        bystander: '旁观者',
        teacher: '老师',
    };
    
    // 确定角色
    const role = msg.role || 'unknown';
    const displayRole = roleNames[role] || role;
    
    const messagesList = document.getElementById('messages-list');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    messageDiv.dataset.id = msg.id;
    
    // 高亮说话者
    highlightSpeaker(role);
    
    let metaHtml = '';
    
    if (msg.hostile_score && msg.hostile_score > 0) {
        metaHtml += `<span class="tag hostile">攻击性: ${Math.round(msg.hostile_score * 100)}%</span>`;
    }
    
    if (msg.emotions && msg.emotions.length > 0) {
        const emotionNames = {
            'sad': '悲伤',
            'angry': '愤怒',
            'fearful': '恐惧',
            'happy': '开心',
            'remorseful': '后悔',
        };
        const emotions = msg.emotions.map(e => emotionNames[e] || e).join(', ');
        metaHtml += `<span class="tag emotion">${emotions}</span>`;
    }
    
    if (role === 'teacher') {
        metaHtml = '<span class="tag intervention">教师干预</span>';
        
        // 如果有评估结果，添加反馈
        if (msg.quality_score !== undefined) {
            const qualityLabel = msg.quality_score >= 0.6 ? '良好' : msg.quality_score >= 0.4 ? '一般' : '需改进';
            metaHtml += ` <span class="tag" style="background: ${msg.quality_score >= 0.5 ? '#c8e6c9' : '#fff9c4'}; color: ${msg.quality_score >= 0.5 ? '#2e7d32' : '#f57c00'};">效果: ${qualityLabel} (${Math.round(msg.quality_score * 100)}%)</span>`;
        }
    }
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <span class="message-sender">${msg.sender}</span>
            <span class="message-role">${displayRole}</span>
        </div>
        <div class="message-content">${escapeHtml(msg.content)}</div>
        ${metaHtml ? `<div class="message-meta">${metaHtml}</div>` : ''}
    `;
    
    messagesList.appendChild(messageDiv);
    
    // 滚动到底部
    const container = document.getElementById('messages-container');
    container.scrollTop = container.scrollHeight;
    
    await delay(100);
}

function addSystemMessage(content) {
    const messagesList = document.getElementById('messages-list');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message system';
    messageDiv.textContent = content;
    messagesList.appendChild(messageDiv);
    
    const container = document.getElementById('messages-container');
    container.scrollTop = container.scrollHeight;
}

function showInterventionResult(result) {
    // 显示评估反馈
    if (result && result.feedback && result.feedback.length > 0) {
        // 找到最后一条干预消息并添加反馈显示
        const messages = document.querySelectorAll('.message.teacher');
        if (messages.length > 0) {
            const lastMsg = messages[messages.length - 1];
            const feedbackDiv = document.createElement('div');
            feedbackDiv.className = 'intervention-feedback';
            feedbackDiv.style.cssText = 'margin-top: 8px; padding: 8px; background: rgba(0,0,0,0.05); border-radius: 6px; font-size: 0.8125rem;';
            
            let feedbackHtml = '<div style="margin-bottom: 4px;"><strong>📊 干预评估</strong></div>';
            result.feedback.forEach(fb => {
                const isPositive = fb.startsWith('✅');
                feedbackHtml += `<div style="color: ${isPositive ? '#4CAF50' : '#ff9800'}; margin: 2px 0;">${fb}</div>`;
            });
            if (result.recommendation) {
                feedbackHtml += `<div style="margin-top: 6px; color: #666; font-style: italic;">💬 ${result.recommendation}</div>`;
            }
            feedbackHtml += `<div style="margin-top: 4px; font-size: 0.75rem; color: #999;">效果: ${Math.round(result.quality_score * 100)}%</div>`;
            feedbackDiv.innerHTML = feedbackHtml;
            lastMsg.appendChild(feedbackDiv);
        }
    }
}

function addToHistory(intervention) {
    state.interventions.push(intervention);
    
    const historyList = document.querySelector('.history-list');
    const item = document.createElement('div');
    item.className = 'history-item';
    
    const qualityClass = intervention.quality_score >= 0.5 ? 'good' : 'bad';
    const qualityLabel = intervention.quality_score >= 0.6 ? '良好' : intervention.quality_score >= 0.4 ? '一般' : '需改进';
    
    item.innerHTML = `
        <div class="quality ${qualityClass}">${qualityLabel} (${Math.round(intervention.quality_score * 100)}%)</div>
        <div class="content">"${escapeHtml((intervention.content || '').substring(0, 50))}${(intervention.content || '').length > 50 ? '...' : ''}"</div>
    `;
    
    historyList.insertBefore(item, historyList.firstChild);
}

// 显示报告内容（传入报告数据）
function displayReport(report) {
    const content = document.getElementById('report-content');
    const summary = report.summary || {};
    const metrics = report.metrics || {};
    const assessment = report.ability_assessment || {};
    
    content.innerHTML = `
        <div class="report-section">
            <h3>📊 霸凌情况</h3>
            <div class="report-metric">
                <span>总消息数</span>
                <span class="value">${summary.total_messages || 0}</span>
            </div>
            <div class="report-metric">
                <span>攻击性事件</span>
                <span class="value danger">${summary.hostile_messages || 0}次</span>
            </div>
            <div class="report-metric">
                <span>最终霸凌强度</span>
                <span class="value ${summary.bullying_intensity > 0.5 ? 'danger' : ''}">${Math.round((summary.bullying_intensity || 0) * 100)}%</span>
            </div>
            <div class="report-metric">
                <span>受害者压力</span>
                <span class="value ${summary.victim_distress > 0.4 ? 'warning' : ''}">${Math.round((summary.victim_distress || 0) * 100)}%</span>
            </div>
        </div>
        
        <div class="report-section">
            <h3>👨🏫 教师干预</h3>
            <div class="report-metric">
                <span>干预次数</span>
                <span class="value">${summary.intervention_count || 0}</span>
            </div>
            <div class="report-metric">
                <span>平均效果</span>
                <span class="value ${(summary.intervention_effectiveness || 0) >= 0.5 ? 'good' : 'warning'}">${Math.round((summary.intervention_effectiveness || 0) * 100)}%</span>
            </div>
        </div>
        
        <div class="report-section">
            <h3>🎯 能力评估</h3>
            <div class="report-metric">
                <span>发现能力</span>
                <span class="value ${assessment.discovery?.level === 'good' ? 'good' : 'warning'}">${assessment.discovery?.description || '未评估'}</span>
            </div>
            <div class="report-metric">
                <span>干预能力</span>
                <span class="value ${assessment.intervention?.level === 'good' || assessment.intervention?.level === 'excellent' ? 'good' : 'warning'}">
                    ${assessment.intervention?.count || 0}次干预
                </span>
            </div>
        </div>
        
        ${report.interventions && report.interventions.length > 0 ? `
        <div class="report-section">
            <h3>📋 干预详情</h3>
            ${report.interventions.slice(-5).map((iv, i) => `
                <div class="report-metric">
                    <span>干预 ${i + 1}</span>
                    <span class="value ${iv.quality_score >= 0.5 ? 'good' : 'warning'}">${Math.round(iv.quality_score * 100)}%</span>
                </div>
                <p style="font-size: 0.8125rem; color: #666; margin: 4px 0 12px 0;">
                    "${escapeHtml(iv.content)}"
                </p>
            `).join('')}
        </div>
        ` : ''}
    `;
    
    // 更新 badge
    document.getElementById('session-badge').textContent = '已完成';
    document.getElementById('session-badge').className = 'badge';
}

async function showReport() {
    if (!state.sessionId) return;
    
    try {
        const report = await apiCall(`/api/session/${state.sessionId}/report`);
        
        const content = document.getElementById('report-content');
        
        const summary = report.summary || {};
        const metrics = report.metrics || {};
        const assessment = report.ability_assessment || {};
        
        content.innerHTML = `
            <div class="report-section">
                <h3>📊 霸凌情况</h3>
                <div class="report-metric">
                    <span>总消息数</span>
                    <span class="value">${summary.total_messages || 0}</span>
                </div>
                <div class="report-metric">
                    <span>攻击性事件</span>
                    <span class="value danger">${summary.hostile_messages || 0}次</span>
                </div>
                <div class="report-metric">
                    <span>最终霸凌强度</span>
                    <span class="value ${summary.bullying_intensity > 0.5 ? 'danger' : ''}">${Math.round((summary.bullying_intensity || 0) * 100)}%</span>
                </div>
                <div class="report-metric">
                    <span>受害者压力</span>
                    <span class="value ${summary.victim_distress > 0.4 ? 'warning' : ''}">${Math.round((summary.victim_distress || 0) * 100)}%</span>
                </div>
            </div>
            
            <div class="report-section">
                <h3>👨‍🏫 教师干预</h3>
                <div class="report-metric">
                    <span>干预次数</span>
                    <span class="value">${summary.intervention_count || 0}</span>
                </div>
                <div class="report-metric">
                    <span>平均效果</span>
                    <span class="value ${(summary.intervention_effectiveness || 0) >= 0.5 ? 'good' : 'warning'}">${Math.round((summary.intervention_effectiveness || 0) * 100)}%</span>
                </div>
            </div>
            
            <div class="report-section">
                <h3>🎯 能力评估</h3>
                <div class="report-metric">
                    <span>发现能力</span>
                    <span class="value ${assessment.discovery?.level === 'good' ? 'good' : 'warning'}">${assessment.discovery?.description || '未评估'}</span>
                </div>
                <div class="report-metric">
                    <span>干预能力</span>
                    <span class="value ${assessment.intervention?.level === 'good' || assessment.intervention?.level === 'excellent' ? 'good' : 'warning'}">
                        ${assessment.intervention?.count || 0}次干预
                    </span>
                </div>
            </div>
            
            ${report.interventions && report.interventions.length > 0 ? `
            <div class="report-section">
                <h3>📋 干预详情</h3>
                ${report.interventions.slice(-5).map((iv, i) => `
                    <div class="report-metric">
                        <span>干预 ${i + 1}</span>
                        <span class="value ${iv.quality_score >= 0.5 ? 'good' : 'warning'}">${Math.round(iv.quality_score * 100)}%</span>
                    </div>
                    <p style="font-size: 0.8125rem; color: #666; margin: 4px 0 12px 0;">
                        "${escapeHtml(iv.content)}"
                    </p>
                `).join('')}
            </div>
            ` : ''}
        `;
        
        // 显示模态框
        document.getElementById('report-modal').classList.add('active');
        
        // 更新 badge
        document.getElementById('session-badge').textContent = '已完成';
        document.getElementById('session-badge').className = 'badge';
        
    } catch (error) {
        console.error('获取报告失败:', error);
    }
}

// ============================================================
// 会话情境管理
// ============================================================

async function loadScenarios() {
    try {
        const result = await apiCall('/api/scenarios');
        state.scenarios = result.scenarios || [];
        renderScenarioSelect();
    } catch (error) {
        console.error('加载情境失败:', error);
    }
}

function renderScenarioSelect() {
    const select = document.getElementById('scenario-select');
    select.innerHTML = '<option value="">-- 选择情境 --</option>';
    
    state.scenarios.forEach(s => {
        const option = document.createElement('option');
        option.value = s.id;
        option.textContent = s.title;
        option.dataset.level = s.level;
        select.appendChild(option);
    });
}

function onScenarioSelect() {
    const select = document.getElementById('scenario-select');
    const scenarioId = select.value;
    
    if (!scenarioId) {
        // 清空输入
        document.getElementById('scenario-title').value = '';
        document.getElementById('scenario-desc').value = '';
        state.currentScenario = null;
        state.scenarioModified = false;
        updateScenarioTip();
        return;
    }
    
    // 查找选中情境
    const scenario = state.scenarios.find(s => s.id === scenarioId);
    if (scenario) {
        state.currentScenario = scenario;
        document.getElementById('scenario-title').value = scenario.title;
        document.getElementById('scenario-desc').value = scenario.description;
        state.scenarioModified = false;
        updateScenarioTip();
        
        // 自动选择级别
        if (scenario.level) {
            document.querySelectorAll('.level-btn').forEach(b => {
                b.classList.remove('active');
                if (parseInt(b.dataset.level) === scenario.level) {
                    b.classList.add('active');
                    state.level = scenario.level;
                    updateLevelInfo(scenario.level);
                }
            });
        }
        
        // 启用开始按钮
        document.getElementById('btn-start').disabled = false;
    }
}

// 启用情境选择（新会话流程）
function enableScenarioSelection() {
    document.getElementById('scenario-select').disabled = false;
    document.getElementById('scenario-select').value = '';
    document.getElementById('scenario-title').disabled = false;
    document.getElementById('scenario-title').value = '';
    document.getElementById('scenario-desc').disabled = false;
    document.getElementById('scenario-desc').value = '';
    document.getElementById('btn-save-scenario').classList.remove('hidden');
    state.currentScenario = null;
    state.scenarioModified = false;
    updateScenarioTip();
    
    // 显示开始按钮（禁用状态）
    const btnStart = document.getElementById('btn-start');
    const btnNewSess = document.getElementById('btn-new-session-alt');
    btnStart.classList.remove('hidden');
    btnStart.disabled = true;
    btnNewSess.classList.add('hidden');
}

function onScenarioModified() {
    if (!state.scenarioModified) {
        state.scenarioModified = true;
        updateScenarioTip();
    }
}

function updateScenarioTip() {
    const tip = document.getElementById('scenario-tip');
    if (state.scenarioModified) {
        tip.querySelector('.status-text').textContent = '描述已修改，点击"保存"保存情境';
        tip.className = 'scenario-status modified';
        document.getElementById('btn-save-scenario').classList.remove('hidden');
    } else {
        tip.querySelector('.status-text').textContent = '选择情境或创建新的会话情境';
        tip.className = 'scenario-status';
        document.getElementById('btn-save-scenario').classList.add('hidden');
    }
}

function newScenario() {
    // 清空并准备新建
    document.getElementById('scenario-select').value = '';
    document.getElementById('scenario-title').value = '新情境';
    document.getElementById('scenario-desc').value = '';
    state.currentScenario = null;
    state.scenarioModified = true;
    updateScenarioTip();
    document.getElementById('scenario-title').focus();
}

async function saveScenario() {
    const title = document.getElementById('scenario-title').value.trim();
    const description = document.getElementById('scenario-desc').value.trim();
    
    if (!title) {
        alert('请输入情境标题');
        return;
    }
    
    if (!description) {
        alert('请输入情境描述');
        return;
    }
    
    try {
        const result = await apiCall('/api/scenarios', 'POST', {
            title: title,
            description: description,
            level: state.level
        });
        
        // 添加到列表
        state.scenarios.push(result.scenario);
        renderScenarioSelect();
        
        // 选中新创建的情境
        document.getElementById('scenario-select').value = result.scenario.id;
        state.currentScenario = result.scenario;
        state.scenarioModified = false;
        updateScenarioTip();
        
        // 显示保存成功
        const tip = document.getElementById('scenario-tip');
        tip.querySelector('.status-text').textContent = '情境已保存成功';
        tip.className = 'scenario-status saved';
        setTimeout(() => {
            tip.querySelector('.status-text').textContent = '选择情境或创建新的会话情境';
            tip.className = 'scenario-status';
        }, 2000);
        
    } catch (error) {
        console.error('保存情境失败:', error);
        alert('保存失败: ' + error.message);
    }
}

function toggleScenarioPanel() {
    const form = document.getElementById('scenario-form');
    const icon = document.getElementById('scenario-collapse-icon');
    const header = document.getElementById('scenario-header');
    
    if (form.classList.contains('collapsed')) {
        // 展开
        form.classList.remove('collapsed');
        icon.classList.remove('collapsed');
        header.classList.remove('collapsed');
    } else {
        // 折叠
        form.classList.add('collapsed');
        icon.classList.add('collapsed');
        header.classList.add('collapsed');
    }
}

// ============================================================
// 工具函数
// ============================================================

function getMaxRounds(level) {
    return 99;  // 不限制轮数
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================================
// 参与者信息编辑
// ============================================================

async function loadParticipants() {
    try {
        const result = await apiCall('/api/participants', 'GET');
        state.participants = result.participants || [];
    } catch (error) {
        console.error('加载参与者信息失败:', error);
    }
}

function renderParticipantSelectList() {
    const container = document.getElementById('participant-select-list');
    if (!container) return;
    
    container.innerHTML = state.participants.map(p => `
        <div class="participant-select-item ${state.currentEditingParticipant?.id === p.id ? 'active' : ''}" 
             data-id="${p.id}">
            <span class="participant-icon">${p.icon || '👤'}</span>
            <div>
                <div class="participant-name">${p.name}</div>
                <div class="participant-role">${p.roleName || p.role}</div>
            </div>
        </div>
    `).join('');
    
    // 添加点击事件
    container.querySelectorAll('.participant-select-item').forEach(item => {
        item.addEventListener('click', () => {
            const id = item.dataset.id;
            selectParticipant(id);
        });
    });
}

function selectParticipant(id) {
    const participant = state.participants.find(p => p.id === id);
    if (!participant) return;
    
    state.currentEditingParticipant = participant;
    
    // 更新选中状态
    document.querySelectorAll('.participant-select-item').forEach(item => {
        item.classList.toggle('active', item.dataset.id === id);
    });
    
    // 填充表单
    document.getElementById('edit-participant-name').textContent = participant.name;
    document.getElementById('edit-participant-role').textContent = participant.roleName || participant.role;
    
    document.getElementById('edit-name').value = participant.name || '';
    document.getElementById('edit-background').value = participant.personality?.background || '';
    
    // 性格特征转为逗号分隔字符串
    const traits = participant.personality?.traits || [];
    document.getElementById('edit-traits').value = traits.join('、');
    
    document.getElementById('edit-speaking-style').value = participant.personality?.speakingStyle?.join('、') || '';
}

async function openParticipantModal() {
    // 重新加载参与者信息
    await loadParticipants();
    
    // 默认选中第一个
    if (state.participants.length > 0 && !state.currentEditingParticipant) {
        selectParticipant(state.participants[0].id);
    }
    
    renderParticipantSelectList();
    
    document.getElementById('participant-modal').classList.add('active');
}

function closeParticipantModal() {
    document.getElementById('participant-modal').classList.remove('active');
    state.currentEditingParticipant = null;
}

async function saveParticipant() {
    if (!state.currentEditingParticipant) return;
    
    const id = state.currentEditingParticipant.id;
    
    // 获取表单数据
    const name = document.getElementById('edit-name').value.trim();
    const background = document.getElementById('edit-background').value.trim();
    const traitsText = document.getElementById('edit-traits').value.trim();
    const speakingStyleText = document.getElementById('edit-speaking-style').value.trim();
    
    if (!name) {
        alert('请输入姓名');
        return;
    }
    
    // 转换为数组
    const traits = traitsText ? traitsText.split(/[、,，]/).map(t => t.trim()).filter(t => t) : [];
    const speakingStyle = speakingStyleText ? speakingStyleText.split(/[、,，]/).map(s => s.trim()).filter(s => s) : [];
    
    try {
        const result = await apiCall(`/api/participants/${id}`, 'PUT', {
            name: name,
            personality: {
                background: background,
                traits: traits,
                speakingStyle: speakingStyle
            }
        });
        
        if (result.success) {
            // 更新本地状态
            const index = state.participants.findIndex(p => p.id === id);
            if (index !== -1) {
                state.participants[index] = result.participant;
            }
            state.currentEditingParticipant = result.participant;
            
            // 更新表单显示
            selectParticipant(id);
            
            // 更新左侧参与者档案显示
            updateParticipantCard(id, result.participant);
            
            alert('保存成功！');
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('保存失败: ' + error.message);
    }
}

async function resetCurrentParticipant() {
    if (!state.currentEditingParticipant) return;
    
    if (!confirm('确定要重置为默认配置吗？')) return;
    
    const id = state.currentEditingParticipant.id;
    
    try {
        const result = await apiCall(`/api/participants/${id}/reset`, 'POST');
        
        if (result.success) {
            // 更新本地状态
            const index = state.participants.findIndex(p => p.id === id);
            if (index !== -1) {
                state.participants[index] = result.participant;
            }
            state.currentEditingParticipant = result.participant;
            
            // 更新表单显示
            selectParticipant(id);
            
            // 更新左侧参与者档案显示
            updateParticipantCard(id, result.participant);
            
            alert('已重置为默认配置');
        }
    } catch (error) {
        console.error('重置失败:', error);
        alert('重置失败: ' + error.message);
    }
}

function updateParticipantCard(id, participant) {
    const card = document.getElementById(`part-${id}`);
    if (!card) return;
    
    // 更新姓名
    const nameEl = card.querySelector('.participant-info strong');
    if (nameEl) nameEl.textContent = participant.name;
    
    // 更新图标
    const iconEl = card.querySelector('.participant-icon');
    if (iconEl && participant.icon) iconEl.textContent = participant.icon;
    
    // 更新角色标签
    const roleEl = card.querySelector('.role-tag');
    if (roleEl && participant.roleName) roleEl.textContent = participant.roleName;
    
    // 更新特征描述
    const traitEl = card.querySelector('.participant-detail .trait');
    if (traitEl && participant.personality?.traits?.length > 0) {
        traitEl.textContent = participant.personality.traits.slice(0, 2).join('、');
    }
}

// ============================================================
// 干预库管理
// ============================================================

async function loadInterventions() {
    try {
        const result = await apiCall('/api/interventions', 'GET');
        state.interventionLibrary = result.interventions || [];
        // 加载推荐干预
        await loadRecommendedInterventions();
    } catch (error) {
        console.error('加载干预库失败:', error);
    }
}

async function loadRecommendedInterventions() {
    try {
        // 获取当前状态参数
        const intensity = parseFloat(document.getElementById('progress-intensity')?.style.width || '0') / 100;
        const distress = parseFloat(document.getElementById('progress-distress')?.style.width || '0') / 100;
        const result = await apiCall(`/api/interventions/recommend?level=${state.level}&distress=${distress}&bullying_intensity=${intensity}`, 'GET');
        state.recommendedInterventions = result.recommended || [];
        state.allInterventions = result.all || [];
        
        // 显示关怀预警
        if (result.warning) {
            showInterventionWarning(result.warning);
        } else {
            hideInterventionWarning();
        }
        
        renderQuickButtons();
    } catch (error) {
        console.error('加载推荐干预失败:', error);
        // 降级：使用全部干预的前5个
        state.recommendedInterventions = state.interventionLibrary.slice(0, 5);
        state.allInterventions = state.interventionLibrary;
        renderQuickButtons();
    }
}

function showInterventionWarning(warning) {
    // 查找或创建关怀预警区域
    let warnEl = document.getElementById('intervention-warning');
    if (!warnEl) {
        warnEl = document.createElement('div');
        warnEl.id = 'intervention-warning';
        warnEl.className = 'intervention-warning';
        warnEl.style.cssText = 'margin: 8px 0; padding: 10px 12px; border-radius: 6px; font-size: 0.8125rem; cursor: pointer;';
        // 插入到干预面板顶部
        const panel = document.querySelector('.intervention-panel .panel-header');
        if (panel) panel.parentNode.insertBefore(warnEl, panel.nextSibling);
    }
    
    const colors = {
        'danger': { bg: '#ffebee', border: '#ef5350', color: '#c62828' },
        'warning': { bg: '#fff8e1', border: '#ffb300', color: '#f57c00' },
        'info': { bg: '#e3f2fd', border: '#42a5f5', color: '#1565c0' }
    };
    const style = colors[warning.level] || colors['info'];
    
    warnEl.style.background = style.bg;
    warnEl.style.border = `1px solid ${style.border}`;
    warnEl.style.color = style.color;
    warnEl.innerHTML = `<div style="font-weight: bold; margin-bottom: 4px;">${warning.message}</div>`;
    warnEl.onclick = () => warnEl.classList.toggle('collapsed');
    warnEl.classList.remove('collapsed');
    
    // 高亮推荐的心理修复干预
    if (warning.suggestions && warning.suggestions.length > 0) {
        setTimeout(() => {
            document.querySelectorAll('.quick-btn[data-id]').forEach(btn => {
                if (warning.suggestions.includes(btn.dataset.id)) {
                    btn.style.boxShadow = `0 0 0 2px ${style.border}`;
                    btn.style.fontWeight = 'bold';
                }
            });
        }, 100);
    }
}

function hideInterventionWarning() {
    const warnEl = document.getElementById('intervention-warning');
    if (warnEl) warnEl.remove();
    // 清除高亮
    document.querySelectorAll('.quick-btn[data-id]').forEach(btn => {
        btn.style.boxShadow = '';
        btn.style.fontWeight = '';
    });
}

function renderQuickButtons() {
    const container = document.getElementById('quick-btn-list');
    if (!container) return;
    
    // 显示推荐的干预（最多5个）
    const toShow = state.recommendedInterventions.slice(0, 5);
    container.innerHTML = toShow.map(item => `
        <button class="quick-btn" data-id="${item.id}" title="${item.content.slice(0, 50)}...">
            ${item.title}
        </button>
    `).join('');
    
    // 添加点击事件
    container.querySelectorAll('.quick-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const intervention = state.interventionLibrary.find(i => i.id === id);
            if (intervention) {
                document.getElementById('intervention-input').value = intervention.content;
                // 停止倒计时，等待用户发送
                cancelWaitTimer();
            }
        });
    });
    
    // 更新更多列表
    const moreList = document.getElementById('more-intervention-list');
    if (moreList) {
        const remaining = state.allInterventions.filter(i => 
            !state.recommendedInterventions.slice(0, 5).some(r => r.id === i.id)
        );
        moreList.innerHTML = remaining.map(item => `
            <button class="quick-btn" data-id="${item.id}" title="${item.content.slice(0, 50)}...">
                ${item.title}
            </button>
        `).join('');
        
        moreList.querySelectorAll('.quick-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                const intervention = state.interventionLibrary.find(i => i.id === id);
                if (intervention) {
                    document.getElementById('intervention-input').value = intervention.content;
                    // 停止倒计时，等待用户发送
                    cancelWaitTimer();
                    // 关闭更多列表
                    toggleMoreInterventions();
                }
            });
        });
    }
}

function toggleMoreInterventions() {
    const moreDiv = document.getElementById('more-interventions');
    const moreBtn = document.getElementById('btn-more-interventions');
    
    state.showAllInterventions = !state.showAllInterventions;
    
    if (state.showAllInterventions) {
        moreDiv.classList.remove('hidden');
        moreBtn.classList.add('expanded');
        moreBtn.textContent = '收起 ▲';
    } else {
        moreDiv.classList.add('hidden');
        moreBtn.classList.remove('expanded');
        moreBtn.textContent = '更多 ▼';
    }
}

function openInterventionModal() {
    state.currentEditingIntervention = null;
    renderInterventionList();
    clearInterventionForm();
    document.getElementById('intervention-modal').classList.add('active');
}

function closeInterventionModal() {
    document.getElementById('intervention-modal').classList.remove('active');
    state.currentEditingIntervention = null;
}

function renderInterventionList() {
    const container = document.getElementById('intervention-list');
    if (!container) return;
    
    container.innerHTML = state.interventionLibrary.map(item => `
        <div class="intervention-list-item ${state.currentEditingIntervention?.id === item.id ? 'active' : ''}" 
             data-id="${item.id}">
            <span class="item-title">${item.title}</span>
            ${item.id.startsWith('custom_') ? '<span class="item-delete" data-delete="' + item.id + '">✕</span>' : ''}
        </div>
    `).join('');
    
    // 添加点击事件
    container.querySelectorAll('.intervention-list-item').forEach(item => {
        item.addEventListener('click', (e) => {
            if (e.target.classList.contains('item-delete')) {
                return; // 删除按钮单独处理
            }
            const id = item.dataset.id;
            selectIntervention(id);
        });
    });
    
    // 删除按钮事件
    container.querySelectorAll('.item-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = btn.dataset.delete;
            if (confirm('确定要删除这个干预内容吗？')) {
                deleteInterventionById(id);
            }
        });
    });
}

function selectIntervention(id) {
    const intervention = state.interventionLibrary.find(i => i.id === id);
    if (!intervention) return;
    
    state.currentEditingIntervention = intervention;
    
    // 更新选中状态
    document.querySelectorAll('.intervention-list-item').forEach(item => {
        item.classList.toggle('active', item.dataset.id === id);
    });
    
    // 填充表单
    document.getElementById('edit-intervention-title').value = intervention.title || '';
    document.getElementById('edit-intervention-content').value = intervention.content || '';
    document.getElementById('edit-intervention-category').value = intervention.category || '';
    document.getElementById('edit-intervention-tags').value = (intervention.tags || []).join('、');
    
    // 显示/隐藏删除按钮
    const deleteBtn = document.getElementById('btn-delete-intervention');
    const infoDiv = document.getElementById('edit-intervention-info');
    
    if (intervention.id.startsWith('custom_')) {
        deleteBtn.classList.remove('hidden');
        infoDiv.classList.add('hidden');
    } else {
        deleteBtn.classList.add('hidden');
        infoDiv.classList.remove('hidden');
    }
}

function clearInterventionForm() {
    document.getElementById('edit-intervention-title').value = '';
    document.getElementById('edit-intervention-content').value = '';
    document.getElementById('edit-intervention-category').value = '';
    document.getElementById('edit-intervention-tags').value = '';
    document.getElementById('btn-delete-intervention').classList.add('hidden');
    document.getElementById('edit-intervention-info').classList.add('hidden');
}

function addNewIntervention() {
    state.currentEditingIntervention = { id: 'new', title: '', content: '', category: '自定义', tags: [] };
    clearInterventionForm();
    document.getElementById('edit-intervention-title').focus();
    
    // 更新列表选中状态
    document.querySelectorAll('.intervention-list-item').forEach(item => {
        item.classList.remove('active');
    });
}

async function saveIntervention() {
    const title = document.getElementById('edit-intervention-title').value.trim();
    const content = document.getElementById('edit-intervention-content').value.trim();
    const category = document.getElementById('edit-intervention-category').value.trim() || '自定义';
    const tagsText = document.getElementById('edit-intervention-tags').value.trim();
    const tags = tagsText ? tagsText.split(/[、,，]/).map(t => t.trim()).filter(t => t) : [];
    
    if (!title || !content) {
        alert('请输入标题和内容');
        return;
    }
    
    try {
        if (state.currentEditingIntervention?.id === 'new') {
            // 新建
            const result = await apiCall('/api/interventions', 'POST', {
                title, content, category, tags
            });
            
            if (result.success) {
                await loadInterventions();
                closeInterventionModal();
                alert('添加成功！');
            }
        } else if (state.currentEditingIntervention?.id?.startsWith('custom_')) {
            // 更新自定义干预
            const result = await apiCall(`/api/interventions/${state.currentEditingIntervention.id}`, 'PUT', {
                title, content, category, tags
            });
            
            if (result.success) {
                await loadInterventions();
                closeInterventionModal();
                alert('保存成功！');
            }
        } else {
            alert('系统内置干预内容不能修改');
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('保存失败: ' + error.message);
    }
}

async function deleteIntervention() {
    if (!state.currentEditingIntervention?.id?.startsWith('custom_')) {
        alert('系统内置干预内容不能删除');
        return;
    }
    
    if (!confirm('确定要删除这个干预内容吗？')) return;
    
    try {
        const result = await apiCall(`/api/interventions/${state.currentEditingIntervention.id}`, 'DELETE');
        
        if (result.success) {
            state.currentEditingIntervention = null;
            await loadInterventions();
            renderInterventionList();
            clearInterventionForm();
            alert('删除成功！');
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('删除失败: ' + error.message);
    }
}

async function deleteInterventionById(id) {
    try {
        const result = await apiCall(`/api/interventions/${id}`, 'DELETE');
        
        if (result.success) {
            if (state.currentEditingIntervention?.id === id) {
                state.currentEditingIntervention = null;
                clearInterventionForm();
            }
            await loadInterventions();
            renderInterventionList();
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('删除失败: ' + error.message);
    }
}

// 更新推荐干预（根据当前对话状态）
async function updateRecommendedInterventions() {
    const distress = parseFloat(document.getElementById('value-distress')?.textContent || '50%') / 100;
    
    try {
        const result = await apiCall(`/api/interventions/recommend?level=${state.level}&distress=${distress}`, 'GET');
        state.recommendedInterventions = result.recommended || [];
        state.allInterventions = result.all || [];
        renderQuickButtons();
    } catch (error) {
        console.error('更新推荐干预失败:', error);
    }
}
