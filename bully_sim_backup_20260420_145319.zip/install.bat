@echo off
chcp 65001 >nul 2>&1
title 校园话语霸凌与教师干预实训系统 - 安装

echo ==========================================
echo   校园话语霸凌与教师干预实训系统
echo   Windows 依赖安装
echo ==========================================
echo.

:: 获取批处理文件所在目录
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

:: 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] 未检测到 Python
    echo.
    echo 请先安装 Python:
    echo   访问 https://www.python.org/downloads/
    echo   下载 Python 3.9 或更高版本
    echo   安装时务必勾选 Add Python to PATH
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%i in ('python --version') do set PYVER=%%i
echo [OK] 检测到 %PYVER%

echo.
echo 正在安装依赖...
echo.

python -m pip install --upgrade pip
pip install fastapi uvicorn pyyaml jinja2 python-dotenv openai langgraph langchain-core langchain-openai httpx requests

if %errorlevel% equ 0 (
    echo.
    echo [OK] 依赖安装成功！
    echo.
    echo 下一步: 双击「启动系统.bat」启动系统
    echo.
) else (
    echo.
    echo [ERROR] 依赖安装失败，请检查网络连接
    echo.
)

pause
