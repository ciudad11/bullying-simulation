import requests, json, os

api_key = os.environ.get("MINIMAX_API_KEY", "")

# Test different endpoints
endpoints = [
    ("MiniMax Official v1", "https://api.minimax.chat/v1/chat/completions"),
    ("MiniMax Official v1 (group)", "https://api.minimax.chat/v1/text/chatcompletion_v2"),
]

models_to_try = [
    "MiniMax-Text-01",
    "abab6.5s-chat",
    "abab6.5t-chat",
    "abab6.5g-chat",
]

for ep_name, url in endpoints:
    for model in models_to_try:
        try:
            r = requests.post(
                url,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": "你好"}],
                    "max_tokens": 10,
                },
                timeout=15,
            )
            data = r.json()
            if r.status_code == 200:
                # Try different response formats
                content = ""
                if "choices" in data:
                    content = data["choices"][0].get("message", {}).get("content", "")
                elif "reply" in data:
                    content = data["reply"]
                elif "choices" in data and "text" in data["choices"][0]:
                    content = data["choices"][0]["text"]
                print(f"OK: [{ep_name}] {model} -> {content}")
            else:
                err = data.get("error", {}).get("message", data.get("base_resp", {}).get("status_msg", str(data)))
                print(f"FAIL: [{ep_name}] {model} -> {str(err)[:100]}")
        except Exception as e:
            print(f"ERR: [{ep_name}] {model} -> {e}")

# Also try the Hailuo/MiniMax API with different group_id
print("\n--- Trying with different group headers ---")
for model in ["MiniMax-Text-01", "abab6.5s-chat"]:
    try:
        r = requests.post(
            "https://api.minimax.chat/v1/text/chatcompletion_v2",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": "你好"}],
                "tokens_to_generate": 10,
            },
            timeout=15,
        )
        data = r.json()
        if r.status_code == 200:
            content = data.get("reply", data.get("choices", [{}])[0].get("message", {}).get("content", str(data)))
            print(f"OK: [v2] {model} -> {content}")
        else:
            err = data.get("base_resp", {}).get("status_msg", data.get("error", {}).get("message", str(data)))
            print(f"FAIL: [v2] {model} -> {str(err)[:100]}")
    except Exception as e:
        print(f"ERR: [v2] {model} -> {e}")
