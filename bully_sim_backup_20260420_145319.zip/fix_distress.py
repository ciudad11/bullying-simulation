# -*- coding: utf-8 -*-
"""修复受害者压力异常累积问题"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

filepath = r'D:\bully_simulation_4.9ver\src\orchestrator.py'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# === 定位并替换破损的自然恢复块 ===
marker = "self._prev_bullying_high"
idx_start = content.find(f"        # ===== ����ֹ")
idx_marker = content.find(marker)

if idx_start == -1 or idx_marker == -1:
    print(f"ERROR: idx_start={idx_start}, idx_marker={idx_marker}")
    sys.exit(1)

# 找到这段代码块的结束（下一个方法定义之前）
search = content[idx_marker:]
idx_end_marker = search.find('\n\n    def evaluate_intervention')
if idx_end_marker == -1:
    print("ERROR: 未找到 evaluate_intervention")
    sys.exit(1)
idx_end = idx_marker + idx_end_marker + 2  # +2 for the \n\n

old_block = content[idx_start:idx_end]
print(f"找到旧块，字符数: {len(old_block)}")
print("--- 旧块内容 ---")
print(old_block[:200])

new_block = """        # ===== 霸凌→受害者压力直接耦合（核心因果链）=====
        # 霸凌强度越高，受害者压力越大；霸凌停止，压力才可能下降
        if self._metrics_initialized and self.message_history:
            current_bully = self.metrics.bullying_intensity
            coupling_rate = cfg('victim_distress.bully_attack_distress_rate', 0.10)
            emotional_scale = cfg('victim_distress.emotional_feedback_scale', 0.3)

            if current_bully > 0:
                # 霸凌驱动压力：当前霸凌强度直接增加压力
                bully_drive = current_bully * coupling_rate
                self.metrics.victim_distress = min(1.0,
                    self.metrics.victim_distress + bully_drive)

            # 受害者情绪词在当前高压力情境下放大压力（情绪是症状）
            if role == AgentRole.VICTIM.value and current_bully > 0.1:
                if emotions:
                    for emotion_type in ["sad", "fearful", "self_doubt"]:
                        if emotion_type in emotions:
                            base_add = {
                                "sad": cfg('victim_distress.sad_emotion', 0.12),
                                "fearful": cfg('victim_distress.fearful_emotion', 0.18),
                                "self_doubt": cfg('victim_distress.self_doubt', 0.22),
                            }[emotion_type]
                            # 在有霸凌背景下，情绪词的贡献被缩放（情绪是结果非主因）
                            scaled_add = base_add * emotional_scale
                            self.metrics.victim_distress = min(1.0,
                                self.metrics.victim_distress + scaled_add)

            # 霸凌停止后自然恢复（每轮固定减压）
            decay_th = cfg('victim_distress.distress_decay_threshold', 0.2)
            decay_rate = cfg('victim_distress.distress_decay_rate', 0.05)
            if current_bully < decay_th and self.metrics.victim_distress > 0:
                self.metrics.victim_distress = max(0,
                    self.metrics.victim_distress - decay_rate)
"""

new_content = content[:idx_start] + new_block + content[idx_end:]

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("\n文件已更新!")

# 验证
with open(filepath, 'r', encoding='utf-8') as f:
    verify = f.read()
if "bully_attack_distress_rate" in verify:
    print("验证通过: bully_attack_distress_rate 已写入")
else:
    print("验证失败!")
