# -*- coding: utf-8 -*-
"""详细追踪受害者压力的变化过程"""
import requests
import json

base = 'http://localhost:5000'

def run_and_show(sid, label=""):
    r = requests.post(f'{base}/api/session/{sid}/run')
    data = r.json()
    s = data.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)
    msgs = data.get('messages', [])
    
    # 打印每条消息
    role_map = {'bully': '霸凌者', 'victim': '受害者', 'bystander_a': '旁观A', 'bystander_b': '旁观B', 'system': '系统'}
    for m in msgs:
        role = role_map.get(m.get('agent_id',''), m.get('agent_id',''))
        content = m.get('content','')[:60]
        print(f"    [{role}] {content}...")
    
    print(f"  {label}→ B={b:.1%} V={v:.1%}")
    return data

print("=" * 60)
print("测试1: 无干预情况，观察压力随霸凌变化")
print("=" * 60)
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': True})
data = r.json()
sid = data['session_id']
s = data['status']
print(f"初始状态: B={s['bullying_intensity']:.1%} V={s['victim_distress']:.1%}")
print()

for i in range(4):
    data = run_and_show(sid, f"第{i+1}轮后")

print()
print("=" * 60)
print("测试2: 干预后观察恢复")
print("=" * 60)

# 高压力状态干预
if not data.get('done'):
    r = requests.post(f'{base}/api/session/{sid}/intervene', json={
        'content': '思远，你还好吗？老师看到了你的委屈，这不是你的错，老师一定会保护你。陈浩，你的行为已经严重伤害了同学，请立刻停止，我们需要谈谈。'
    })
    iv = r.json()
    print(f"干预评估: 质量={iv.get('quality_score',0):.2f} B={iv.get('bullying_intensity',0):.1%} V={iv.get('victim_distress',0):.1%}")
    
    print("\n干预后运行3轮：")
    for i in range(3):
        data = run_and_show(sid, f"干预后第{i+1}轮")

print()
print("=" * 60)
print("测试3: 验证因果关系——霸凌下降→压力下降")
print("=" * 60)
r2 = requests.post(f'{base}/api/session', json={'level': 1, 'use_llm': True})
sid2 = r2.json()['session_id']
s2 = r2.json()['status']
print(f"初始: B={s2['bullying_intensity']:.1%} V={s2['victim_distress']:.1%}")

# 运行到霸凌者发言，然后旁观者干预使霸凌下降
for i in range(5):
    r_post = requests.post(f'{base}/api/session/{sid2}/run')
    d = r_post.json()
    ss = d.get('status', {})
    print(f"轮{i+1}: B={ss.get('bullying_intensity',0):.1%} V={ss.get('victim_distress',0):.1%}")
    if d.get('done'):
        print(f"  场景结束: {d.get('auto_end_reason','')}")
        break

print("\n✅ 验证点总结:")
print("  1. 霸凌持续时，压力应逐渐上升")
print("  2. 霸凌停止后，压力应逐渐下降（自然恢复）")
print("  3. 有效干预后，压力应立即下降")
