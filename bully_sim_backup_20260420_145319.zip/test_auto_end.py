import requests
import json
import time

# Test auto-end conditions
print('=== Test Auto-End Conditions ===')

# Create session with low level to trigger auto-end quickly
resp = requests.post('http://127.0.0.1:5000/api/session', json={'level': 1, 'use_llm': False})
data = resp.json()
session_id = data.get('session_id')
print(f"Session ID: {session_id}")

# Run many rounds to trigger auto-end
for i in range(50):
    resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
    data = resp.json()
    
    if data.get('done') or data.get('auto_ended'):
        print(f"\n=== Auto-end triggered at round {i+1} ===")
        print(f"Auto ended: {data.get('auto_ended')}")
        print(f"Auto end reason: {data.get('auto_end_reason')}")
        print(f"Status: {data.get('status', {})}")
        break
    
    if i < 5:  # Print first few rounds
        print(f"Round {i+1}: {len(data.get('messages', []))} messages")

print('\n=== Test completed ===')
