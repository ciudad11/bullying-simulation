import requests
import json
import time

# Test intervention not repeating in new round
print('=== Test: Intervention Not Repeating ===')

# Create session
resp = requests.post('http://127.0.0.1:5000/api/session', json={'level': 2, 'use_llm': False})
data = resp.json()
session_id = data.get('session_id')
print(f"Session ID: {session_id}")

# Run 3 rounds
for i in range(3):
    resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
    data = resp.json()
    print(f"Round {i+1}: {len(data.get('messages', []))} new messages")

# Send intervention
print("\n--- Sending intervention ---")
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/intervene', 
                     json={'content': '同学们，请停止这种行为'})
data = resp.json()
print(f"Intervention message from: {data.get('message', {}).get('sender')}")

# Run next round - check if intervention appears again
print("\n--- Running next round ---")
resp = requests.post(f'http://127.0.0.1:5000/api/session/{session_id}/run')
data = resp.json()
messages = data.get('messages', [])
print(f"New messages count: {len(messages)}")

# Check if teacher message appears twice
teacher_count = sum(1 for m in messages if m.get('role') == 'teacher')
print(f"Teacher messages in this round: {teacher_count}")

if teacher_count == 0:
    print("[PASS] Intervention not repeated in new round")
else:
    print("[FAIL] Intervention repeated!")
    for m in messages:
        if m.get('role') == 'teacher':
            print(f"  - {m.get('sender')}: {m.get('content')}")

print('\n=== Test completed ===')
