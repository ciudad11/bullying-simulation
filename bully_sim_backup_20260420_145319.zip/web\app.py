#!/usr/bin/env python3
"""
Campus Verbal Bullying & Teacher Intervention Training System v3.0
======================================
Based on LangGraph Multi-Agent Architecture

Run:
    python3 -m uvicorn app:app --reload --port 5000
"""

# Load .env
from dotenv import load_dotenv
import os
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

import asyncio
import datetime
import json
import time
import uuid
from pathlib import Path
from typing import Optional, Dict, List

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn

from session_manager import SessionManager, NEW_MULTI_AGENT_AVAILABLE, load_config


# Custom JSONResponse that ensures UTF-8 encoding
class UTF8JSONResponse(JSONResponse):
    def render(self, content) -> bytes:
        return json.dumps(content, ensure_ascii=False, allow_nan=False).encode("utf-8")


# ============================================================
# LLM Configuration
# ============================================================

LLM_API_KEY = os.environ.get("MINIMAX_API_KEY", "") or os.environ.get("OPENCLAW_API_KEY", "")
if not LLM_API_KEY:
    try:
        openclaw_config = Path.home() / ".openclaw" / "openclaw.json"
        if openclaw_config.exists():
            with open(openclaw_config, "r", encoding="utf-8") as f:
                config = json.load(f)
            providers = config.get("models", {}).get("providers", {})
            for name in ["minimax-cn", "minimax"]:
                if name in providers:
                    LLM_API_KEY = providers[name].get("apiKey", "")
                    break
    except Exception:
        pass

print(f"LLM API Key: {'Set' if LLM_API_KEY else 'Not set'}")
print(f"New LangGraph MultiAgent: {'Available' if NEW_MULTI_AGENT_AVAILABLE else 'Not available'}")

# ============================================================
# FastAPI App
# ============================================================

app = FastAPI(
    title="Campus Verbal Bullying & Teacher Intervention System",
    description="Teacher Professional Development Training Platform",
    version="3.0.0"
)

BASE_DIR = Path(__file__).parent
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.mount("/css", StaticFiles(directory=str(BASE_DIR / "css")), name="css")
app.mount("/js", StaticFiles(directory=str(BASE_DIR / "js")), name="js")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# ============================================================
# Preset Scenarios (8 scenarios from original app.py)
# ============================================================

_scenarios = [
    {
        "id": "scenario_1",
        "title": "美术课上的嘲笑",
        "description": "思远在美术课上展示自己的画作，陈浩当众嘲笑她的画\"丑\"、\"土\"，并带动其他同学起哄。",
        "level": 2,
    },
    {
        "id": "scenario_2",
        "title": "食堂里的排挤",
        "description": "午餐时间，陈浩故意不让思远坐在他们旁边，说\"这里没你的位置\"，导致思远独自坐在角落。",
        "level": 3,
    },
    {
        "id": "scenario_3",
        "title": "体育课上的孤立",
        "description": "体育课上分组活动，陈浩故意不让思远加入自己的小组，说\"我们不要拖后腿的\"。",
        "level": 3,
    },
    {
        "id": "scenario_4",
        "title": "网络上的嘲讽",
        "description": "陈浩在班级群里发思远的照片并配上嘲笑的文字，其他同学纷纷点赞和跟风评论。",
        "level": 4,
    },
    {
        "id": "scenario_5",
        "title": "放学路上的威胁",
        "description": "放学后，陈浩和几个同学在走廊拦住思远，威胁她\"明天带钱来，不然有你好看\"。",
        "level": 5,
    },
    {
        "id": "scenario_6",
        "title": "课堂上的羞辱",
        "description": "语文课上思远回答问题出错，陈浩大声嘲笑\"这么简单都不会，笨死了\"，老师没有及时制止。",
        "level": 2,
    },
    {
        "id": "scenario_7",
        "title": "运动会上的恶作剧",
        "description": "运动会报名时，陈浩故意在思远的报名表上写侮辱性的外号，导致全班哄堂大笑。",
        "level": 3,
    },
    {
        "id": "scenario_8",
        "title": "考试后的嘲讽",
        "description": "期中考试成绩公布后，陈浩当众嘲笑思远的成绩，说\"考这么差还好意思来上学\"。",
        "level": 2,
    },
]

# ============================================================
# Session Management
# ============================================================

sessions: Dict[str, SessionManager] = {}


def create_session(level: int = 2, scenario_id: str = None, use_llm: bool = False) -> SessionManager:
    """Create new session"""
    session_id = str(uuid.uuid4())[:8]

    scenario = None
    if scenario_id:
        for s in _scenarios:
            if s["id"] == scenario_id:
                scenario = s
                break

    session = SessionManager(
        session_id=session_id,
        level=level,
        scenario=scenario,
        use_llm=use_llm,
    )
    sessions[session_id] = session
    return session


def get_session(session_id: str) -> Optional[SessionManager]:
    return sessions.get(session_id)


# ============================================================
# API Routes - Scenarios
# ============================================================

@app.get("/api/scenarios")
async def get_scenarios():
    return UTF8JSONResponse(content={"scenarios": _scenarios, "count": len(_scenarios)})


@app.post("/api/scenarios")
async def create_scenario(request: dict):
    title = request.get("title", "").strip()
    description = request.get("description", "").strip()
    if not title or not description:
        raise HTTPException(status_code=400, detail="Title and description required")

    for s in _scenarios:
        if s["title"] == title:
            raise HTTPException(status_code=400, detail="Title already exists")

    scenario = {
        "id": f"custom_{uuid.uuid4().hex[:8]}",
        "title": title,
        "description": description,
        "level": request.get("level", 2),
    }
    _scenarios.append(scenario)
    return UTF8JSONResponse(content={"success": True, "scenario": scenario})


@app.put("/api/scenarios/{scenario_id}")
async def update_scenario(scenario_id: str, request: dict):
    for s in _scenarios:
        if s["id"] == scenario_id:
            if request.get("title"):
                s["title"] = request["title"]
            if request.get("description"):
                s["description"] = request["description"]
            if "level" in request:
                s["level"] = request["level"]
            return UTF8JSONResponse(content={"success": True, "scenario": s})
    raise HTTPException(status_code=404, detail="Scenario not found")


@app.delete("/api/scenarios/{scenario_id}")
async def delete_scenario(scenario_id: str):
    for i, s in enumerate(_scenarios):
        if s["id"] == scenario_id:
            if scenario_id.startswith("custom_"):
                _scenarios.pop(i)
                return UTF8JSONResponse(content={"success": True})
            raise HTTPException(status_code=403, detail="Preset scenarios cannot be deleted")
    raise HTTPException(status_code=404, detail="Scenario not found")


# ============================================================
# API Routes - Participants
# ============================================================

@app.get("/api/participants")
async def get_participants():
    """Get participant info (from multi_agent module)"""
    try:
        from multi_agent.agents import AGENT_ROLE_MAP
        participants = []
        for agent_id, cfg in AGENT_ROLE_MAP.items():
            participants.append({
                "id": agent_id,
                "name": cfg.get("name", agent_id),
                "roleName": cfg.get("role_type", agent_id),
            })
        return UTF8JSONResponse(content={"success": True, "participants": participants})
    except ImportError:
        return UTF8JSONResponse(content={"success": True, "participants": [
            {"id": "bully", "name": "陈浩", "roleName": "霸凌者"},
            {"id": "victim", "name": "思远", "roleName": "受害者"},
            {"id": "bystander_a", "name": "林雨桐", "roleName": "正义旁观者"},
            {"id": "bystander_b", "name": "赵磊", "roleName": "从众旁观者"},
        ]})


# ============================================================
# API Routes - Intervention Library
# ============================================================

INTERVENTION_LIB_PATH = Path(__file__).parent.parent / "src" / "intervention_library.json"


def load_interventions() -> dict:
    if INTERVENTION_LIB_PATH.exists():
        with open(INTERVENTION_LIB_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # 规范化 tags 字段（修复历史遗留问题：tags 被错误存储为字符串）
        for item in data.get("interventions", []):
            if isinstance(item.get("tags"), str):
                item["tags"] = [t.strip() for t in item["tags"].split() if t.strip()]
        return data
    return {"interventions": []}


def save_interventions(data: dict):
    with open(INTERVENTION_LIB_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


@app.get("/api/interventions")
async def get_interventions():
    return UTF8JSONResponse(content={"success": True, "interventions": load_interventions().get("interventions", [])})


@app.post("/api/interventions")
async def create_intervention(request: dict):
    title = request.get("title", "").strip()
    content = request.get("content", "").strip()
    if not title or not content:
        raise HTTPException(status_code=400, detail="Title and content required")

    data = load_interventions()
    new_id = f"custom_{uuid.uuid4().hex[:8]}"
    new_interv = {
        "id": new_id,
        "title": title,
        "content": content,
        "category": request.get("category", "Custom"),
        "tags": request.get("tags", ["Custom"]),
    }
    data.setdefault("interventions", []).append(new_interv)
    save_interventions(data)
    return UTF8JSONResponse(content={"success": True, "intervention": new_interv})


@app.put("/api/interventions/{intervention_id}")
async def update_intervention(intervention_id: str, request: dict):
    data = load_interventions()
    for i, item in enumerate(data.get("interventions", [])):
        if item.get("id") == intervention_id:
            if not intervention_id.startswith("custom_"):
                raise HTTPException(status_code=403, detail="Built-in interventions cannot be modified")
            data["interventions"][i].update({
                "title": request.get("title", item["title"]),
                "content": request.get("content", item["content"]),
                "category": request.get("category", item.get("category", "Custom")),
                "tags": request.get("tags", item.get("tags", [])),
            })
            save_interventions(data)
            return UTF8JSONResponse(content={"success": True, "intervention": data["interventions"][i]})
    raise HTTPException(status_code=404, detail="Intervention not found")


@app.delete("/api/interventions/{intervention_id}")
async def delete_intervention(intervention_id: str):
    if not intervention_id.startswith("custom_"):
        raise HTTPException(status_code=403, detail="Built-in interventions cannot be deleted")
    data = load_interventions()
    new_list = [x for x in data.get("interventions", []) if x.get("id") != intervention_id]
    if len(new_list) == len(data.get("interventions", [])):
        raise HTTPException(status_code=404, detail="Intervention not found")
    data["interventions"] = new_list
    save_interventions(data)
    return UTF8JSONResponse(content={"success": True})


@app.get("/api/interventions/recommend")
async def recommend_interventions(
    session_id: str = None,
    level: int = 2,
    distress: float = 0.5,
    bullying_intensity: float = 0.0,
):
    """Recommend interventions based on current state"""
    all_interventions = load_interventions().get("interventions", [])

    # Default recommended interventions
    priority_ids = []
    warning = None

    if distress >= 0.8:
        priority_ids = ["psych_repair_3", "psych_repair_2", "victim_priority", "private_talk", "post_bullying_care"]
        warning = "受害者压力极高，需要立即干预！"
    elif distress >= 0.6:
        priority_ids = ["support", "psych_repair_1", "private_talk", "empathy_build", "bystander_guide"]
        warning = "受害者压力较高，建议尽快干预。"
    elif bullying_intensity >= 0.7:
        priority_ids = ["firm", "rule_remind", "behavior_contract", "face_talk", "support"]
        warning = "霸凌强度较高，需要坚定制止。"
    elif bullying_intensity >= 0.4:
        priority_ids = ["kind", "reflect", "bystander_guide", "empathy_build", "class_discussion"]
    else:
        priority_ids = ["kind", "bystander_guide", "class_discussion", "private_talk", "support"]

    # Filter and sort
    recommended = sorted(
        [x for x in all_interventions if x["id"] in priority_ids],
        key=lambda x: priority_ids.index(x["id"]) if x["id"] in priority_ids else 999
    )[:5]

    return UTF8JSONResponse(content={
        "success": True,
        "recommended": recommended,
        "all": all_interventions,
        "warning": warning,
        "remaining": [x for x in all_interventions if x["id"] not in priority_ids],
    })


# ============================================================
# API Routes - Session Management
# ============================================================

class CreateSessionRequest(BaseModel):
    level: int = 2
    scenario_id: Optional[str] = None
    use_llm: bool = True


class InterventionRequest(BaseModel):
    content: str


@app.post("/api/session")
async def create_new_session(request: CreateSessionRequest):
    """Create new session"""
    level = request.level
    if level < 1 or level > 5:
        raise HTTPException(status_code=400, detail="Level must be 1-5")

    session = create_session(
        level=request.level,
        scenario_id=request.scenario_id,
        use_llm=request.use_llm,
    )

    return UTF8JSONResponse(content={
        "session_id": session.session_id,
        "level": session.level,
        "scenario": session.scenario,
        "use_llm": session.use_llm,
        "llm_available": NEW_MULTI_AGENT_AVAILABLE and bool(LLM_API_KEY),
        "status": session.get_status(),
    })


@app.get("/api/session/{session_id}")
async def get_session_status(session_id: str):
    """Get session status"""
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return UTF8JSONResponse(content={
        "session_id": session.session_id,
        "level": session.level,
        "status": session.get_status(),
    })


@app.post("/api/session/{session_id}/run")
async def run_simulation_round(session_id: str):
    """Run one round of dialogue"""
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # 必须先调用 run_round()，让内部 supervisor_node() 设置 termination_reason
    # 之后检查 done 状态，用 run_round() 返回的 auto_end_reason
    status = session.run_round()

    # 如果已经结束（内部 Supervisor 已设置 termination_reason），返回完整终止信息
    if status.get("done"):
        return UTF8JSONResponse(content={
            "done": True,
            "auto_ended": True,
            "auto_end_reason": status.get("auto_end_reason", ""),
            "result_type": status.get("result_type", ""),
            "status": status.get("status", {}),
            "messages": status.get("messages", []),
        })

    # 未结束时，才检查主动终止条件（max_rounds 等）
    end_check = session.check_auto_end_conditions()
    if end_check["should_end"]:
        return UTF8JSONResponse(content={
            "done": True,
            "auto_ended": True,
            "auto_end_reason": end_check["reason"],
            "result_type": session.result_type or "",
            "status": session.get_status(),
        })

    return UTF8JSONResponse(content={
        "done": status.get("done", False),
        "auto_ended": status.get("auto_ended", False),
        "auto_end_reason": status.get("auto_end_reason", ""),
        "status": status.get("status", {}),
        "messages": status.get("messages", []),
    })


@app.get("/api/session/{session_id}/auto-end-status")
async def get_auto_end_status(session_id: str):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return UTF8JSONResponse(content=session.check_auto_end_conditions())


@app.post("/api/session/{session_id}/auto-end-config")
async def update_auto_end_config(session_id: str, request: Request):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    try:
        config = await request.json()
        for key, value in config.items():
            if key in session.AUTO_END_CONFIG:
                session.AUTO_END_CONFIG[key] = value
        return UTF8JSONResponse(content={"success": True, "config": session.AUTO_END_CONFIG})
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/session/{session_id}/intervene")
async def intervene(session_id: str, request: InterventionRequest):
    """Teacher intervention"""
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    content = request.content.strip()
    if not content:
        raise HTTPException(status_code=400, detail="Intervention content cannot be empty")

    result = session.intervene(content)
    
    # 添加干预消息到会话消息列表
    # 使用 time 模块获取时间戳，避免 datetime 模块被覆盖的问题
    msg = {
        "id": str(uuid.uuid4())[:8],
        "sender": "张老师",
        "role": "teacher",
        "role_name": "教师",
        "role_icon": "👩‍🏫",
        "content": content,
        "timestamp": time.strftime("%H:%M:%S"),
        "round": session.get_status().get("round", 1),
    }
    session.add_message(msg)

    return UTF8JSONResponse(content={
        "intervention": result,
        "message": msg,
        "status": session.get_status(),
    })


@app.get("/api/session/{session_id}/messages")
async def get_messages(session_id: str, after: str = None):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return UTF8JSONResponse(content={"messages": session.get_messages(after)})


@app.get("/api/session/{session_id}/report")
async def get_report(session_id: str):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return UTF8JSONResponse(content=session.generate_report())


@app.delete("/api/session/{session_id}")
async def delete_session(session_id: str):
    if session_id in sessions:
        report = sessions[session_id].generate_report()
        del sessions[session_id]
    return UTF8JSONResponse(content={"ok": True})


# ============================================================
# SSE Streaming (optional)
# ============================================================

@app.get("/api/session/{session_id}/stream")
async def stream_updates(session_id: str):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    async def event_generator():
        last_msg_id = None
        while True:
            new_messages = session.get_messages(last_msg_id)
            for msg in new_messages:
                yield f"data: {json.dumps({'type': 'message', 'data': msg}, ensure_ascii=False)}\n\n"
                last_msg_id = msg.get("id")
            status = session.get_status()
            if status.get("finished"):
                yield f"data: {json.dumps({'type': 'done', 'reason': status.get('termination_reason', '')}, ensure_ascii=False)}\n\n"
                break
            await asyncio.sleep(1)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


# ============================================================
# Web Routes
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def home():
    return templates.TemplateResponse("index.html", {
        "request": {},
        "title": "Campus Verbal Bullying & Teacher Intervention System"
    })


# ============================================================
# Run
# ============================================================

def run():
    print("\n" + "=" * 60)
    print("Campus Verbal Bullying & Teacher Intervention System v3.0")
    print("LangGraph Multi-Agent Architecture")
    print("=" * 60)
    print(f"\nOpen: http://localhost:5000")
    print(f"LLM: {'Enabled' if LLM_API_KEY else 'Disabled (using presets)'}")
    print(f"New MultiAgent: {'Enabled' if NEW_MULTI_AGENT_AVAILABLE else 'Fallback mode'}")
    print()
    uvicorn.run(app, host="0.0.0.0", port=5000)


if __name__ == "__main__":
    run()
