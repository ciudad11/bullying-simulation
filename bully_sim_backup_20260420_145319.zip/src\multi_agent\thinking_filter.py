"""
思维过滤器 - 提取对话内容，移除思考过程
策略：保守过滤，段落级别处理，宁可保留多余内容也不丢失有效对话
"""

import re


def extract_dialogue_only(text: str, agent_name: str = '') -> str:
    """
    从 LLM 输出中提取纯对话内容，移除思考过程。

    策略：
    1. 处理 <think...> 标签格式（MiniMax/DeepSeek 等）
    2. 按段落分离，保留最后一段（通常是对话）
    3. 只过滤明确标记的内容块，不对自然语言逐行猜测
    """
    if not text or not text.strip():
        return text

    original = text.strip()
    text = original.replace('\r\n', '\n').replace('\r', '\n')

    # Phase 1: <think...> 标签处理
    # 移除被标签包裹的整块思考内容
    text = re.sub(r'<think[^>]*>[\s\S]*?</think[^>]*>', '', text, flags=re.IGNORECASE)

    # 处理未闭合的 <think 标签（截断情况）
    if '<think' in text.lower():
        text = re.sub(r'<think[^>]*>[^\n]*\n?', '', text, flags=re.IGNORECASE)

    # 清理残留标签
    text = re.sub(r'</?think[^>]*>', '', text, flags=re.IGNORECASE)
    text = text.strip()

    if not text:
        return original

    # Phase 2: 按空行分段，段落级别处理
    paragraphs = re.split(r'\n\s*\n', text)
    paragraphs = [p.strip() for p in paragraphs if p.strip()]

    if not paragraphs:
        return original

    if len(paragraphs) == 1:
        return _clean_single_paragraph(paragraphs[0])

    # 多段落：最后一段通常是对话内容
    last = paragraphs[-1]
    if _looks_like_dialogue(last):
        return _clean_single_paragraph(last)

    # 倒数第二段也可能包含对话
    if len(paragraphs) >= 2 and _looks_like_dialogue(paragraphs[-2]):
        return _clean_single_paragraph(paragraphs[-2])

    # 兜底：返回最后一段
    return _clean_single_paragraph(last)


def _looks_like_dialogue(text: str) -> bool:
    """
    判断一段文字是否像对话（而非纯分析）

    对话特征（满足任一即为对话）：
    - 包含引号、「」、《》
    - 包含动作描述（中文括号内的动作）
    - 长度 < 100 字（通常对话比较简短）

    明确不是对话的特征：
    - 纯编号列表（3个以上编号项）且无动作描述
    """
    if not text:
        return False

    # 明确是对话
    if re.search(r'[""\u300c\u300d\u300e\u300f]', text):
        return True
    if re.search(r'[\uff08(].*?[\uff09)]', text):  # 动作描述
        return True
    if len(text) < 100:
        return True

    # 明确是分析（多行编号列表）
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    numbered_lines = sum(
        1 for l in lines
        if re.match(r'^\s*[\d\u4e00-\u4e5f]+[\.、:：]', l)
    )
    if numbered_lines >= 3 and not re.search(r'[\uff08(]', text):
        return False

    return True


def _clean_single_paragraph(text: str) -> str:
    """清理单段文本中的内联思考痕迹"""
    if not text:
        return text

    # 移除明显的思考前缀（仅匹配行首）
    text = re.sub(r'^\s*(思考[：:]\s*|分析[：:]\s*)', '', text)

    # 清理表情符号标记
    text = text.replace('\U0001f4ad', '').replace('\U0001f914', '').replace('\U0001f9e0', '')

    # 如果文本包含动作描述，且动作描述之前是思考性文字，则从动作处截断
    # 例如："我觉得她很可怜。（低头小声说）我没有做错什么..."
    # → 保留从动作描述开始的部分
    match = re.search(r'[\uff08(][^\uff09)]*[\uff09)]', text)
    if match and match.start() > 10:
        before_action = text[:match.start()].strip()
        if _before_action_is_thinking(before_action):
            text = text[match.start():]

    return text.strip()


def _before_action_is_thinking(text: str) -> bool:
    """判断动作描述之前的文本是否是思考内容"""
    if not text:
        return False

    # 思考性开头关键词
    thinking_indicators = [
        '我觉得', '我认为', '我想', '作为', '应该',
        '需要考虑', '根据情境', '作为一个', '角色扮演',
        '在当前情况下', '在这种情况下',
    ]

    for indicator in thinking_indicators:
        if text.startswith(indicator):
            return True

    # 如果有明显对话引号，不是思考
    if re.search(r'[""\u300c\u300d\u300e\u300f]', text):
        return False

    return False


def filter_thinking_content(response, agent_name=''):
    """公开接口"""
    return extract_dialogue_only(response, agent_name)