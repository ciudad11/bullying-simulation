# -*- coding: utf-8 -*-
"""详细诊断压力计算和干预问题"""
import requests
import json

base = 'http://localhost:5000'

print("=" * 70)
print("诊断测试 - 受害者压力异常上升问题")
print("=" * 70)

# 创建session
r = requests.post(f'{base}/api/session', json={'level': 2, 'use_llm': False})
data = r.json()
sid = data['session_id']
s = data['status']
print(f'Session ID: {sid}')
print(f'初始状态: B={s.get("bullying_intensity",0):.1%} V={s.get("victim_distress",0):.1%}')

print("\n" + "=" * 70)
print("阶段1: 观察5轮压力变化")
print("=" * 70)

prev_b, prev_v = 0, 0
for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)
    
    # 计算变化
    b_delta = b - prev_b
    v_delta = v - prev_v
    
    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        role = last.get('role', '')
        content = last.get('content', '')[:50]
        print(f'轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')
    
    prev_b, prev_v = b, v
    
    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("阶段2: 执行干预并检查响应")
print("=" * 70)

# 使用明确的关怀语言
intervention_text = '思远，这不是你的错，老师看到了你的委屈。陈浩，你的行为已经构成了言语霸凌，需要立刻停止并向思远道歉。'
print(f'干预内容: {intervention_text}')

r = requests.post(f'{base}/api/session/{sid}/intervene', json={'content': intervention_text})
iv = r.json()
print(f'\n干预响应:')
print(f'  quality_score: {iv.get("quality_score", "N/A")}')
print(f'  victim_care_score: {iv.get("victim_care_score", "N/A")}')
print(f'  bullying_intensity: {iv.get("bullying_intensity", "N/A")}')
print(f'  victim_distress: {iv.get("victim_distress", "N/A")}')
print(f'  feedback: {iv.get("feedback", [])}')

# 检查session状态
r2 = requests.get(f'{base}/api/session/{sid}')
s2 = r2.json().get('status', {})
print(f'\n当前session状态:')
print(f'  B={s2.get("bullying_intensity", 0):.1%} V={s2.get("victim_distress", 0):.1%}')

print("\n" + "=" * 70)
print("阶段3: 干预后观察压力恢复")
print("=" * 70)

for i in range(5):
    r = requests.post(f'{base}/api/session/{sid}/run')
    d = r.json()
    s = d.get('status', {})
    b = s.get('bullying_intensity', 0)
    v = s.get('victim_distress', 0)
    
    b_delta = b - prev_b
    v_delta = v - prev_v
    
    msgs = d.get('messages', [])
    if msgs:
        last = msgs[-1]
        sender = last.get('sender', '')
        content = last.get('content', '')[:50]
        print(f'干预后轮{i+1}: B={b:.1%}({b_delta:+.1%}) V={v:.1%}({v_delta:+.1%}) | [{sender}] {content}...')
    
    prev_b, prev_v = b, v
    
    if d.get('done'):
        print(f'  会话结束: {d.get("auto_end_reason", "")}')
        break

print("\n" + "=" * 70)
print("诊断总结")
print("=" * 70)
print("预期行为:")
print("  1. 霸凌持续时，压力应缓慢上升（每轮<5%）")
print("  2. 干预后，B和V应明显下降（根据干预质量）")
print("  3. 霸凌停止后，压力应自然恢复")
print("\n如果看到异常：")
print("  - 压力快速增长 (>10%/轮) → 耦合系数过高")
print("  - 干预返回quality=0 → 检查evaluate_intervention逻辑")
print("  - 干预后压力不降 → 检查intervention_relief配置")
