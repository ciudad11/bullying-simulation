import requests, json, os

api_key = os.environ.get("MINIMAX_API_KEY", "")

# Try listing models via the v1 endpoint
try:
    r = requests.get(
        "https://api.minimax.chat/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=15,
    )
    print("GET /v1/models status:", r.status_code)
    print(json.dumps(r.json(), indent=2, ensure_ascii=False)[:2000])
except Exception as e:
    print(f"Error listing models: {e}")

# Also try some newer model names
print("\n--- Testing newer model names ---")
models = [
    "minimax-abab-7",
    "MiniMax-ABAB-7",
    "MiniMax-ABAB6.5S",
    "Hailuo-Video-01",
    "MiniMax-Text",
    "MiniMax-Chat",
    "text-01",
    "MiniMax-Text-02",
    "MiniMax-M1-80k",
]

for model in models:
    try:
        r = requests.post(
            "https://api.minimax.chat/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": "hi"}],
                "max_tokens": 5,
            },
            timeout=15,
        )
        data = r.json()
        if r.status_code == 200:
            content = data["choices"][0]["message"]["content"]
            print(f"OK: {model} -> {content}")
        else:
            err = data.get("error", {}).get("message", str(data))
            print(f"FAIL: {model} -> {err[:100]}")
    except Exception as e:
        print(f"ERR: {model} -> {e}")
