@echo off
chcp 65001 >nul 2>&1
title 校园话语霸凌与教师干预实训系统

echo ==========================================
echo   校园话语霸凌与教师干预实训系统
echo ==========================================
echo.

:: 获取批处理文件所在目录
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

:: 加载 .env 中的环境变量（含 API Key）
if exist ".env" (
    for /f "usebackq tokens=1,* delims==" %%a in (".env") do (
        set "%%a=%%b"
    )
    echo [OK] 环境变量已加载（含 API Key）
) else (
    echo [ERROR] 未找到 .env 文件！
    echo 请在项目根目录创建 .env 文件并配置 MINIMAX_API_KEY
    echo.
    pause
    exit /b 1
)

:: 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] 未检测到 Python，请先安装 Python 3.9+
    echo 下载地址: https://www.python.org/downloads/
    echo 安装时请勾选 Add Python to PATH
    echo.
    pause
    exit /b 1
)

:: 检查依赖
echo 检查依赖...
python -c "import fastapi, uvicorn, yaml, jinja2, dotenv, openai, langgraph" 2>nul
if errorlevel 1 (
    echo [WARN] 部分依赖未安装，正在自动安装...
    echo.
    pip install fastapi uvicorn pyyaml jinja2 python-dotenv openai langgraph langchain-core langchain-openai httpx requests
    if errorlevel 1 (
        echo [ERROR] 依赖安装失败，请手动运行 install.bat
        pause
        exit /b 1
    )
)
echo [OK] 依赖检查通过

:: 检查 API Key
if defined MINIMAX_API_KEY (
    echo [OK] API Key: 已配置
) else (
    echo [ERROR] API Key 未配置！
    echo 请在 .env 文件中设置 MINIMAX_API_KEY
    echo.
    pause
    exit /b 1
)

echo.
echo 启动服务...
echo.
echo 访问地址: http://localhost:5000
echo 按 Ctrl+C 停止服务
echo.

:: 3秒后自动打开浏览器
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"

:: 启动服务
python web\app.py
