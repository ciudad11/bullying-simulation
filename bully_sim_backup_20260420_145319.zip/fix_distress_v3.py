# -*- coding: utf-8 -*-
"""进一步优化压力计算逻辑 - 增加平滑性和合理性"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 修改orchestrator.py中的压力计算逻辑
filepath = r'D:\bully_simulation_4.9ver\src\orchestrator.py'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# === 调整霸凌→压力耦合段，增加压力增长的阻尼机制 ===
old_coupling_block = """        # ===== 霸凌→受害者压力直接耦合（核心因果链）=====
        # 霸凌强度越高，受害者压力越大；霸凌停止，压力才可能下降
        if self._metrics_initialized and self.message_history:
            current_bully = self.metrics.bullying_intensity
            coupling_rate = cfg('victim_distress.bully_attack_distress_rate', 0.04)
            emotional_scale = cfg('victim_distress.emotional_feedback_scale', 0.3)

            if current_bully > 0:
                # 霸凌驱动压力：当前霸凌强度直接增加压力
                bully_drive = current_bully * coupling_rate
                self.metrics.victim_distress = min(1.0,
                    self.metrics.victim_distress + bully_drive)

            # 受害者情绪词在当前高压力情境下放大压力（情绪是症状）
            if role == AgentRole.VICTIM.value and current_bully > 0.1:
                if emotions:
                    for emotion_type in ["sad", "fearful", "self_doubt"]:
                        if emotion_type in emotions:
                            base_add = {
                                "sad": cfg('victim_distress.sad_emotion', 0.12),
                                "fearful": cfg('victim_distress.fearful_emotion', 0.18),
                                "self_doubt": cfg('victim_distress.self_doubt', 0.22),
                            }[emotion_type]
                            # 在有霸凌背景下，情绪词的贡献被缩放（情绪是结果非主因）
                            scaled_add = base_add * emotional_scale
                            self.metrics.victim_distress = min(1.0,
                                self.metrics.victim_distress + scaled_add)

            # 霸凌停止后自然恢复（每轮固定减压）
            decay_th = cfg('victim_distress.distress_decay_threshold', 0.3)
            decay_rate = cfg('victim_distress.distress_decay_rate', 0.08)
            if current_bully < decay_th and self.metrics.victim_distress > 0:
                self.metrics.victim_distress = max(0,
                    self.metrics.victim_distress - decay_rate)"""

new_coupling_block = """        # ===== 霸凌→受害者压力直接耦合（核心因果链）=====
        # 霸凌强度越高，受害者压力越大；霸凌停止，压力才可能下降
        if self._metrics_initialized and self.message_history:
            current_bully = self.metrics.bullying_intensity
            coupling_rate = cfg('victim_distress.bully_attack_distress_rate', 0.04)
            emotional_scale = cfg('victim_distress.emotional_feedback_scale', 0.3)

            if current_bully > 0:
                # 霸凌驱动压力：增加阻尼机制，避免压力飙升
                # 使用对数缩放：压力增长速度随当前压力值递减
                current_distress = self.metrics.victim_distress
                damping_factor = 1.0 - (current_distress * 0.5)  # 压力越高，增长越慢
                bully_drive = current_bully * coupling_rate * max(0.3, damping_factor)
                self.metrics.victim_distress = min(1.0,
                    self.metrics.victim_distress + bully_drive)

            # 受害者情绪词在当前高压力情境下放大压力（情绪是症状）
            if role == AgentRole.VICTIM.value and current_bully > 0.1:
                if emotions:
                    for emotion_type in ["sad", "fearful", "self_doubt"]:
                        if emotion_type in emotions:
                            base_add = {
                                "sad": cfg('victim_distress.sad_emotion', 0.12),
                                "fearful": cfg('victim_distress.fearful_emotion', 0.18),
                                "self_doubt": cfg('victim_distress.self_doubt', 0.22),
                            }[emotion_type]
                            # 在有霸凌背景下，情绪词的贡献被缩放（情绪是结果非主因）
                            # 并考虑阻尼：压力越高，情绪词影响越小
                            current_distress = self.metrics.victim_distress
                            damping = 1.0 - (current_distress * 0.3)
                            scaled_add = base_add * emotional_scale * max(0.5, damping)
                            self.metrics.victim_distress = min(1.0,
                                self.metrics.victim_distress + scaled_add)

            # 霸凌停止后自然恢复（每轮固定减压）
            # 放宽恢复条件：只要霸凌强度低于阈值就触发恢复
            decay_th = cfg('victim_distress.distress_decay_threshold', 0.3)
            decay_rate = cfg('victim_distress.distress_decay_rate', 0.08)
            if current_bully < decay_th and self.metrics.victim_distress > 0:
                # 恢复速度与当前压力成正比：压力越高，恢复越快
                recovery_boost = self.metrics.victim_distress * 0.1
                total_decay = decay_rate + recovery_boost
                self.metrics.victim_distress = max(0,
                    self.metrics.victim_distress - total_decay)"""

if old_coupling_block in content:
    content = content.replace(old_coupling_block, new_coupling_block)
    print("✓ 已优化霸凌→压力耦合逻辑（增加阻尼机制）")
else:
    print("✗ 未找到原耦合逻辑块")

# 保存修改
with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

print("\n✅ orchestrator.py 已更新")
print("\n优化要点：")
print("  1. 增加阻尼机制：压力越高，增长越慢（避免飙升）")
print("  2. 情绪词影响也带阻尼：高压力时情绪影响减弱")
print("  3. 恢复速度与压力成正比：压力越高，恢复越快")
print("  4. 保持原有参数配置接口")
