import sys
sys.path.insert(0, 'src')
sys.path.insert(0, 'web')

from session_manager import SessionManager

# 创建会话
sm = SessionManager('test_intervention_session', level=2, use_llm=True)
print('Session created')

# 运行一轮
result = sm.run_round()
msg_count = len(result.get("messages", []))
print(f'Run round 1: {msg_count} messages')
metrics = result.get("metrics", {})
print(f'Status: B={metrics.get("bullying_intensity", 0):.2f}, V={metrics.get("victim_distress", 0):.2f}')

# 测试干预
print('\nSending intervention 1: "同学们，我们应该互相尊重，不应该嘲笑别人。"')
interv_result = sm.intervene('同学们，我们应该互相尊重，不应该嘲笑别人。')
print(f'Intervention result: {interv_result}')
print(f'New B={interv_result.get("bullying_intensity", "N/A"):.2f}, V={interv_result.get("victim_distress", "N/A"):.2f}')

# 运行下一轮
print('\nRunning round 2...')
result2 = sm.run_round()
metrics2 = result2.get("metrics", {})
print(f'After intervention: B={metrics2.get("bullying_intensity", 0):.2f}, V={metrics2.get("victim_distress", 0):.2f}')

# 测试第二个干预
print('\nSending intervention 2: "思远，你还好吗？老师的办公室随时欢迎你来倾诉，我会保护你的。"')
interv_result2 = sm.intervene('思远，你还好吗？老师的办公室随时欢迎你来倾诉，我会保护你的。')
print(f'Intervention result: {interv_result2}')
print(f'New B={interv_result2.get("bullying_intensity", "N/A"):.2f}, V={interv_result2.get("victim_distress", "N/A"):.2f}')

# 运行第三轮
print('\nRunning round 3...')
result3 = sm.run_round()
metrics3 = result3.get("metrics", {})
print(f'After intervention 2: B={metrics3.get("bullying_intensity", 0):.2f}, V={metrics3.get("victim_distress", 0):.2f}')

# 检查干预记录
print(f'\nTotal interventions recorded: {len(sm.interventions)}')
for i, iv in enumerate(sm.interventions):
    print(f'  {i+1}. score={iv.get("quality_score", 0):.2f}, B-reduction={iv.get("bullying_reduction", 0):.2f}, V-reduction={iv.get("distress_reduction", 0):.2f}')
