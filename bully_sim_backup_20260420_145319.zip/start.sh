#!/bin/bash

# 校园话语霸凌与教师干预实训系统 - macOS 启动脚本

echo "=========================================="
echo "  校园话语霸凌与教师干预实训系统"
echo "=========================================="
echo ""

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 检查依赖
echo "检查依赖..."
python3 -c "import fastapi, uvicorn, yaml, jinja2" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ 依赖未安装，请先运行 install.sh"
    echo ""
    exit 1
fi

echo "✅ 依赖检查通过"
echo ""
echo "启动服务..."
echo ""

# 启动服务
python3 -m uvicorn web.app:app --host 0.0.0.0 --port 5002

# 按 Ctrl+C 退出
