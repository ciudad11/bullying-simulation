# -*- coding: utf-8 -*-
"""修复受害者压力异常累积问题 v2 - 移除重复计算并优化参数"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

filepath = r'D:\bully_simulation_4.9ver\src\orchestrator.py'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# === 修复1: 移除受害者情绪词的重复计算（第一段） ===
# 在 elif role == AgentRole.VICTIM.value 分支中，注释掉情绪词直接累积
old_victim_block = """        elif role == AgentRole.VICTIM.value:
            if emotions and "sad" in emotions:
                self.metrics.victim_distress = min(1.0, 
                    self.metrics.victim_distress + cfg('victim_distress.sad_emotion', 0.12))
            if emotions and "fearful" in emotions:
                self.metrics.victim_distress = min(1.0, 
                    self.metrics.victim_distress + cfg('victim_distress.fearful_emotion', 0.18))
            if emotions and "self_doubt" in emotions:
                # 自我怀疑/自我否定情绪，危害极大
                self.metrics.victim_distress = min(1.0,
                    self.metrics.victim_distress + cfg('victim_distress.self_doubt', 0.22))
            if supportive_score > cfg('victim_distress.supportive_threshold', 0.3):
                self.metrics.victim_distress = max(0, 
                    self.metrics.victim_distress - cfg('victim_distress.supportive_comfort', 0.15))"""

new_victim_block = """        elif role == AgentRole.VICTIM.value:
            # 情绪词的压力累积已移至霸凌→压力耦合段，避免重复计算
            # 仅保留支持性言语的减压效果
            if supportive_score > cfg('victim_distress.supportive_threshold', 0.3):
                self.metrics.victim_distress = max(0, 
                    self.metrics.victim_distress - cfg('victim_distress.supportive_comfort', 0.15))"""

if old_victim_block in content:
    content = content.replace(old_victim_block, new_victim_block)
    print("✓ 已移除受害者情绪词重复累积（第一段）")
else:
    print("✗ 未找到第一段受害者情绪累积代码")

# === 修复2: 调整霸凌→压力耦合段参数 ===
old_coupling = "            coupling_rate = cfg('victim_distress.bully_attack_distress_rate', 0.10)"
new_coupling = "            coupling_rate = cfg('victim_distress.bully_attack_distress_rate', 0.04)"

if old_coupling in content:
    content = content.replace(old_coupling, new_coupling)
    print("✓ 已降低耦合系数 0.10 → 0.04")
else:
    print("✗ 未找到耦合系数配置")

old_decay_th = "            decay_th = cfg('victim_distress.distress_decay_threshold', 0.2)"
new_decay_th = "            decay_th = cfg('victim_distress.distress_decay_threshold', 0.3)"

if old_decay_th in content:
    content = content.replace(old_decay_th, new_decay_th)
    print("✓ 已提高恢复阈值 0.2 → 0.3")
else:
    print("✗ 未找到恢复阈值配置")

old_decay_rate = "            decay_rate = cfg('victim_distress.distress_decay_rate', 0.05)"
new_decay_rate = "            decay_rate = cfg('victim_distress.distress_decay_rate', 0.08)"

if old_decay_rate in content:
    content = content.replace(old_decay_rate, new_decay_rate)
    print("✓ 已提高恢复速率 0.05 → 0.08")
else:
    print("✗ 未找到恢复速率配置")

# 保存修改
with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

print("\n✅ orchestrator.py 已更新")

# === 更新配置文件 ===
config_path = r'D:\bully_simulation_4.9ver\config\orchestrator.yaml'
with open(config_path, 'r', encoding='utf-8') as f:
    config = f.read()

# 更新配置参数
config = config.replace('  bully_attack_distress_rate: 0.10', '  bully_attack_distress_rate: 0.04')
config = config.replace('  distress_decay_threshold: 0.1', '  distress_decay_threshold: 0.3')
config = config.replace('  distress_decay_rate: 0.08', '  distress_decay_rate: 0.10')

with open(config_path, 'w', encoding='utf-8') as f:
    f.write(config)

print("✅ orchestrator.yaml 已更新")
print("\n参数调整总结：")
print("  - bully_attack_distress_rate: 0.10 → 0.04 (降低60%)")
print("  - distress_decay_threshold: 0.1 → 0.3 (提高恢复触发条件)")
print("  - distress_decay_rate: 0.08 → 0.10 (提高恢复速度25%)")
print("\n核心修复：移除情绪词双重计算，确保压力仅随霸凌强度变化")
